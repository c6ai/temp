


#include "std_testcase.h"

namespace listen_socket_divide_62
{

#ifndef OMITBAD


void badSource(int &data);

void bad()
{
    int data;
    
    data = -1;
    badSource(data);
    
    printIntLine(100 / data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(int &data);

static void goodG2B()
{
    int data;
    
    data = -1;
    goodG2BSource(data);
    
    printIntLine(100 / data);
}


void goodB2GSource(int &data);

static void goodB2G()
{
    int data;
    
    data = -1;
    goodB2GSource(data);
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace listen_socket_divide_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
