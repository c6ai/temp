

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_82.h"

namespace rand_82
{

void rand_82_bad::action(float data)
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
