

#ifndef OMITGOOD

#include "std_testcase.h"
#include "listenSocket_81.h"

namespace listenSocket_81
{

void listenSocket_81_goodB2G::action(float data) const
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
