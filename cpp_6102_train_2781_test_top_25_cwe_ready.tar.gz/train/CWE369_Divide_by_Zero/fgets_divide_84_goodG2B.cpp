

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_divide_84.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_divide_84
{
fgets_divide_84_goodG2B::fgets_divide_84_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

fgets_divide_84_goodG2B::~fgets_divide_84_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
