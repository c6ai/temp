

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_modulo_83.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_modulo_83
{
fgets_modulo_83_goodG2B::fgets_modulo_83_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

fgets_modulo_83_goodG2B::~fgets_modulo_83_goodG2B()
{
    
    printIntLine(100 % data);
}
}
#endif 
