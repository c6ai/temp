

#ifndef OMITBAD

#include "std_testcase.h"
#include "zero_divide_81.h"

namespace zero_divide_81
{

void zero_divide_81_bad::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
