


#include "std_testcase.h"

namespace fscanf_divide_43
{

#ifndef OMITBAD

static void badSource(int &data)
{
    
    fscanf(stdin, "%d", &data);
}

void bad()
{
    int data;
    
    data = -1;
    badSource(data);
    
    printIntLine(100 / data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSource(int &data)
{
    
    data = 7;
}

static void goodG2B()
{
    int data;
    
    data = -1;
    goodG2BSource(data);
    
    printIntLine(100 / data);
}


static void goodB2GSource(int &data)
{
    
    fscanf(stdin, "%d", &data);
}

static void goodB2G()
{
    int data;
    
    data = -1;
    goodB2GSource(data);
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fscanf_divide_43; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
