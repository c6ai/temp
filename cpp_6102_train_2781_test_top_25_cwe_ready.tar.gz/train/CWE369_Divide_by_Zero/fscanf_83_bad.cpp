

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_83.h"

namespace fscanf_83
{
fscanf_83_bad::fscanf_83_bad(float dataCopy)
{
    data = dataCopy;
    
    fscanf (stdin, "%f", &data);
}

fscanf_83_bad::~fscanf_83_bad()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
