

#ifndef OMITGOOD

#include "std_testcase.h"
#include "connect_socket_82.h"

namespace connect_socket_82
{

void connect_socket_82_goodG2B::action(float data)
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
