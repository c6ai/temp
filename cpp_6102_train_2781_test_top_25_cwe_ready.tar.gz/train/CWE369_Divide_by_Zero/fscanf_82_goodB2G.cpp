

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_82.h"

namespace fscanf_82
{

void fscanf_82_goodB2G::action(float data)
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
