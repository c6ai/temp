

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_84.h"

namespace fscanf_84
{
fscanf_84_goodB2G::fscanf_84_goodB2G(float dataCopy)
{
    data = dataCopy;
    
    fscanf (stdin, "%f", &data);
}

fscanf_84_goodB2G::~fscanf_84_goodB2G()
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
