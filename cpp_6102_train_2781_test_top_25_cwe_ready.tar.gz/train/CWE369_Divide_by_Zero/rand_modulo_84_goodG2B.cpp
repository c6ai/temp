

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_modulo_84.h"

namespace rand_modulo_84
{
rand_modulo_84_goodG2B::rand_modulo_84_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

rand_modulo_84_goodG2B::~rand_modulo_84_goodG2B()
{
    
    printIntLine(100 % data);
}
}
#endif 
