

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_divide_83.h"

namespace fscanf_divide_83
{
fscanf_divide_83_goodG2B::fscanf_divide_83_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

fscanf_divide_83_goodG2B::~fscanf_divide_83_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
