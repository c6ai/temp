


#include "std_testcase.h"
#include "fgets_81.h"

#define CHAR_ARRAY_SIZE 20

namespace fgets_81
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    const fgets_81_base& baseObject = fgets_81_bad();
    baseObject.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    
    data = 2.0F;
    const fgets_81_base& baseObject = fgets_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    const fgets_81_base& baseObject = fgets_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fgets_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
