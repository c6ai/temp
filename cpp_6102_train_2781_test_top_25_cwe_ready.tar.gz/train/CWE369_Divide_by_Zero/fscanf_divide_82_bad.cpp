

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_divide_82.h"

namespace fscanf_divide_82
{

void fscanf_divide_82_bad::action(int data)
{
    
    printIntLine(100 / data);
}

}
#endif 
