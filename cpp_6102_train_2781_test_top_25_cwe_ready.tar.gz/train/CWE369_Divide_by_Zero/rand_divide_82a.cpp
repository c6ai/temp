


#include "std_testcase.h"
#include "rand_divide_82.h"

namespace rand_divide_82
{

#ifndef OMITBAD

void bad()
{
    int data;
    
    data = -1;
    
    data = RAND32();
    rand_divide_82_base* baseObject = new rand_divide_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int data;
    
    data = -1;
    
    data = 7;
    rand_divide_82_base* baseObject = new rand_divide_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    int data;
    
    data = -1;
    
    data = RAND32();
    rand_divide_82_base* baseObject = new rand_divide_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace rand_divide_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
