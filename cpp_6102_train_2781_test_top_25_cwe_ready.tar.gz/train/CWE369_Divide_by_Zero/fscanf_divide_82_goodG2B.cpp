

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_divide_82.h"

namespace fscanf_divide_82
{

void fscanf_divide_82_goodG2B::action(int data)
{
    
    printIntLine(100 / data);
}

}
#endif 
