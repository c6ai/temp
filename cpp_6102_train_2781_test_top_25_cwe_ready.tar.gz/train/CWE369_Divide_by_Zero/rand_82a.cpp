


#include "std_testcase.h"
#include "rand_82.h"

namespace rand_82
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    
    data = (float)RAND32();
    rand_82_base* baseObject = new rand_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    
    data = 2.0F;
    rand_82_base* baseObject = new rand_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    
    data = (float)RAND32();
    rand_82_base* baseObject = new rand_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace rand_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
