


#include "std_testcase.h"
#include <vector>

using namespace std;

namespace zero_modulo_72
{

#ifndef OMITBAD

void badSink(vector<int> dataVector)
{
    
    int data = dataVector[2];
    
    printIntLine(100 % data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<int> dataVector)
{
    int data = dataVector[2];
    
    printIntLine(100 % data);
}


void goodB2GSink(vector<int> dataVector)
{
    int data = dataVector[2];
    
    if( data != 0 )
    {
        printIntLine(100 % data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
