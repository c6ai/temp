

#ifndef OMITBAD

#include "std_testcase.h"
#include "connect_socket_modulo_81.h"

namespace connect_socket_modulo_81
{

void connect_socket_modulo_81_bad::action(int data) const
{
    
    printIntLine(100 % data);
}

}
#endif 
