

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_modulo_82.h"

namespace rand_modulo_82
{

void rand_modulo_82_goodG2B::action(int data)
{
    
    printIntLine(100 % data);
}

}
#endif 
