


#include "std_testcase.h"
#include <map>

using namespace std;

namespace fscanf_divide_74
{

#ifndef OMITBAD

void badSink(map<int, int> dataMap)
{
    
    int data = dataMap[2];
    
    printIntLine(100 / data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, int> dataMap)
{
    int data = dataMap[2];
    
    printIntLine(100 / data);
}


void goodB2GSink(map<int, int> dataMap)
{
    int data = dataMap[2];
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
