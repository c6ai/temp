

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_83.h"

#define CHAR_ARRAY_SIZE 20

namespace fgets_83
{
fgets_83_goodG2B::fgets_83_goodG2B(float dataCopy)
{
    data = dataCopy;
    
    data = 2.0F;
}

fgets_83_goodG2B::~fgets_83_goodG2B()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
