

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_divide_84.h"

namespace rand_divide_84
{
rand_divide_84_goodB2G::rand_divide_84_goodB2G(int dataCopy)
{
    data = dataCopy;
    
    data = RAND32();
}

rand_divide_84_goodB2G::~rand_divide_84_goodB2G()
{
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
