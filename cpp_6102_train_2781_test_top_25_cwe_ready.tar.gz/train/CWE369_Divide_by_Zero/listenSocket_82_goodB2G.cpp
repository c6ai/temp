

#ifndef OMITGOOD

#include "std_testcase.h"
#include "listenSocket_82.h"

namespace listenSocket_82
{

void listenSocket_82_goodB2G::action(float data)
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
