

#ifndef OMITGOOD

#include "std_testcase.h"
#include "listenSocket_82.h"

namespace listenSocket_82
{

void listenSocket_82_goodG2B::action(float data)
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
