


#include "std_testcase.h"

#include <math.h>

namespace rand_62
{

#ifndef OMITBAD

void badSource(float &data)
{
    
    data = (float)RAND32();
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(float &data)
{
    
    data = 2.0F;
}


void goodB2GSource(float &data)
{
    
    data = (float)RAND32();
}

#endif 

} 
