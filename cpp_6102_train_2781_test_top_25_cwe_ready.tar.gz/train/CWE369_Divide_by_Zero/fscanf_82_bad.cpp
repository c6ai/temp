

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_82.h"

namespace fscanf_82
{

void fscanf_82_bad::action(float data)
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
