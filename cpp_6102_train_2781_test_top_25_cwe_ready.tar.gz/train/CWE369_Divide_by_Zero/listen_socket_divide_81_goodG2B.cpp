

#ifndef OMITGOOD

#include "std_testcase.h"
#include "listen_socket_divide_81.h"

namespace listen_socket_divide_81
{

void listen_socket_divide_81_goodG2B::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
