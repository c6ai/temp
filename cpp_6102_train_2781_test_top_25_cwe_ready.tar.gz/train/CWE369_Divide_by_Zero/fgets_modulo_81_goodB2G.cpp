

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_modulo_81.h"

namespace fgets_modulo_81
{

void fgets_modulo_81_goodB2G::action(int data) const
{
    
    if( data != 0 )
    {
        printIntLine(100 % data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
