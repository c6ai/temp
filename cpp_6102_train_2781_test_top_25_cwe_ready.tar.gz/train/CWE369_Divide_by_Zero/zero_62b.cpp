


#include "std_testcase.h"

#include <math.h>

namespace zero_62
{

#ifndef OMITBAD

void badSource(float &data)
{
    
    data = 0.0F;
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(float &data)
{
    
    data = 2.0F;
}


void goodB2GSource(float &data)
{
    
    data = 0.0F;
}

#endif 

} 
