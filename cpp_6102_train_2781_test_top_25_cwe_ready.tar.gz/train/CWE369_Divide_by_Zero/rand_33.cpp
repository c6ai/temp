


#include "std_testcase.h"

#include <math.h>

namespace rand_33
{

#ifndef OMITBAD

void bad()
{
    float data;
    float &dataRef = data;
    
    data = 0.0F;
    
    data = (float)RAND32();
    {
        float data = dataRef;
        {
            
            int result = (int)(100.0 / data);
            printIntLine(result);
        }
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    float &dataRef = data;
    
    data = 0.0F;
    
    data = 2.0F;
    {
        float data = dataRef;
        {
            
            int result = (int)(100.0 / data);
            printIntLine(result);
        }
    }
}


static void goodB2G()
{
    float data;
    float &dataRef = data;
    
    data = 0.0F;
    
    data = (float)RAND32();
    {
        float data = dataRef;
        
        if(fabs(data) > 0.000001)
        {
            int result = (int)(100.0 / data);
            printIntLine(result);
        }
        else
        {
            printLine("This would result in a divide by zero");
        }
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace rand_33; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
