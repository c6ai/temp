


#include "std_testcase.h"


static const int STATIC_CONST_TRUE = 1; 
static const int STATIC_CONST_FALSE = 0; 

namespace class_malloc_04
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        
        data = (TwoIntsClass *)malloc(100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(STATIC_CONST_TRUE)
    {
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        
        data = (TwoIntsClass *)malloc(100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(STATIC_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


static void goodB2G2()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        
        data = (TwoIntsClass *)malloc(100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(STATIC_CONST_TRUE)
    {
        
        free(data);
    }
}


static void goodG2B1()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(STATIC_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new TwoIntsClass;
    }
    if(STATIC_CONST_TRUE)
    {
        
        delete data;
    }
}


static void goodG2B2()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(STATIC_CONST_TRUE)
    {
        
        data = new TwoIntsClass;
    }
    if(STATIC_CONST_TRUE)
    {
        
        delete data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace class_malloc_04; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
