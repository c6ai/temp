


#include "std_testcase.h"

namespace delete_array_char_68
{

char * badData;
char * goodG2BData;
char * goodB2GData;

#ifndef OMITBAD


void badSink();

void bad()
{
    char * data;
    
    data = NULL;
    
    data = new char;
    badData = data;
    badSink();
}

#endif 

#ifndef OMITGOOD


void goodG2BSink();
void goodB2GSink();


static void goodG2B()
{
    char * data;
    
    data = NULL;
    
    data = new char[100];
    goodG2BData = data;
    goodG2BSink();
}


static void goodB2G()
{
    char * data;
    
    data = NULL;
    
    data = new char;
    goodB2GData = data;
    goodB2GSink();
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_array_char_68; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
