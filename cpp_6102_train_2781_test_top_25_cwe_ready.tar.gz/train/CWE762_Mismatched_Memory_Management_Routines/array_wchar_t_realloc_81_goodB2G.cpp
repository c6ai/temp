

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_wchar_t_realloc_81.h"

namespace array_wchar_t_realloc_81
{

void array_wchar_t_realloc_81_goodB2G::action(wchar_t * data) const
{
    
    free(data);
}

}
#endif 
