

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_int64_t_calloc_82.h"

namespace array_int64_t_calloc_82
{

void array_int64_t_calloc_82_goodB2G::action(int64_t * data)
{
    
    free(data);
}

}
#endif 
