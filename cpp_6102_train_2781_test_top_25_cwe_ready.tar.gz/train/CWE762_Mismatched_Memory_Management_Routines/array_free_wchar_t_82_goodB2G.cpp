

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_free_wchar_t_82.h"

namespace array_free_wchar_t_82
{

void array_free_wchar_t_82_goodB2G::action(wchar_t * data)
{
    
    delete [] data;
}

}
#endif 
