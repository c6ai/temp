


#include "std_testcase.h"

namespace free_struct_53
{

#ifndef OMITBAD

void badSink_d(twoIntsStruct * data)
{
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(twoIntsStruct * data)
{
    
    free(data);
}


void goodB2GSink_d(twoIntsStruct * data)
{
    
    delete data;
}

#endif 

} 
