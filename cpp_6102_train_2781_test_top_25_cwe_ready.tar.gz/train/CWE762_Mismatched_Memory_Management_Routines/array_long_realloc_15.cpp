


#include "std_testcase.h"

namespace array_long_realloc_15
{

#ifndef OMITBAD

void bad()
{
    long * data;
    
    data = NULL;
    switch(6)
    {
    case 6:
        data = NULL;
        
        data = (long *)realloc(data, 100*sizeof(long));
        if (data == NULL) {exit(-1);}
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        delete [] data;
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    long * data;
    
    data = NULL;
    switch(6)
    {
    case 6:
        data = NULL;
        
        data = (long *)realloc(data, 100*sizeof(long));
        if (data == NULL) {exit(-1);}
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(8)
    {
    case 7:
        
        printLine("Benign, fixed string");
        break;
    default:
        
        free(data);
        break;
    }
}


static void goodB2G2()
{
    long * data;
    
    data = NULL;
    switch(6)
    {
    case 6:
        data = NULL;
        
        data = (long *)realloc(data, 100*sizeof(long));
        if (data == NULL) {exit(-1);}
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        free(data);
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}


static void goodG2B1()
{
    long * data;
    
    data = NULL;
    switch(5)
    {
    case 6:
        
        printLine("Benign, fixed string");
        break;
    default:
        
        data = new long[100];
        break;
    }
    switch(7)
    {
    case 7:
        
        delete [] data;
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}


static void goodG2B2()
{
    long * data;
    
    data = NULL;
    switch(6)
    {
    case 6:
        
        data = new long[100];
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        delete [] data;
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_long_realloc_15; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
