


#include "std_testcase.h"

namespace free_char_67
{

typedef struct _structType
{
    char * structFirst;
} structType;

#ifndef OMITBAD

void badSink(structType myStruct)
{
    char * data = myStruct.structFirst;
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct)
{
    char * data = myStruct.structFirst;
    
    free(data);
}


void goodB2GSink(structType myStruct)
{
    char * data = myStruct.structFirst;
    
    delete data;
}

#endif 

} 
