


#include "std_testcase.h"

namespace array_struct_malloc_66
{

#ifndef OMITBAD


void badSink(twoIntsStruct * dataArray[]);

void bad()
{
    twoIntsStruct * data;
    twoIntsStruct * dataArray[5];
    
    data = NULL;
    
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
    
    dataArray[2] = data;
    badSink(dataArray);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(twoIntsStruct * dataArray[]);

static void goodG2B()
{
    twoIntsStruct * data;
    twoIntsStruct * dataArray[5];
    
    data = NULL;
    
    data = new twoIntsStruct[100];
    dataArray[2] = data;
    goodG2BSink(dataArray);
}


void goodB2GSink(twoIntsStruct * dataArray[]);

static void goodB2G()
{
    twoIntsStruct * data;
    twoIntsStruct * dataArray[5];
    
    data = NULL;
    
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
    dataArray[2] = data;
    goodB2GSink(dataArray);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_struct_malloc_66; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
