


#include "std_testcase.h"

namespace array_long_malloc_17
{

#ifndef OMITBAD

void bad()
{
    int i,j;
    long * data;
    
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = (long *)malloc(100*sizeof(long));
        if (data == NULL) {exit(-1);}
    }
    for(j = 0; j < 1; j++)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int i,k;
    long * data;
    
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = (long *)malloc(100*sizeof(long));
        if (data == NULL) {exit(-1);}
    }
    for(k = 0; k < 1; k++)
    {
        
        free(data);
    }
}


static void goodG2B()
{
    int h,j;
    long * data;
    
    data = NULL;
    for(h = 0; h < 1; h++)
    {
        
        data = new long[100];
    }
    for(j = 0; j < 1; j++)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_long_malloc_17; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
