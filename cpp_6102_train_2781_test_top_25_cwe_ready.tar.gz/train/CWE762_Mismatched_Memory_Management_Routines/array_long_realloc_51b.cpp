


#include "std_testcase.h"

namespace array_long_realloc_51
{

#ifndef OMITBAD

void badSink(long * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(long * data)
{
    
    delete [] data;
}


void goodB2GSink(long * data)
{
    
    free(data);
}

#endif 

} 
