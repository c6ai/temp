

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_struct_malloc_83.h"

namespace array_struct_malloc_83
{
array_struct_malloc_83_bad::array_struct_malloc_83_bad(twoIntsStruct * dataCopy)
{
    data = dataCopy;
    
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
}

array_struct_malloc_83_bad::~array_struct_malloc_83_bad()
{
    
    delete [] data;
}
}
#endif 
