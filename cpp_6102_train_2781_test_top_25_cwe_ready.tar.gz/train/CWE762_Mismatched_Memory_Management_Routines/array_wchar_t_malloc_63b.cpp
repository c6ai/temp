


#include "std_testcase.h"

namespace array_wchar_t_malloc_63
{

#ifndef OMITBAD

void badSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    delete [] data;
}


void goodB2GSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    free(data);
}

#endif 

} 
