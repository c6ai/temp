

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_calloc_81.h"

namespace wchar_t_calloc_81
{

void wchar_t_calloc_81_goodG2B::action(wchar_t * data) const
{
    
    delete data;
}

}
#endif 
