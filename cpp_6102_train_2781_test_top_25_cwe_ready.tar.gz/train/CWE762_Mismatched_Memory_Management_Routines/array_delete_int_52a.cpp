


#include "std_testcase.h"

namespace array_delete_int_52
{

#ifndef OMITBAD


void badSink_b(int * data);

void bad()
{
    int * data;
    
    data = NULL;
    
    data = new int[100];
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(int * data);

static void goodG2B()
{
    int * data;
    
    data = NULL;
    
    data = new int;
    goodG2BSink_b(data);
}


void goodB2GSink_b(int * data);

static void goodB2G()
{
    int * data;
    
    data = NULL;
    
    data = new int[100];
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_delete_int_52; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
