

#ifndef OMITGOOD

#include "std_testcase.h"
#include "struct_realloc_81.h"

namespace struct_realloc_81
{

void struct_realloc_81_goodG2B::action(twoIntsStruct * data) const
{
    
    delete data;
}

}
#endif 
