


#include "std_testcase.h"

namespace wchar_t_calloc_43
{

#ifndef OMITBAD

void badSource(wchar_t * &data)
{
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
}

void bad()
{
    wchar_t * data;
    
    data = NULL;
    badSource(data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


static void goodG2BSource(wchar_t * &data)
{
    
    data = new wchar_t;
}

static void goodG2B()
{
    wchar_t * data;
    
    data = NULL;
    goodG2BSource(data);
    
    delete data;
}


static void goodB2GSource(wchar_t * &data)
{
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
}

static void goodB2G()
{
    wchar_t * data;
    
    data = NULL;
    goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_calloc_43; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
