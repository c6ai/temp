


#include "std_testcase.h"

namespace array_int_malloc_63
{

#ifndef OMITBAD

void badSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    delete [] data;
}


void goodB2GSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    free(data);
}

#endif 

} 
