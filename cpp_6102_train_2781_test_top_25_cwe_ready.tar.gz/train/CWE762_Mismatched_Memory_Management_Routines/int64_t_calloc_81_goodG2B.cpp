

#ifndef OMITGOOD

#include "std_testcase.h"
#include "int64_t_calloc_81.h"

namespace int64_t_calloc_81
{

void int64_t_calloc_81_goodG2B::action(int64_t * data) const
{
    
    delete data;
}

}
#endif 
