


#include "std_testcase.h"

namespace array_free_int64_t_22
{

#ifndef OMITBAD


int badGlobal = 0;

void badSink(int64_t * data);

void bad()
{
    int64_t * data;
    
    data = NULL;
    
    data = new int64_t[100];
    badGlobal = 1; 
    badSink(data);
}

#endif 

#ifndef OMITGOOD


int goodB2G1Global = 0;
int goodB2G2Global = 0;
int goodG2B1Global = 0;


void goodB2G1Sink(int64_t * data);

static void goodB2G1()
{
    int64_t * data;
    
    data = NULL;
    
    data = new int64_t[100];
    goodB2G1Global = 0; 
    goodB2G1Sink(data);
}


void goodB2G2Sink(int64_t * data);

static void goodB2G2()
{
    int64_t * data;
    
    data = NULL;
    
    data = new int64_t[100];
    goodB2G2Global = 1; 
    goodB2G2Sink(data);
}


void goodG2B1Sink(int64_t * data);

static void goodG2B1()
{
    int64_t * data;
    
    data = NULL;
    
    data = (int64_t *)malloc(100*sizeof(int64_t));
    goodG2B1Global = 1; 
    goodG2B1Sink(data);
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_int64_t_22; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
