


#include "std_testcase.h"

namespace struct_calloc_54
{

#ifndef OMITBAD

void badSink_e(twoIntsStruct * data)
{
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(twoIntsStruct * data)
{
    
    delete data;
}


void goodB2GSink_e(twoIntsStruct * data)
{
    
    free(data);
}

#endif 

} 
