


#include "std_testcase.h"

namespace array_delete_long_33
{

#ifndef OMITBAD

void bad()
{
    long * data;
    long * &dataRef = data;
    
    data = NULL;
    
    data = new long[100];
    {
        long * data = dataRef;
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    long * data;
    long * &dataRef = data;
    
    data = NULL;
    
    data = new long;
    {
        long * data = dataRef;
        
        delete data;
    }
}


static void goodB2G()
{
    long * data;
    long * &dataRef = data;
    
    data = NULL;
    
    data = new long[100];
    {
        long * data = dataRef;
        
        delete [] data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_delete_long_33; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
