


#include "std_testcase.h"

namespace array_int_malloc_09
{

#ifndef OMITBAD

void bad()
{
    int * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = (int *)malloc(100*sizeof(int));
        if (data == NULL) {exit(-1);}
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    int * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = (int *)malloc(100*sizeof(int));
        if (data == NULL) {exit(-1);}
    }
    if(GLOBAL_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


static void goodB2G2()
{
    int * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = (int *)malloc(100*sizeof(int));
        if (data == NULL) {exit(-1);}
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        free(data);
    }
}


static void goodG2B1()
{
    int * data;
    
    data = NULL;
    if(GLOBAL_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new int[100];
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete [] data;
    }
}


static void goodG2B2()
{
    int * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = new int[100];
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_malloc_09; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
