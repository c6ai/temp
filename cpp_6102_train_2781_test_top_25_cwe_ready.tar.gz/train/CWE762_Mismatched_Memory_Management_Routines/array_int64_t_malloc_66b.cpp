


#include "std_testcase.h"

namespace array_int64_t_malloc_66
{

#ifndef OMITBAD

void badSink(int64_t * dataArray[])
{
    
    int64_t * data = dataArray[2];
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int64_t * dataArray[])
{
    int64_t * data = dataArray[2];
    
    delete [] data;
}


void goodB2GSink(int64_t * dataArray[])
{
    int64_t * data = dataArray[2];
    
    free(data);
}

#endif 

} 
