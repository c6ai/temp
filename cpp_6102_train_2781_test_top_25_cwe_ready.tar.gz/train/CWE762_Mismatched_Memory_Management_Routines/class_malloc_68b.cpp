


#include "std_testcase.h"

namespace class_malloc_68
{

extern TwoIntsClass * badData;
extern TwoIntsClass * goodG2BData;
extern TwoIntsClass * goodB2GData;

#ifndef OMITBAD

void badSink()
{
    TwoIntsClass * data = badData;
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink()
{
    TwoIntsClass * data = goodG2BData;
    
    delete data;
}


void goodB2GSink()
{
    TwoIntsClass * data = goodB2GData;
    
    free(data);
}

#endif 

} 
