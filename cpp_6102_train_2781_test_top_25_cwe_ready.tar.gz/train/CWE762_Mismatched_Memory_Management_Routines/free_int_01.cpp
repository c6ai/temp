


#include "std_testcase.h"

namespace free_int_01
{

#ifndef OMITBAD

void bad()
{
    int * data;
    
    data = NULL;
    
    data = new int;
    
    free(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int * data;
    
    data = NULL;
    
    data = (int *)malloc(100*sizeof(int));
    if (data == NULL) {exit(-1);}
    
    free(data);
}


static void goodB2G()
{
    int * data;
    
    data = NULL;
    
    data = new int;
    
    delete data;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace free_int_01; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
