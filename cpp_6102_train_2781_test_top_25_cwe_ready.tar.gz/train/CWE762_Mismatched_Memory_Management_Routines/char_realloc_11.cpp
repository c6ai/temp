


#include "std_testcase.h"

namespace char_realloc_11
{

#ifndef OMITBAD

void bad()
{
    char * data;
    
    data = NULL;
    if(globalReturnsTrue())
    {
        data = NULL;
        
        data = (char *)realloc(data, 100*sizeof(char));
        if (data == NULL) {exit(-1);}
    }
    if(globalReturnsTrue())
    {
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    char * data;
    
    data = NULL;
    if(globalReturnsTrue())
    {
        data = NULL;
        
        data = (char *)realloc(data, 100*sizeof(char));
        if (data == NULL) {exit(-1);}
    }
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


static void goodB2G2()
{
    char * data;
    
    data = NULL;
    if(globalReturnsTrue())
    {
        data = NULL;
        
        data = (char *)realloc(data, 100*sizeof(char));
        if (data == NULL) {exit(-1);}
    }
    if(globalReturnsTrue())
    {
        
        free(data);
    }
}


static void goodG2B1()
{
    char * data;
    
    data = NULL;
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new char;
    }
    if(globalReturnsTrue())
    {
        
        delete data;
    }
}


static void goodG2B2()
{
    char * data;
    
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new char;
    }
    if(globalReturnsTrue())
    {
        
        delete data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_realloc_11; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
