


#include "std_testcase.h"

namespace free_long_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(long * data)
{
    if(badGlobal)
    {
        
        free(data);
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(long * data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


void goodB2G2Sink(long * data)
{
    if(goodB2G2Global)
    {
        
        delete data;
    }
}


void goodG2B1Sink(long * data)
{
    if(goodG2B1Global)
    {
        
        free(data);
    }
}

#endif 

} 
