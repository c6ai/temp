


#include "std_testcase.h"

namespace array_struct_calloc_14
{

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    
    data = NULL;
    if(globalFive==5)
    {
        
        data = (twoIntsStruct *)calloc(100, sizeof(twoIntsStruct));
        if (data == NULL) {exit(-1);}
    }
    if(globalFive==5)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    twoIntsStruct * data;
    
    data = NULL;
    if(globalFive==5)
    {
        
        data = (twoIntsStruct *)calloc(100, sizeof(twoIntsStruct));
        if (data == NULL) {exit(-1);}
    }
    if(globalFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


static void goodB2G2()
{
    twoIntsStruct * data;
    
    data = NULL;
    if(globalFive==5)
    {
        
        data = (twoIntsStruct *)calloc(100, sizeof(twoIntsStruct));
        if (data == NULL) {exit(-1);}
    }
    if(globalFive==5)
    {
        
        free(data);
    }
}


static void goodG2B1()
{
    twoIntsStruct * data;
    
    data = NULL;
    if(globalFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new twoIntsStruct[100];
    }
    if(globalFive==5)
    {
        
        delete [] data;
    }
}


static void goodG2B2()
{
    twoIntsStruct * data;
    
    data = NULL;
    if(globalFive==5)
    {
        
        data = new twoIntsStruct[100];
    }
    if(globalFive==5)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_struct_calloc_14; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
