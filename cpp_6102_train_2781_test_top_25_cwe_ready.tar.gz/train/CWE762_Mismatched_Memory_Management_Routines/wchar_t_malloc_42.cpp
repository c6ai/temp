


#include "std_testcase.h"

namespace wchar_t_malloc_42
{

#ifndef OMITBAD

static wchar_t * badSource(wchar_t * data)
{
    
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
    return data;
}

void bad()
{
    wchar_t * data;
    
    data = NULL;
    data = badSource(data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


static wchar_t * goodG2BSource(wchar_t * data)
{
    
    data = new wchar_t;
    return data;
}

static void goodG2B()
{
    wchar_t * data;
    
    data = NULL;
    data = goodG2BSource(data);
    
    delete data;
}


static wchar_t * goodB2GSource(wchar_t * data)
{
    
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    if (data == NULL) {exit(-1);}
    return data;
}

static void goodB2G()
{
    wchar_t * data;
    
    data = NULL;
    data = goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_malloc_42; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
