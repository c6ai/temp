


#include "std_testcase.h"

namespace array_delete_char_33
{

#ifndef OMITBAD

void bad()
{
    char * data;
    char * &dataRef = data;
    
    data = NULL;
    
    data = new char[100];
    {
        char * data = dataRef;
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    char * data;
    char * &dataRef = data;
    
    data = NULL;
    
    data = new char;
    {
        char * data = dataRef;
        
        delete data;
    }
}


static void goodB2G()
{
    char * data;
    char * &dataRef = data;
    
    data = NULL;
    
    data = new char[100];
    {
        char * data = dataRef;
        
        delete [] data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_delete_char_33; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
