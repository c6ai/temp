

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_int_realloc_82.h"

namespace array_int_realloc_82
{

void array_int_realloc_82_bad::action(int * data)
{
    
    delete [] data;
}

}
#endif 
