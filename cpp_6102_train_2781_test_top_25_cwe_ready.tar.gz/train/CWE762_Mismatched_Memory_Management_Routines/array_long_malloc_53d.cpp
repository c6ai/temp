


#include "std_testcase.h"

namespace array_long_malloc_53
{

#ifndef OMITBAD

void badSink_d(long * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(long * data)
{
    
    delete [] data;
}


void goodB2GSink_d(long * data)
{
    
    free(data);
}

#endif 

} 
