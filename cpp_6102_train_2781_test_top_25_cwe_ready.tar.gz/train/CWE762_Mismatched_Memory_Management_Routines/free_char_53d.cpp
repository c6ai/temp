


#include "std_testcase.h"

namespace free_char_53
{

#ifndef OMITBAD

void badSink_d(char * data)
{
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(char * data)
{
    
    free(data);
}


void goodB2GSink_d(char * data)
{
    
    delete data;
}

#endif 

} 
