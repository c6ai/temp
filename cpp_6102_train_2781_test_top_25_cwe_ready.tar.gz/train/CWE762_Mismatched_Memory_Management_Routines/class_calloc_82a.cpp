


#include "std_testcase.h"
#include "class_calloc_82.h"

namespace class_calloc_82
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    
    data = (TwoIntsClass *)calloc(100, sizeof(TwoIntsClass));
    if (data == NULL) {exit(-1);}
    class_calloc_82_base* baseObject = new class_calloc_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    TwoIntsClass * data;
    
    data = NULL;
    
    data = new TwoIntsClass;
    class_calloc_82_base* baseObject = new class_calloc_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    TwoIntsClass * data;
    
    data = NULL;
    
    data = (TwoIntsClass *)calloc(100, sizeof(TwoIntsClass));
    if (data == NULL) {exit(-1);}
    class_calloc_82_base* baseObject = new class_calloc_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace class_calloc_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
