


#include "std_testcase.h"

namespace array_wchar_t_malloc_53
{

#ifndef OMITBAD

void badSink_d(wchar_t * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(wchar_t * data)
{
    
    delete [] data;
}


void goodB2GSink_d(wchar_t * data)
{
    
    free(data);
}

#endif 

} 
