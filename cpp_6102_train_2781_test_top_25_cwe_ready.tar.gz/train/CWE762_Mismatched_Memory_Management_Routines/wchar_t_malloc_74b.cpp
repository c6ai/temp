


#include "std_testcase.h"
#include <map>

using namespace std;

namespace wchar_t_malloc_74
{

#ifndef OMITBAD

void badSink(map<int, wchar_t *> dataMap)
{
    
    wchar_t * data = dataMap[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    
    delete data;
}


void goodB2GSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    
    free(data);
}

#endif 

} 
