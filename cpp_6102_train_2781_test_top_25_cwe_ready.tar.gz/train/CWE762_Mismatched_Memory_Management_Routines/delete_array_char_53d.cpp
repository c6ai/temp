


#include "std_testcase.h"

namespace delete_array_char_53
{

#ifndef OMITBAD

void badSink_d(char * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(char * data)
{
    
    delete [] data;
}


void goodB2GSink_d(char * data)
{
    
    delete data;
}

#endif 

} 
