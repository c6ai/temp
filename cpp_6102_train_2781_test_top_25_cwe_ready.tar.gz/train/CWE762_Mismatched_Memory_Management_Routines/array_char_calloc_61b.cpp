


#include "std_testcase.h"

namespace array_char_calloc_61
{

#ifndef OMITBAD

char * badSource(char * data)
{
    
    data = (char *)calloc(100, sizeof(char));
    if (data == NULL) {exit(-1);}
    return data;
}

#endif 

#ifndef OMITGOOD


char * goodG2BSource(char * data)
{
    
    data = new char[100];
    return data;
}


char * goodB2GSource(char * data)
{
    
    data = (char *)calloc(100, sizeof(char));
    if (data == NULL) {exit(-1);}
    return data;
}

#endif 

} 
