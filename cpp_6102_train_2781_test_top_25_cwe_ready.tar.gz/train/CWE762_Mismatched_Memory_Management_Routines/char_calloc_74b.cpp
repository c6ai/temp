


#include "std_testcase.h"
#include <map>

using namespace std;

namespace char_calloc_74
{

#ifndef OMITBAD

void badSink(map<int, char *> dataMap)
{
    
    char * data = dataMap[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, char *> dataMap)
{
    char * data = dataMap[2];
    
    delete data;
}


void goodB2GSink(map<int, char *> dataMap)
{
    char * data = dataMap[2];
    
    free(data);
}

#endif 

} 
