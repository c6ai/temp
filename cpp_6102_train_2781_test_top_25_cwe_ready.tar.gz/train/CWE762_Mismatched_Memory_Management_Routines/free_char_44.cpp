


#include "std_testcase.h"

namespace free_char_44
{

#ifndef OMITBAD

static void badSink(char * data)
{
    
    free(data);
}

void bad()
{
    char * data;
    
    void (*funcPtr) (char *) = badSink;
    
    data = NULL;
    
    data = new char;
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(char * data)
{
    
    free(data);
}

static void goodG2B()
{
    char * data;
    void (*funcPtr) (char *) = goodG2BSink;
    
    data = NULL;
    
    data = (char *)malloc(100*sizeof(char));
    if (data == NULL) {exit(-1);}
    funcPtr(data);
}


static void goodB2GSink(char * data)
{
    
    delete data;
}

static void goodB2G()
{
    char * data;
    void (*funcPtr) (char *) = goodB2GSink;
    
    data = NULL;
    
    data = new char;
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace free_char_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
