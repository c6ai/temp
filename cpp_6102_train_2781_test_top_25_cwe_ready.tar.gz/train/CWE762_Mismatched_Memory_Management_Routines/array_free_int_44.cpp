


#include "std_testcase.h"

namespace array_free_int_44
{

#ifndef OMITBAD

static void badSink(int * data)
{
    
    free(data);
}

void bad()
{
    int * data;
    
    void (*funcPtr) (int *) = badSink;
    
    data = NULL;
    
    data = new int[100];
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(int * data)
{
    
    free(data);
}

static void goodG2B()
{
    int * data;
    void (*funcPtr) (int *) = goodG2BSink;
    
    data = NULL;
    
    data = (int *)malloc(100*sizeof(int));
    if (data == NULL) {exit(-1);}
    funcPtr(data);
}


static void goodB2GSink(int * data)
{
    
    delete [] data;
}

static void goodB2G()
{
    int * data;
    void (*funcPtr) (int *) = goodB2GSink;
    
    data = NULL;
    
    data = new int[100];
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_int_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
