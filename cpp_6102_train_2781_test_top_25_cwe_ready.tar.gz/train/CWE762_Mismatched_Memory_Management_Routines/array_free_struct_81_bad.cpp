

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_free_struct_81.h"

namespace array_free_struct_81
{

void array_free_struct_81_bad::action(twoIntsStruct * data) const
{
    
    free(data);
}

}
#endif 
