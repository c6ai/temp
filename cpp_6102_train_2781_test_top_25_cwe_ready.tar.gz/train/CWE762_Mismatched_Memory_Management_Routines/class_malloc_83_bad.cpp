

#ifndef OMITBAD

#include "std_testcase.h"
#include "class_malloc_83.h"

namespace class_malloc_83
{
class_malloc_83_bad::class_malloc_83_bad(TwoIntsClass * dataCopy)
{
    data = dataCopy;
    
    data = (TwoIntsClass *)malloc(100*sizeof(TwoIntsClass));
}

class_malloc_83_bad::~class_malloc_83_bad()
{
    
    delete data;
}
}
#endif 
