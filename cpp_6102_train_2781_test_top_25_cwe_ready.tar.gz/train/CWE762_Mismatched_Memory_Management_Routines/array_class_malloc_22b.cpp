


#include "std_testcase.h"

namespace array_class_malloc_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(TwoIntsClass * data)
{
    if(badGlobal)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(TwoIntsClass * data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


void goodB2G2Sink(TwoIntsClass * data)
{
    if(goodB2G2Global)
    {
        
        free(data);
    }
}


void goodG2B1Sink(TwoIntsClass * data)
{
    if(goodG2B1Global)
    {
        
        delete [] data;
    }
}

#endif 

} 
