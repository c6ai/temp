

#ifndef OMITGOOD

#include "std_testcase.h"
#include "free_long_82.h"

namespace free_long_82
{

void free_long_82_goodB2G::action(long * data)
{
    
    delete data;
}

}
#endif 
