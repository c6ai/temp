


#include "std_testcase.h"
#include <vector>

using namespace std;

namespace delete_array_int_72
{

#ifndef OMITBAD

void badSink(vector<int *> dataVector)
{
    
    int * data = dataVector[2];
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<int *> dataVector)
{
    int * data = dataVector[2];
    
    delete [] data;
}


void goodB2GSink(vector<int *> dataVector)
{
    int * data = dataVector[2];
    
    delete data;
}

#endif 

} 
