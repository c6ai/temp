

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_free_class_83.h"

namespace array_free_class_83
{
array_free_class_83_goodB2G::array_free_class_83_goodB2G(TwoIntsClass * dataCopy)
{
    data = dataCopy;
    
    data = new TwoIntsClass[100];
}

array_free_class_83_goodB2G::~array_free_class_83_goodB2G()
{
    
    delete [] data;
}
}
#endif 
