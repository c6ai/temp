


#include "std_testcase.h"

namespace free_long_41
{

#ifndef OMITBAD

static void badSink(long * data)
{
    
    free(data);
}

void bad()
{
    long * data;
    
    data = NULL;
    
    data = new long;
    badSink(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(long * data)
{
    
    free(data);
}

static void goodG2B()
{
    long * data;
    
    data = NULL;
    
    data = (long *)malloc(100*sizeof(long));
    if (data == NULL) {exit(-1);}
    goodG2BSink(data);
}


static void goodB2GSink(long * data)
{
    
    delete data;
}

static void goodB2G()
{
    long * data;
    
    data = NULL;
    
    data = new long;
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace free_long_41; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
