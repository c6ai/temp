


#include "std_testcase.h"

#include <wchar.h>

namespace delete_array_char_66
{

#ifndef OMITBAD


void badSink(char * dataArray[]);

void bad()
{
    char * data;
    char * dataArray[5];
    
    data = NULL;
    {
        char myString[] = "myString";
        
        data = strdup(myString);
    }
    
    dataArray[2] = data;
    badSink(dataArray);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * dataArray[]);

static void goodG2B()
{
    char * data;
    char * dataArray[5];
    
    data = NULL;
    
    data = new char[100];
    dataArray[2] = data;
    goodG2BSink(dataArray);
}


void goodB2GSink(char * dataArray[]);

static void goodB2G()
{
    char * data;
    char * dataArray[5];
    
    data = NULL;
    {
        char myString[] = "myString";
        
        data = strdup(myString);
    }
    dataArray[2] = data;
    goodB2GSink(dataArray);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_array_char_66; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
