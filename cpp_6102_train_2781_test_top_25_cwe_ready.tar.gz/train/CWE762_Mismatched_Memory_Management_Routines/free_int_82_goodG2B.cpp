

#ifndef OMITGOOD

#include "std_testcase.h"
#include "free_int_82.h"

namespace free_int_82
{

void free_int_82_goodG2B::action(int * data)
{
    
    free(data);
}

}
#endif 
