


#include "std_testcase.h"

namespace array_struct_realloc_68
{

twoIntsStruct * badData;
twoIntsStruct * goodG2BData;
twoIntsStruct * goodB2GData;

#ifndef OMITBAD


void badSink();

void bad()
{
    twoIntsStruct * data;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    badData = data;
    badSink();
}

#endif 

#ifndef OMITGOOD


void goodG2BSink();
void goodB2GSink();


static void goodG2B()
{
    twoIntsStruct * data;
    
    data = NULL;
    
    data = new twoIntsStruct[100];
    goodG2BData = data;
    goodG2BSink();
}


static void goodB2G()
{
    twoIntsStruct * data;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    goodB2GData = data;
    goodB2GSink();
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_struct_realloc_68; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
