


#include "std_testcase.h"

namespace array_long_realloc_51
{

#ifndef OMITBAD


void badSink(long * data);

void bad()
{
    long * data;
    
    data = NULL;
    data = NULL;
    
    data = (long *)realloc(data, 100*sizeof(long));
    badSink(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(long * data);
void goodB2GSink(long * data);


static void goodG2B()
{
    long * data;
    
    data = NULL;
    
    data = new long[100];
    goodG2BSink(data);
}


static void goodB2G()
{
    long * data;
    
    data = NULL;
    data = NULL;
    
    data = (long *)realloc(data, 100*sizeof(long));
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_long_realloc_51; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
