

#ifndef OMITGOOD

#include "std_testcase.h"
#include "int_calloc_81.h"

namespace int_calloc_81
{

void int_calloc_81_goodG2B::action(int * data) const
{
    
    delete data;
}

}
#endif 
