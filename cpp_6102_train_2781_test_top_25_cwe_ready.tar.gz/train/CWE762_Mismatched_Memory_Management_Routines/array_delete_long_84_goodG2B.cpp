

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_delete_long_84.h"

namespace array_delete_long_84
{
array_delete_long_84_goodG2B::array_delete_long_84_goodG2B(long * dataCopy)
{
    data = dataCopy;
    
    data = new long;
}

array_delete_long_84_goodG2B::~array_delete_long_84_goodG2B()
{
    
    delete data;
}
}
#endif 
