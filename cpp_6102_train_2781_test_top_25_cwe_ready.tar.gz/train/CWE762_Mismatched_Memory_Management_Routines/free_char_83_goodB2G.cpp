

#ifndef OMITGOOD

#include "std_testcase.h"
#include "free_char_83.h"

namespace free_char_83
{
free_char_83_goodB2G::free_char_83_goodB2G(char * dataCopy)
{
    data = dataCopy;
    
    data = new char;
}

free_char_83_goodB2G::~free_char_83_goodB2G()
{
    
    delete data;
}
}
#endif 
