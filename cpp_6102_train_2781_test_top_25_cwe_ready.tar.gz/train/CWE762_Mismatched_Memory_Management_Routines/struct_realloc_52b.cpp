


#include "std_testcase.h"

namespace struct_realloc_52
{

#ifndef OMITBAD


void badSink_c(twoIntsStruct * data);

void badSink_b(twoIntsStruct * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(twoIntsStruct * data);

void goodG2BSink_b(twoIntsStruct * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(twoIntsStruct * data);

void goodB2GSink_b(twoIntsStruct * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
