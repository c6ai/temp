


#include "std_testcase.h"

namespace array_class_realloc_31
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = NULL;
    
    data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
    if (data == NULL) {exit(-1);}
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    TwoIntsClass * data;
    
    data = NULL;
    
    data = new TwoIntsClass[100];
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        delete [] data;
    }
}


static void goodB2G()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = NULL;
    
    data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
    if (data == NULL) {exit(-1);}
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        free(data);
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_class_realloc_31; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
