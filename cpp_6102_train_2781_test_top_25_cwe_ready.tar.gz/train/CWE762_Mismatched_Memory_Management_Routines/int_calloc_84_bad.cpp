

#ifndef OMITBAD

#include "std_testcase.h"
#include "int_calloc_84.h"

namespace int_calloc_84
{
int_calloc_84_bad::int_calloc_84_bad(int * dataCopy)
{
    data = dataCopy;
    
    data = (int *)calloc(100, sizeof(int));
}

int_calloc_84_bad::~int_calloc_84_bad()
{
    
    delete data;
}
}
#endif 
