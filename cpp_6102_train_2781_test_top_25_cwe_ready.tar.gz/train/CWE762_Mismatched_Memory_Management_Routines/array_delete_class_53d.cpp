


#include "std_testcase.h"

namespace array_delete_class_53
{

#ifndef OMITBAD

void badSink_d(TwoIntsClass * data)
{
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(TwoIntsClass * data)
{
    
    delete data;
}


void goodB2GSink_d(TwoIntsClass * data)
{
    
    delete [] data;
}

#endif 

} 
