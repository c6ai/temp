


#include "std_testcase.h"

#include <wchar.h>

namespace delete_array_char_51
{

#ifndef OMITBAD

void badSink(char * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * data)
{
    
    delete [] data;
}


void goodB2GSink(char * data)
{
    
    free(data);
}

#endif 

} 
