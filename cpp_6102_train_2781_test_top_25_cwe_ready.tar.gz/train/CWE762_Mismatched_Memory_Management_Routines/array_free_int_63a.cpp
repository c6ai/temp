


#include "std_testcase.h"

namespace array_free_int_63
{

#ifndef OMITBAD


void badSink(int * * dataPtr);

void bad()
{
    int * data;
    
    data = NULL;
    
    data = new int[100];
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * * data);

static void goodG2B()
{
    int * data;
    
    data = NULL;
    
    data = (int *)malloc(100*sizeof(int));
    goodG2BSink(&data);
}


void goodB2GSink(int * * data);

static void goodB2G()
{
    int * data;
    
    data = NULL;
    
    data = new int[100];
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_int_63; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
