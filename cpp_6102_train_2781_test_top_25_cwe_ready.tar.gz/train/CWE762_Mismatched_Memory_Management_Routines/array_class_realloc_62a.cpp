


#include "std_testcase.h"

namespace array_class_realloc_62
{

#ifndef OMITBAD


void badSource(TwoIntsClass * &data);

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    badSource(data);
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(TwoIntsClass * &data);

static void goodG2B()
{
    TwoIntsClass * data;
    
    data = NULL;
    goodG2BSource(data);
    
    delete [] data;
}


void goodB2GSource(TwoIntsClass * &data);

static void goodB2G()
{
    TwoIntsClass * data;
    
    data = NULL;
    goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_class_realloc_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
