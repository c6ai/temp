


#include "std_testcase.h"

namespace free_int_67
{

typedef struct _structType
{
    int * structFirst;
} structType;

#ifndef OMITBAD

void badSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    free(data);
}


void goodB2GSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    delete data;
}

#endif 

} 
