

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_delete_long_81.h"

namespace array_delete_long_81
{

void array_delete_long_81_bad::action(long * data) const
{
    
    delete data;
}

}
#endif 
