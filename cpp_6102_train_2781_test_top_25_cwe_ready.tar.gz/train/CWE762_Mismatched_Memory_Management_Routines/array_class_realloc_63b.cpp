


#include "std_testcase.h"

namespace array_class_realloc_63
{

#ifndef OMITBAD

void badSink(TwoIntsClass * * dataPtr)
{
    TwoIntsClass * data = *dataPtr;
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(TwoIntsClass * * dataPtr)
{
    TwoIntsClass * data = *dataPtr;
    
    delete [] data;
}


void goodB2GSink(TwoIntsClass * * dataPtr)
{
    TwoIntsClass * data = *dataPtr;
    
    free(data);
}

#endif 

} 
