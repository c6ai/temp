


#include "std_testcase.h"

namespace array_int64_t_malloc_17
{

#ifndef OMITBAD

void bad()
{
    int i,j;
    int64_t * data;
    
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = (int64_t *)malloc(100*sizeof(int64_t));
        if (data == NULL) {exit(-1);}
    }
    for(j = 0; j < 1; j++)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int i,k;
    int64_t * data;
    
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = (int64_t *)malloc(100*sizeof(int64_t));
        if (data == NULL) {exit(-1);}
    }
    for(k = 0; k < 1; k++)
    {
        
        free(data);
    }
}


static void goodG2B()
{
    int h,j;
    int64_t * data;
    
    data = NULL;
    for(h = 0; h < 1; h++)
    {
        
        data = new int64_t[100];
    }
    for(j = 0; j < 1; j++)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int64_t_malloc_17; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
