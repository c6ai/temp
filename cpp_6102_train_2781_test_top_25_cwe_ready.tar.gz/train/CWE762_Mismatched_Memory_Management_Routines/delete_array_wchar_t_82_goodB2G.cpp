

#ifndef OMITGOOD

#include "std_testcase.h"
#include "delete_array_wchar_t_82.h"

namespace delete_array_wchar_t_82
{

void delete_array_wchar_t_82_goodB2G::action(wchar_t * data)
{
    
    free(data);
}

}
#endif 
