


#include "std_testcase.h"

namespace delete_array_int64_t_34
{

typedef union
{
    int64_t * unionFirst;
    int64_t * unionSecond;
} unionType;

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new int64_t;
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int64_t * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new int64_t[100];
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
        
        delete [] data;
    }
}


static void goodB2G()
{
    int64_t * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new int64_t;
    myUnion.unionFirst = data;
    {
        int64_t * data = myUnion.unionSecond;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace delete_array_int64_t_34; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
