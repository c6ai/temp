


#include "std_testcase.h"

namespace array_long_malloc_54
{

#ifndef OMITBAD


void badSink_b(long * data);

void bad()
{
    long * data;
    
    data = NULL;
    
    data = (long *)malloc(100*sizeof(long));
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(long * data);

static void goodG2B()
{
    long * data;
    
    data = NULL;
    
    data = new long[100];
    goodG2BSink_b(data);
}


void goodB2GSink_b(long * data);

static void goodB2G()
{
    long * data;
    
    data = NULL;
    
    data = (long *)malloc(100*sizeof(long));
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_long_malloc_54; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
