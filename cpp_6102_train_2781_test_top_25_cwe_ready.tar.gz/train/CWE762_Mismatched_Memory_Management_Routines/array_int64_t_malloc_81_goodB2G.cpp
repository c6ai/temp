

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_int64_t_malloc_81.h"

namespace array_int64_t_malloc_81
{

void array_int64_t_malloc_81_goodB2G::action(int64_t * data) const
{
    
    free(data);
}

}
#endif 
