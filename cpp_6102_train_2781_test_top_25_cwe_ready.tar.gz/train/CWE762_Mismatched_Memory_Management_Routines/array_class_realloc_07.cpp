


#include "std_testcase.h"


static int staticFive = 5;

namespace array_class_realloc_07
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(staticFive==5)
    {
        data = NULL;
        
        data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(staticFive==5)
    {
        data = NULL;
        
        data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


static void goodB2G2()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(staticFive==5)
    {
        data = NULL;
        
        data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
    }
    if(staticFive==5)
    {
        
        free(data);
    }
}


static void goodG2B1()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new TwoIntsClass[100];
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}


static void goodG2B2()
{
    TwoIntsClass * data;
    
    data = NULL;
    if(staticFive==5)
    {
        
        data = new TwoIntsClass[100];
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_class_realloc_07; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
