


#include "std_testcase.h"

namespace free_class_65
{

#ifndef OMITBAD

void badSink(TwoIntsClass * data)
{
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(TwoIntsClass * data)
{
    
    free(data);
}


void goodB2GSink(TwoIntsClass * data)
{
    
    delete data;
}

#endif 

} 
