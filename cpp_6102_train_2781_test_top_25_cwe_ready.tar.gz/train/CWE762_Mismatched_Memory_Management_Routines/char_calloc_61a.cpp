


#include "std_testcase.h"

namespace char_calloc_61
{

#ifndef OMITBAD


char * badSource(char * data);

void bad()
{
    char * data;
    
    data = NULL;
    data = badSource(data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


char * goodG2BSource(char * data);

static void goodG2B()
{
    char * data;
    
    data = NULL;
    data = goodG2BSource(data);
    
    delete data;
}


char * goodB2GSource(char * data);

static void goodB2G()
{
    char * data;
    
    data = NULL;
    data = goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_calloc_61; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
