


#include "std_testcase.h"

namespace array_char_malloc_64
{

#ifndef OMITBAD

void badSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    delete [] data;
}


void goodB2GSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    free(data);
}

#endif 

} 
