


#include "std_testcase.h"

namespace free_struct_54
{

#ifndef OMITBAD


void badSink_e(twoIntsStruct * data);

void badSink_d(twoIntsStruct * data)
{
    badSink_e(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(twoIntsStruct * data);

void goodG2BSink_d(twoIntsStruct * data)
{
    goodG2BSink_e(data);
}


void goodB2GSink_e(twoIntsStruct * data);

void goodB2GSink_d(twoIntsStruct * data)
{
    goodB2GSink_e(data);
}

#endif 

} 
