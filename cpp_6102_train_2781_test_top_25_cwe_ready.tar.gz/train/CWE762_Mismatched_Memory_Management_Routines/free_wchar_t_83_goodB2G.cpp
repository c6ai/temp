

#ifndef OMITGOOD

#include "std_testcase.h"
#include "free_wchar_t_83.h"

namespace free_wchar_t_83
{
free_wchar_t_83_goodB2G::free_wchar_t_83_goodB2G(wchar_t * dataCopy)
{
    data = dataCopy;
    
    data = new wchar_t;
}

free_wchar_t_83_goodB2G::~free_wchar_t_83_goodB2G()
{
    
    delete data;
}
}
#endif 
