

#ifndef OMITBAD

#include "std_testcase.h"
#include "free_int64_t_84.h"

namespace free_int64_t_84
{
free_int64_t_84_bad::free_int64_t_84_bad(int64_t * dataCopy)
{
    data = dataCopy;
    
    data = new int64_t;
}

free_int64_t_84_bad::~free_int64_t_84_bad()
{
    
    free(data);
}
}
#endif 
