


#include "std_testcase.h"

namespace array_delete_long_09
{

#ifndef OMITBAD

void bad()
{
    long * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = new long[100];
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    long * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = new long[100];
    }
    if(GLOBAL_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete [] data;
    }
}


static void goodB2G2()
{
    long * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = new long[100];
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete [] data;
    }
}


static void goodG2B1()
{
    long * data;
    
    data = NULL;
    if(GLOBAL_CONST_FALSE)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new long;
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete data;
    }
}


static void goodG2B2()
{
    long * data;
    
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        
        data = new long;
    }
    if(GLOBAL_CONST_TRUE)
    {
        
        delete data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_delete_long_09; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
