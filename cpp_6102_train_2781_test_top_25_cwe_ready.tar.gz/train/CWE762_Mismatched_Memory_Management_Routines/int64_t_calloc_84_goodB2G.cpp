

#ifndef OMITGOOD

#include "std_testcase.h"
#include "int64_t_calloc_84.h"

namespace int64_t_calloc_84
{
int64_t_calloc_84_goodB2G::int64_t_calloc_84_goodB2G(int64_t * dataCopy)
{
    data = dataCopy;
    
    data = (int64_t *)calloc(100, sizeof(int64_t));
}

int64_t_calloc_84_goodB2G::~int64_t_calloc_84_goodB2G()
{
    
    free(data);
}
}
#endif 
