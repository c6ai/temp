


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_63
{

#ifndef OMITBAD


void badSink(size_t * dataPtr);

void bad()
{
    size_t data;
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(size_t * data);

static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    goodG2BSink(&data);
}


void goodB2GSink(size_t * data);

static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_fscanf_63; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
