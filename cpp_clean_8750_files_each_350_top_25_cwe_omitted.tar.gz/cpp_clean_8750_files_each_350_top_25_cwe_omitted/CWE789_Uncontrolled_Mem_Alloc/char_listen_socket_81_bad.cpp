

#ifndef OMITBAD

#include "std_testcase.h"
#include "char_listen_socket_81.h"

#define HELLO_STRING "hello"

namespace char_listen_socket_81
{

void char_listen_socket_81_bad::action(size_t data) const
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

}
#endif 
