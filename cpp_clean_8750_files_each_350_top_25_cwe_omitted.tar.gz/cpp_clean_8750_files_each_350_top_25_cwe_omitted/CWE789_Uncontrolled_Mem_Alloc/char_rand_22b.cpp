


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING "hello"

namespace char_rand_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(size_t data)
{
    if(badGlobal)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(size_t data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}


void goodB2G2Sink(size_t data)
{
    if(goodB2G2Global)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}


void goodG2B1Sink(size_t data)
{
    if(goodG2B1Global)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

#endif 

} 
