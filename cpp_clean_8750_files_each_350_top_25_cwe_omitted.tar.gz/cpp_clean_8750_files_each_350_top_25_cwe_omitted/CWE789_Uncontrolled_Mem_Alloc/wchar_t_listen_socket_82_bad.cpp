

#ifndef OMITBAD

#include "std_testcase.h"
#include "wchar_t_listen_socket_82.h"

#define HELLO_STRING L"hello"

namespace wchar_t_listen_socket_82
{

void wchar_t_listen_socket_82_bad::action(size_t data)
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

}
#endif 
