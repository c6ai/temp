

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_listen_socket_82.h"

#define HELLO_STRING "hello"

namespace char_listen_socket_82
{

void char_listen_socket_82_goodB2G::action(size_t data)
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

}
#endif 
