


#include "std_testcase.h"
#include <map>

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

using namespace std;

namespace wchar_t_connect_socket_74
{

#ifndef OMITBAD

void badSink(map<int, size_t> dataMap)
{
    
    size_t data = dataMap[2];
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, size_t> dataMap)
{
    size_t data = dataMap[2];
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}


void goodB2GSink(map<int, size_t> dataMap)
{
    size_t data = dataMap[2];
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

#endif 

} 
