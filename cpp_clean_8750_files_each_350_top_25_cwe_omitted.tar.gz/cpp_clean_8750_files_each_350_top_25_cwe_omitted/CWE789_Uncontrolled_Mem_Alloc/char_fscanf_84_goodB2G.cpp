

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_fscanf_84.h"

#define HELLO_STRING "hello"

namespace char_fscanf_84
{
char_fscanf_84_goodB2G::char_fscanf_84_goodB2G(size_t dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%ud", &data);
}

char_fscanf_84_goodB2G::~char_fscanf_84_goodB2G()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = (char *)malloc(data*sizeof(char));
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}
}
#endif 
