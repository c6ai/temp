


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING "hello"

namespace char_rand_51
{

#ifndef OMITBAD


void badSink(size_t data);

void bad()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    badSink(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(size_t data);
void goodB2GSink(size_t data);


static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    goodG2BSink(data);
}


static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_rand_51; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
