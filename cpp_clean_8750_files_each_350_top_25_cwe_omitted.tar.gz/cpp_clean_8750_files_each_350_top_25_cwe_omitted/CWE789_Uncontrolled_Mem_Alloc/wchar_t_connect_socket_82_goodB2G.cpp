

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_connect_socket_82.h"

#define HELLO_STRING L"hello"

namespace wchar_t_connect_socket_82
{

void wchar_t_connect_socket_82_goodB2G::action(size_t data)
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

}
#endif 
