


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_rand_62
{

#ifndef OMITBAD

void badSource(size_t &data)
{
    
    data = rand();
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(size_t &data)
{
    
    data = 20;
}


void goodB2GSource(size_t &data)
{
    
    data = rand();
}

#endif 

} 
