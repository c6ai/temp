

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_rand_81.h"

#define HELLO_STRING L"hello"

namespace wchar_t_rand_81
{

void wchar_t_rand_81_goodB2G::action(size_t data) const
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

}
#endif 
