

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_fgets_84.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING L"hello"

namespace wchar_t_fgets_84
{
wchar_t_fgets_84_goodG2B::wchar_t_fgets_84_goodG2B(size_t dataCopy)
{
    data = dataCopy;
    
    data = 20;
}

wchar_t_fgets_84_goodG2B::~wchar_t_fgets_84_goodG2B()
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
