


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING "hello"


static int staticFive = 5;

namespace char_fscanf_07
{

#ifndef OMITBAD

void bad()
{
    size_t data;
    
    data = 0;
    if(staticFive==5)
    {
        
        fscanf(stdin, "%zu", &data);
    }
    if(staticFive==5)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    size_t data;
    
    data = 0;
    if(staticFive==5)
    {
        
        fscanf(stdin, "%zu", &data);
    }
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}


static void goodB2G2()
{
    size_t data;
    
    data = 0;
    if(staticFive==5)
    {
        
        fscanf(stdin, "%zu", &data);
    }
    if(staticFive==5)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}


static void goodG2B1()
{
    size_t data;
    
    data = 0;
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = 20;
    }
    if(staticFive==5)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}


static void goodG2B2()
{
    size_t data;
    
    data = 0;
    if(staticFive==5)
    {
        
        data = 20;
    }
    if(staticFive==5)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_fscanf_07; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
