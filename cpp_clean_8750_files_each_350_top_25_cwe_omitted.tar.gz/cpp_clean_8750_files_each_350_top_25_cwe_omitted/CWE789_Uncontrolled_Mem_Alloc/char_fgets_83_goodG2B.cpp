

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_fgets_83.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING "hello"

namespace char_fgets_83
{
char_fgets_83_goodG2B::char_fgets_83_goodG2B(size_t dataCopy)
{
    data = dataCopy;
    
    data = 20;
}

char_fgets_83_goodG2B::~char_fgets_83_goodG2B()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = (char *)malloc(data*sizeof(char));
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
