


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING "hello"

namespace char_fscanf_61
{

#ifndef OMITBAD


size_t badSource(size_t data);

void bad()
{
    size_t data;
    
    data = 0;
    data = badSource(data);
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

#endif 

#ifndef OMITGOOD


size_t goodG2BSource(size_t data);

static void goodG2B()
{
    size_t data;
    
    data = 0;
    data = goodG2BSource(data);
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}


size_t goodB2GSource(size_t data);

static void goodB2G()
{
    size_t data;
    
    data = 0;
    data = goodB2GSource(data);
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_fscanf_61; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
