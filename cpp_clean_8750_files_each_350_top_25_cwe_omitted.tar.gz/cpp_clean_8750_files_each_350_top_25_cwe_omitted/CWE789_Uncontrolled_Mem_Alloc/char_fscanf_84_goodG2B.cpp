

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_fscanf_84.h"

#define HELLO_STRING "hello"

namespace char_fscanf_84
{
char_fscanf_84_goodG2B::char_fscanf_84_goodG2B(size_t dataCopy)
{
    data = dataCopy;
    
    data = 20;
}

char_fscanf_84_goodG2B::~char_fscanf_84_goodG2B()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
