


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_rand_61
{

#ifndef OMITBAD

size_t badSource(size_t data)
{
    
    data = rand();
    return data;
}

#endif 

#ifndef OMITGOOD


size_t goodG2BSource(size_t data)
{
    
    data = 20;
    return data;
}


size_t goodB2GSource(size_t data)
{
    
    data = rand();
    return data;
}

#endif 

} 
