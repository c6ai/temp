

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_fscanf_84.h"

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_84
{
wchar_t_fscanf_84_goodB2G::wchar_t_fscanf_84_goodB2G(size_t dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%ud", &data);
}

wchar_t_fscanf_84_goodB2G::~wchar_t_fscanf_84_goodB2G()
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}
}
#endif 
