

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_fgets_81.h"

#define HELLO_STRING "hello"

namespace char_fgets_81
{

void char_fgets_81_goodG2B::action(size_t data) const
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

}
#endif 
