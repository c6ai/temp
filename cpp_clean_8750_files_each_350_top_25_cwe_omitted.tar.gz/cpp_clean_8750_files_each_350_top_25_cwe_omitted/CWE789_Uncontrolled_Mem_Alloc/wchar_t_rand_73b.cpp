


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

using namespace std;

namespace wchar_t_rand_73
{

#ifndef OMITBAD

void badSink(list<size_t> dataList)
{
    
    size_t data = dataList.back();
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            if (myString == NULL) {exit(-1);}
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<size_t> dataList)
{
    size_t data = dataList.back();
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            if (myString == NULL) {exit(-1);}
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}


void goodB2GSink(list<size_t> dataList)
{
    size_t data = dataList.back();
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            if (myString == NULL) {exit(-1);}
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

#endif 

} 
