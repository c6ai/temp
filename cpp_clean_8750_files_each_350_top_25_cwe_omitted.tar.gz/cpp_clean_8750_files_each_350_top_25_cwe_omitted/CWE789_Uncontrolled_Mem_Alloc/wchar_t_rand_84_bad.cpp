

#ifndef OMITBAD

#include "std_testcase.h"
#include "wchar_t_rand_84.h"

#define HELLO_STRING L"hello"

namespace wchar_t_rand_84
{
wchar_t_rand_84_bad::wchar_t_rand_84_bad(size_t dataCopy)
{
    data = dataCopy;
    
    data = rand();
}

wchar_t_rand_84_bad::~wchar_t_rand_84_bad()
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = (wchar_t *)malloc(data*sizeof(wchar_t));
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
