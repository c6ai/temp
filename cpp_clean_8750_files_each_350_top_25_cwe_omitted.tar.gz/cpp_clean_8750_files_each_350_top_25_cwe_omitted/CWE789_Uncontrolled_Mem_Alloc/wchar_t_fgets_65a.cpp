


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING L"hello"

namespace wchar_t_fgets_65
{

#ifndef OMITBAD


void badSink(size_t data);

void bad()
{
    size_t data;
    
    void (*funcPtr) (size_t) = badSink;
    
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(size_t data);

static void goodG2B()
{
    size_t data;
    void (*funcPtr) (size_t) = goodG2BSink;
    
    data = 0;
    
    data = 20;
    funcPtr(data);
}


void goodB2GSink(size_t data);

static void goodB2G()
{
    size_t data;
    void (*funcPtr) (size_t) = goodB2GSink;
    
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_fgets_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
