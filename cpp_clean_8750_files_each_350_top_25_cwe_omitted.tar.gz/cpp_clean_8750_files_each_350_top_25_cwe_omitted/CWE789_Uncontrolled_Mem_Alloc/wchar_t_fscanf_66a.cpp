


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_66
{

#ifndef OMITBAD


void badSink(size_t dataArray[]);

void bad()
{
    size_t data;
    size_t dataArray[5];
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    
    dataArray[2] = data;
    badSink(dataArray);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(size_t dataArray[]);

static void goodG2B()
{
    size_t data;
    size_t dataArray[5];
    
    data = 0;
    
    data = 20;
    dataArray[2] = data;
    goodG2BSink(dataArray);
}


void goodB2GSink(size_t dataArray[]);

static void goodB2G()
{
    size_t data;
    size_t dataArray[5];
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    dataArray[2] = data;
    goodB2GSink(dataArray);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_fscanf_66; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
