


#include "std_testcase.h"
#include "char_rand_82.h"

namespace char_rand_82
{

#ifndef OMITBAD

void bad()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    char_rand_82_base* baseObject = new char_rand_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    char_rand_82_base* baseObject = new char_rand_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    char_rand_82_base* baseObject = new char_rand_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_rand_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
