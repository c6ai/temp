


#include "std_testcase.h"
#include <map>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace wchar_t_rand_74
{

#ifndef OMITBAD


void badSink(map<int, size_t> dataMap);

void bad()
{
    size_t data;
    map<int, size_t> dataMap;
    
    data = 0;
    
    data = rand();
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    badSink(dataMap);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, size_t> dataMap);

static void goodG2B()
{
    size_t data;
    map<int, size_t> dataMap;
    
    data = 0;
    
    data = 20;
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodG2BSink(dataMap);
}


void goodB2GSink(map<int, size_t> dataMap);

static void goodB2G()
{
    size_t data;
    map<int, size_t> dataMap;
    
    data = 0;
    
    data = rand();
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodB2GSink(dataMap);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_rand_74; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
