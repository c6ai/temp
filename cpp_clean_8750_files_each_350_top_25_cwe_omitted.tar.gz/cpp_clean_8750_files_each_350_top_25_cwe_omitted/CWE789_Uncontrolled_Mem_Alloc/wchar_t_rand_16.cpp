


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_rand_16
{

#ifndef OMITBAD

void bad()
{
    size_t data;
    
    data = 0;
    while(1)
    {
        
        data = rand();
        break;
    }
    while(1)
    {
        {
            wchar_t * myString;
            
            
            if (data > wcslen(HELLO_STRING))
            {
                myString = new wchar_t[data];
                
                wcscpy(myString, HELLO_STRING);
                printWLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    size_t data;
    
    data = 0;
    while(1)
    {
        
        data = rand();
        break;
    }
    while(1)
    {
        {
            wchar_t * myString;
            
            
            if (data > wcslen(HELLO_STRING) && data < 100)
            {
                myString = new wchar_t[data];
                
                wcscpy(myString, HELLO_STRING);
                printWLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
        break;
    }
}


static void goodG2B()
{
    size_t data;
    
    data = 0;
    while(1)
    {
        
        data = 20;
        break;
    }
    while(1)
    {
        {
            wchar_t * myString;
            
            
            if (data > wcslen(HELLO_STRING))
            {
                myString = new wchar_t[data];
                
                wcscpy(myString, HELLO_STRING);
                printWLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
        break;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_rand_16; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
