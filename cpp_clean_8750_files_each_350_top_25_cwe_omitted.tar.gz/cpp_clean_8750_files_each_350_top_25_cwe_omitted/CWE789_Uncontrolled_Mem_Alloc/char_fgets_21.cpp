


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING "hello"

namespace char_fgets_21
{

#ifndef OMITBAD


static int badStatic = 0;

static void badSink(size_t data)
{
    if(badStatic)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

void bad()
{
    size_t data;
    
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    badStatic = 1; 
    badSink(data);
}

#endif 

#ifndef OMITGOOD


static int goodB2G1Static = 0;
static int goodB2G2Static = 0;
static int goodG2bStatic = 0;


static void goodB2G1Sink(size_t data)
{
    if(goodB2G1Static)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}

static void goodB2G1()
{
    size_t data;
    
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    goodB2G1Static = 0; 
    goodB2G1Sink(data);
}


static void goodB2G2Sink(size_t data)
{
    if(goodB2G2Static)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING) && data < 100)
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string or too large");
            }
        }
    }
}

static void goodB2G2()
{
    size_t data;
    
    data = 0;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    goodB2G2Static = 1; 
    goodB2G2Sink(data);
}


static void goodG2BSink(size_t data)
{
    if(goodG2bStatic)
    {
        {
            char * myString;
            
            
            if (data > strlen(HELLO_STRING))
            {
                myString = new char[data];
                
                strcpy(myString, HELLO_STRING);
                printLine(myString);
                delete [] myString;
            }
            else
            {
                printLine("Input is less than the length of the source string");
            }
        }
    }
}

static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    goodG2bStatic = 1; 
    goodG2BSink(data);
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_fgets_21; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
