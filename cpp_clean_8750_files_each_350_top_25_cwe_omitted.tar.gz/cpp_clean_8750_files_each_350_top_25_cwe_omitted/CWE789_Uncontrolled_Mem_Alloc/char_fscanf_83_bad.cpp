

#ifndef OMITBAD

#include "std_testcase.h"
#include "char_fscanf_83.h"

#define HELLO_STRING "hello"

namespace char_fscanf_83
{
char_fscanf_83_bad::char_fscanf_83_bad(size_t dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%ud", &data);
}

char_fscanf_83_bad::~char_fscanf_83_bad()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
