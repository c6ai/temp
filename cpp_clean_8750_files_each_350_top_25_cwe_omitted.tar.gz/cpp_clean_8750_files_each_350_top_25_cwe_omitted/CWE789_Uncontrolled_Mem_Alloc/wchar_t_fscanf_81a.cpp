


#include "std_testcase.h"
#include "wchar_t_fscanf_81.h"

namespace wchar_t_fscanf_81
{

#ifndef OMITBAD

void bad()
{
    size_t data;
    
    data = 0;
    
    fscanf(stdin, "%zu", &data);
    const wchar_t_fscanf_81_base& o = wchar_t_fscanf_81_bad();
    o.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    const wchar_t_fscanf_81_base& baseObject = wchar_t_fscanf_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    fscanf(stdin, "%zu", &data);
    const wchar_t_fscanf_81_base& baseObject = wchar_t_fscanf_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_fscanf_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
