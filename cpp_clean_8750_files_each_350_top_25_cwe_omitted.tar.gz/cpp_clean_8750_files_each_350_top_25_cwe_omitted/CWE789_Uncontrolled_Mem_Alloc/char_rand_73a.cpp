


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace char_rand_73
{

#ifndef OMITBAD


void badSink(list<size_t> dataList);

void bad()
{
    size_t data;
    list<size_t> dataList;
    
    data = 0;
    
    data = rand();
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    badSink(dataList);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<size_t> dataList);

static void goodG2B()
{
    size_t data;
    list<size_t> dataList;
    
    data = 0;
    
    data = 20;
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodG2BSink(dataList);
}


void goodB2GSink(list<size_t> dataList);

static void goodB2G()
{
    size_t data;
    list<size_t> dataList;
    
    data = 0;
    
    data = rand();
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodB2GSink(dataList);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_rand_73; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
