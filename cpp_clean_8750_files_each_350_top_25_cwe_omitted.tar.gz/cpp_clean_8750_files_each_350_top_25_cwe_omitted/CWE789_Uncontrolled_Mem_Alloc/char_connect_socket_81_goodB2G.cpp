

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_connect_socket_81.h"

#define HELLO_STRING "hello"

namespace char_connect_socket_81
{

void char_connect_socket_81_goodB2G::action(size_t data) const
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = (char *)malloc(data*sizeof(char));
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            free(myString);
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

}
#endif 
