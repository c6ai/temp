

#ifndef OMITBAD

#include "std_testcase.h"
#include "char_rand_83.h"

#define HELLO_STRING "hello"

namespace char_rand_83
{
char_rand_83_bad::char_rand_83_bad(size_t dataCopy)
{
    data = dataCopy;
    
    data = rand();
}

char_rand_83_bad::~char_rand_83_bad()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
