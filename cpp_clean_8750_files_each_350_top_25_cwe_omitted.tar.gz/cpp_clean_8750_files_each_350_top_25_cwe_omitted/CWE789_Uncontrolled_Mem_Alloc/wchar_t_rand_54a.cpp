


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_rand_54
{

#ifndef OMITBAD


void badSink_b(size_t data);

void bad()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(size_t data);

static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    goodG2BSink_b(data);
}


void goodB2GSink_b(size_t data);

static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_rand_54; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
