


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_67
{

typedef struct _structType
{
    size_t structFirst;
} structType;

#ifndef OMITBAD


void badSink(structType myStruct);

void bad()
{
    size_t data;
    structType myStruct;
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    myStruct.structFirst = data;
    badSink(myStruct);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct);

static void goodG2B()
{
    size_t data;
    structType myStruct;
    
    data = 0;
    
    data = 20;
    myStruct.structFirst = data;
    goodG2BSink(myStruct);
}


void goodB2GSink(structType myStruct);

static void goodB2G()
{
    size_t data;
    structType myStruct;
    
    data = 0;
    
    fscanf(stdin, "%ud", &data);
    myStruct.structFirst = data;
    goodB2GSink(myStruct);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_fscanf_67; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
