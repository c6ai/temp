


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING "hello"

using namespace std;

namespace char_connect_socket_73
{

#ifndef OMITBAD

void badSink(list<size_t> dataList)
{
    
    size_t data = dataList.back();
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<size_t> dataList)
{
    size_t data = dataList.back();
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}


void goodB2GSink(list<size_t> dataList)
{
    size_t data = dataList.back();
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

#endif 

} 
