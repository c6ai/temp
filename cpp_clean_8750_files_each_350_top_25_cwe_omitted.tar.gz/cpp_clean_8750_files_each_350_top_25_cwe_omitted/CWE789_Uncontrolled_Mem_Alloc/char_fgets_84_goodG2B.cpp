

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_fgets_84.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING "hello"

namespace char_fgets_84
{
char_fgets_84_goodG2B::char_fgets_84_goodG2B(size_t dataCopy)
{
    data = dataCopy;
    
    data = 20;
}

char_fgets_84_goodG2B::~char_fgets_84_goodG2B()
{
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
