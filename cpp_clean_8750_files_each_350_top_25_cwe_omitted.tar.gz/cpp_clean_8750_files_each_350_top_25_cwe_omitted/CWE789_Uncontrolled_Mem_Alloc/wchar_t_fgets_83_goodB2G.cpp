

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_fgets_83.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING L"hello"

namespace wchar_t_fgets_83
{
wchar_t_fgets_83_goodB2G::wchar_t_fgets_83_goodB2G(size_t dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = strtoul(inputBuffer, NULL, 0);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

wchar_t_fgets_83_goodB2G::~wchar_t_fgets_83_goodB2G()
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING) && data < 100)
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}
}
#endif 
