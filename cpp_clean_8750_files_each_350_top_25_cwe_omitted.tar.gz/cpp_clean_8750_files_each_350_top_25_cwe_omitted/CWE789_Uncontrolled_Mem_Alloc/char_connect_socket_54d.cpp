


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#ifdef _WIN32
#include <winsock2.h>
#include <windows.h>
#include <direct.h>
#pragma comment(lib, "ws2_32") 
#define CLOSE_SOCKET closesocket
#else 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define CLOSE_SOCKET close
#define SOCKET int
#endif

#define TCP_PORT 27015
#define IP_ADDRESS "127.0.0.1"
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING "hello"

namespace char_connect_socket_54
{

#ifndef OMITBAD


void badSink_e(size_t data);

void badSink_d(size_t data)
{
    badSink_e(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(size_t data);

void goodG2BSink_d(size_t data)
{
    goodG2BSink_e(data);
}


void goodB2GSink_e(size_t data);

void goodB2GSink_d(size_t data)
{
    goodB2GSink_e(data);
}

#endif 

} 
