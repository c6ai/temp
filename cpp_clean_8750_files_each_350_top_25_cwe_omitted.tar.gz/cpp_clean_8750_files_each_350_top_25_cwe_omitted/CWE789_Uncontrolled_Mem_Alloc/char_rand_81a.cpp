


#include "std_testcase.h"
#include "char_rand_81.h"

namespace char_rand_81
{

#ifndef OMITBAD

void bad()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    const char_rand_81_base& o = char_rand_81_bad();
    o.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    size_t data;
    
    data = 0;
    
    data = 20;
    const char_rand_81_base& baseObject = char_rand_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    size_t data;
    
    data = 0;
    
    data = rand();
    const char_rand_81_base& baseObject = char_rand_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_rand_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
