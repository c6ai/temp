


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_62
{

#ifndef OMITBAD

void badSource(size_t &data)
{
    
    fscanf(stdin, "%zu", &data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(size_t &data)
{
    
    data = 20;
}


void goodB2GSource(size_t &data)
{
    
    fscanf(stdin, "%zu", &data);
}

#endif 

} 
