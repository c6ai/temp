

#ifndef OMITBAD

#include "std_testcase.h"
#include "wchar_t_fscanf_83.h"

#define HELLO_STRING L"hello"

namespace wchar_t_fscanf_83
{
wchar_t_fscanf_83_bad::wchar_t_fscanf_83_bad(size_t dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%ud", &data);
}

wchar_t_fscanf_83_bad::~wchar_t_fscanf_83_bad()
{
    {
        wchar_t * myString;
        
        
        if (data > wcslen(HELLO_STRING))
        {
            myString = new wchar_t[data];
            
            wcscpy(myString, HELLO_STRING);
            printWLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}
}
#endif 
