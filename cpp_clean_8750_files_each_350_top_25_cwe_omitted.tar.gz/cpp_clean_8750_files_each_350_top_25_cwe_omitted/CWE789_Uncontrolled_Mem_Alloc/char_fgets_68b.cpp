


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING "hello"

namespace char_fgets_68
{

extern size_t badData;
extern size_t goodG2BData;
extern size_t goodB2GData;

#ifndef OMITBAD

void badSink()
{
    size_t data = badData;
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink()
{
    size_t data = goodG2BData;
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING))
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string");
        }
    }
}


void goodB2GSink()
{
    size_t data = goodB2GData;
    {
        char * myString;
        
        
        if (data > strlen(HELLO_STRING) && data < 100)
        {
            myString = new char[data];
            
            strcpy(myString, HELLO_STRING);
            printLine(myString);
            delete [] myString;
        }
        else
        {
            printLine("Input is less than the length of the source string or too large");
        }
    }
}

#endif 

} 
