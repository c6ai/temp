


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

#define HELLO_STRING L"hello"

namespace wchar_t_fgets_54
{

#ifndef OMITBAD


void badSink_d(size_t data);

void badSink_c(size_t data)
{
    badSink_d(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(size_t data);

void goodG2BSink_c(size_t data)
{
    goodG2BSink_d(data);
}


void goodB2GSink_d(size_t data);

void goodB2GSink_c(size_t data)
{
    goodB2GSink_d(data);
}

#endif 

} 
