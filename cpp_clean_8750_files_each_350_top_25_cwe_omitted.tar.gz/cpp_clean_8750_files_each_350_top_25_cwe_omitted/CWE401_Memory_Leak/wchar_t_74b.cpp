


#include "std_testcase.h"
#include <map>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace wchar_t_74
{

#ifndef OMITBAD

void badSink(map<int, wchar_t *> dataMap)
{
    
    wchar_t * data = dataMap[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    
    ; 
}


void goodB2GSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    
    delete data;
}

#endif 

} 
