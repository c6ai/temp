


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif


static int staticTrue = 1; 
static int staticFalse = 0; 

namespace array_int64_t_05
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL;
    if(staticTrue)
    {
        
        data = new int64_t[100];
        
        data[0] = 5LL;
        printLongLongLine(data[0]);
    }
    if(staticTrue)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    int64_t * data;
    data = NULL;
    if(staticTrue)
    {
        
        data = new int64_t[100];
        
        data[0] = 5LL;
        printLongLongLine(data[0]);
    }
    if(staticFalse)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete[] data;
    }
}


static void goodB2G2()
{
    int64_t * data;
    data = NULL;
    if(staticTrue)
    {
        
        data = new int64_t[100];
        
        data[0] = 5LL;
        printLongLongLine(data[0]);
    }
    if(staticTrue)
    {
        
        delete[] data;
    }
}


static void goodG2B1()
{
    int64_t * data;
    data = NULL;
    if(staticFalse)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        int64_t dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0] = 5LL;
        printLongLongLine(data[0]);
    }
    if(staticTrue)
    {
        
        ; 
    }
}


static void goodG2B2()
{
    int64_t * data;
    data = NULL;
    if(staticTrue)
    {
        
        int64_t dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0] = 5LL;
        printLongLongLine(data[0]);
    }
    if(staticTrue)
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int64_t_05; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
