

#ifndef OMITBAD

#include "std_testcase.h"
#include "malloc_81.h"

namespace malloc_81
{

void malloc_81_bad::action(int * data) const
{
    
    ; 
}

}
#endif 
