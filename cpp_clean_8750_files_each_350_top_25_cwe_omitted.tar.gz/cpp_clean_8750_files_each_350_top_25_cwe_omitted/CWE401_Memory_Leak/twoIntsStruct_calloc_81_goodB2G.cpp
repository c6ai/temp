

#ifndef OMITGOOD

#include "std_testcase.h"
#include "twoIntsStruct_calloc_81.h"

namespace twoIntsStruct_calloc_81
{

void twoIntsStruct_calloc_81_goodB2G::action(struct _twoIntsStruct * data) const
{
    
    free(data);
}

}
#endif 
