


#include "std_testcase.h"
#include "twoIntsStruct_calloc_84.h"

namespace twoIntsStruct_calloc_84
{

#ifndef OMITBAD

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_calloc_84_bad * badObject = new twoIntsStruct_calloc_84_bad(data);
    delete badObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_calloc_84_goodG2B * goodG2BObject = new twoIntsStruct_calloc_84_goodG2B(data);
    delete goodG2BObject;
}


static void goodB2G()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_calloc_84_goodB2G * goodB2GObject = new twoIntsStruct_calloc_84_goodB2G(data);
    delete goodB2GObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_calloc_84; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
