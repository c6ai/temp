


#include "std_testcase.h"

#include <wchar.h>

namespace char_62
{

#ifndef OMITBAD


void badSource(char * &data);

void bad()
{
    char * data;
    data = NULL;
    badSource(data);
    
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(char * &data);

static void goodG2B()
{
    char * data;
    data = NULL;
    goodG2BSource(data);
    
    
    ; 
}


void goodB2GSource(char * &data);

static void goodB2G()
{
    char * data;
    data = NULL;
    goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
