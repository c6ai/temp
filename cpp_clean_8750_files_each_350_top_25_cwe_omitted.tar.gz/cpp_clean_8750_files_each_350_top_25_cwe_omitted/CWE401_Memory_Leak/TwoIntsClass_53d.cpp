


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace TwoIntsClass_53
{

#ifndef OMITBAD

void badSink_d(TwoIntsClass * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(TwoIntsClass * data)
{
    
    ; 
}


void goodB2GSink_d(TwoIntsClass * data)
{
    
    delete data;
}

#endif 

} 
