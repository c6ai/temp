


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int_18
{

#ifndef OMITBAD

void bad()
{
    int * data;
    data = NULL;
    goto source;
source:
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    goto sink;
sink:
    
    ; 
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int * data;
    data = NULL;
    goto source;
source:
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    goto sink;
sink:
    
    delete[] data;
}


static void goodG2B()
{
    int * data;
    data = NULL;
    goto source;
source:
    
    int dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    data[0] = 5;
    printIntLine(data[0]);
    goto sink;
sink:
    
    ; 
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_18; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
