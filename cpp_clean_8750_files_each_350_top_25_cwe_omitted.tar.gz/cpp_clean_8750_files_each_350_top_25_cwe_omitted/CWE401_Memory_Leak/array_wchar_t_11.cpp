


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_wchar_t_11
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new wchar_t[100];
        
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new wchar_t[100];
        
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete[] data;
    }
}


static void goodB2G2()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new wchar_t[100];
        
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsTrue())
    {
        
        delete[] data;
    }
}


static void goodG2B1()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        wchar_t dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}


static void goodG2B2()
{
    wchar_t * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        wchar_t dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        wcscpy(data, L"A String");
        printWLine(data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_wchar_t_11; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
