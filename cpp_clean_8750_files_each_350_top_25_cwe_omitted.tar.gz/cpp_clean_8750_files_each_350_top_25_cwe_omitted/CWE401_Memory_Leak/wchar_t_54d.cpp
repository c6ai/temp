


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_54
{

#ifndef OMITBAD


void badSink_e(wchar_t * data);

void badSink_d(wchar_t * data)
{
    badSink_e(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(wchar_t * data);

void goodG2BSink_d(wchar_t * data)
{
    goodG2BSink_e(data);
}


void goodB2GSink_e(wchar_t * data);

void goodB2GSink_d(wchar_t * data)
{
    goodB2GSink_e(data);
}

#endif 

} 
