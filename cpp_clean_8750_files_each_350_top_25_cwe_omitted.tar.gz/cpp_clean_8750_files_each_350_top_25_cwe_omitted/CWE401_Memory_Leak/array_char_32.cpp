


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_char_32
{

#ifndef OMITBAD

void bad()
{
    char * data;
    char * *dataPtr1 = &data;
    char * *dataPtr2 = &data;
    data = NULL;
    {
        char * data = *dataPtr1;
        
        data = new char[100];
        
        strcpy(data, "A String");
        printLine(data);
        *dataPtr1 = data;
    }
    {
        char * data = *dataPtr2;
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    char * data;
    char * *dataPtr1 = &data;
    char * *dataPtr2 = &data;
    data = NULL;
    {
        char * data = *dataPtr1;
        
        char dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        strcpy(data, "A String");
        printLine(data);
        *dataPtr1 = data;
    }
    {
        char * data = *dataPtr2;
        
        ; 
    }
}


static void goodB2G()
{
    char * data;
    char * *dataPtr1 = &data;
    char * *dataPtr2 = &data;
    data = NULL;
    {
        char * data = *dataPtr1;
        
        data = new char[100];
        
        strcpy(data, "A String");
        printLine(data);
        *dataPtr1 = data;
    }
    {
        char * data = *dataPtr2;
        
        delete[] data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_char_32; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
