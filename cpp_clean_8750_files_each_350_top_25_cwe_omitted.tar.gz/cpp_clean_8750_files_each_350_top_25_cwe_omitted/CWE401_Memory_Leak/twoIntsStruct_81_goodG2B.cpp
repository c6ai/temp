

#ifndef OMITGOOD

#include "std_testcase.h"
#include "twoIntsStruct_81.h"

namespace twoIntsStruct_81
{

void twoIntsStruct_81_goodG2B::action(twoIntsStruct * data) const
{
    
    ; 
}

}
#endif 
