


#include "std_testcase.h"
#include <map>

#include <wchar.h>

using namespace std;

namespace t_realloc_74
{

#ifndef OMITBAD

void badSink(map<int, int64_t *> dataMap)
{
    
    int64_t * data = dataMap[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, int64_t *> dataMap)
{
    int64_t * data = dataMap[2];
    
    ; 
}


void goodB2GSink(map<int, int64_t *> dataMap)
{
    int64_t * data = dataMap[2];
    
    free(data);
}

#endif 

} 
