


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int_17
{

#ifndef OMITBAD

void bad()
{
    int i,j;
    int * data;
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = new int;
        
        *data = 5;
        printIntLine(*data);
    }
    for(j = 0; j < 1; j++)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int i,k;
    int * data;
    data = NULL;
    for(i = 0; i < 1; i++)
    {
        
        data = new int;
        
        *data = 5;
        printIntLine(*data);
    }
    for(k = 0; k < 1; k++)
    {
        
        delete data;
    }
}


static void goodG2B()
{
    int h,j;
    int * data;
    data = NULL;
    for(h = 0; h < 1; h++)
    {
        
        int dataGoodBuffer;
        data = &dataGoodBuffer;
        
        *data = 5;
        printIntLine(*data);
    }
    for(j = 0; j < 1; j++)
    {
        
        ; 
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int_17; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
