


#include "std_testcase.h"
#include <map>

#include <wchar.h>

using namespace std;

namespace calloc_74
{

#ifndef OMITBAD


void badSink(map<int, int *> dataMap);

void bad()
{
    int * data;
    map<int, int *> dataMap;
    data = NULL;
    
    data = (int *)calloc(100, sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    badSink(dataMap);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, int *> dataMap);

static void goodG2B()
{
    int * data;
    map<int, int *> dataMap;
    data = NULL;
    
    data = (int *)ALLOCA(100*sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodG2BSink(dataMap);
}


void goodB2GSink(map<int, int *> dataMap);

static void goodB2G()
{
    int * data;
    map<int, int *> dataMap;
    data = NULL;
    
    data = (int *)calloc(100, sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodB2GSink(dataMap);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace calloc_74; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
