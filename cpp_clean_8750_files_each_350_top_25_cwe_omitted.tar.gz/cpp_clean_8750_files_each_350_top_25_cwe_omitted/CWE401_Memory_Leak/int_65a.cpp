


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int_65
{

#ifndef OMITBAD


void badSink(int * data);

void bad()
{
    int * data;
    
    void (*funcPtr) (int *) = badSink;
    data = NULL;
    
    data = new int;
    
    *data = 5;
    printIntLine(*data);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * data);

static void goodG2B()
{
    int * data;
    void (*funcPtr) (int *) = goodG2BSink;
    data = NULL;
    
    int dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 5;
    printIntLine(*data);
    funcPtr(data);
}


void goodB2GSink(int * data);

static void goodB2G()
{
    int * data;
    void (*funcPtr) (int *) = goodB2GSink;
    data = NULL;
    
    data = new int;
    
    *data = 5;
    printIntLine(*data);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
