


#include "std_testcase.h"
#include "twoIntsStruct_realloc_83.h"

namespace twoIntsStruct_realloc_83
{

#ifndef OMITBAD

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_realloc_83_bad badObject(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_realloc_83_goodG2B goodG2BObject(data);
}


static void goodB2G()
{
    struct _twoIntsStruct * data;
    data = NULL;
    twoIntsStruct_realloc_83_goodB2G goodB2GObject(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_realloc_83; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
