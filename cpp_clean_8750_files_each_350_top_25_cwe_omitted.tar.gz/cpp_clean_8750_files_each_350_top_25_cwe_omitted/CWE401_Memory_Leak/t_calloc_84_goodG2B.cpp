

#ifndef OMITGOOD

#include "std_testcase.h"
#include "t_calloc_84.h"

namespace t_calloc_84
{
t_calloc_84_goodG2B::t_calloc_84_goodG2B(wchar_t * dataCopy)
{
    data = dataCopy;
    
    data = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    
    wcscpy(data, L"A String");
    printWLine(data);
}

t_calloc_84_goodG2B::~t_calloc_84_goodG2B()
{
    
    ; 
}
}
#endif 
