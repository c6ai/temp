


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace char_54
{

#ifndef OMITBAD

void badSink_e(char * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(char * data)
{
    
    ; 
}


void goodB2GSink_e(char * data)
{
    
    delete data;
}

#endif 

} 
