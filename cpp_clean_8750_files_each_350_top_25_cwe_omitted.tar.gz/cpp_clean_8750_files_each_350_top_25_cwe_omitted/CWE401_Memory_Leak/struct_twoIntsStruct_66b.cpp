


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_66
{

#ifndef OMITBAD

void badSink(struct _twoIntsStruct * dataArray[])
{
    
    struct _twoIntsStruct * data = dataArray[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(struct _twoIntsStruct * dataArray[])
{
    struct _twoIntsStruct * data = dataArray[2];
    
    ; 
}


void goodB2GSink(struct _twoIntsStruct * dataArray[])
{
    struct _twoIntsStruct * data = dataArray[2];
    
    delete data;
}

#endif 

} 
