


#include "std_testcase.h"
#include <vector>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace char_72
{

#ifndef OMITBAD

void badSink(vector<char *> dataVector)
{
    
    char * data = dataVector[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<char *> dataVector)
{
    char * data = dataVector[2];
    
    ; 
}


void goodB2GSink(vector<char *> dataVector)
{
    char * data = dataVector[2];
    
    delete data;
}

#endif 

} 
