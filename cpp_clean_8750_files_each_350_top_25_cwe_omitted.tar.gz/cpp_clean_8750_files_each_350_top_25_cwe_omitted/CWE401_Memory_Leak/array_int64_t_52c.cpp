


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int64_t_52
{

#ifndef OMITBAD

void badSink_c(int64_t * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(int64_t * data)
{
    
    ; 
}


void goodB2GSink_c(int64_t * data)
{
    
    delete[] data;
}

#endif 

} 
