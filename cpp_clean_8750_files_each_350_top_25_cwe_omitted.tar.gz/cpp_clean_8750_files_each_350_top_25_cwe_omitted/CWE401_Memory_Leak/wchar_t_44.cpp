


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_44
{

#ifndef OMITBAD

static void badSink(wchar_t * data)
{
    
    ; 
}

void bad()
{
    wchar_t * data;
    
    void (*funcPtr) (wchar_t *) = badSink;
    data = NULL;
    
    data = new wchar_t;
    
    *data = L'A';
    printHexCharLine((char)*data);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(wchar_t * data)
{
    
    ; 
}

static void goodG2B()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodG2BSink;
    data = NULL;
    
    wchar_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = L'A';
    printHexCharLine((char)*data);
    funcPtr(data);
}


static void goodB2GSink(wchar_t * data)
{
    
    delete data;
}

static void goodB2G()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodB2GSink;
    data = NULL;
    
    data = new wchar_t;
    
    *data = L'A';
    printHexCharLine((char)*data);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
