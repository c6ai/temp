


#include "std_testcase.h"
#include <vector>

#include <wchar.h>

using namespace std;

namespace twoIntsStruct_malloc_72
{

#ifndef OMITBAD

void badSink(vector<struct _twoIntsStruct *> dataVector)
{
    
    struct _twoIntsStruct * data = dataVector[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<struct _twoIntsStruct *> dataVector)
{
    struct _twoIntsStruct * data = dataVector[2];
    
    ; 
}


void goodB2GSink(vector<struct _twoIntsStruct *> dataVector)
{
    struct _twoIntsStruct * data = dataVector[2];
    
    free(data);
}

#endif 

} 
