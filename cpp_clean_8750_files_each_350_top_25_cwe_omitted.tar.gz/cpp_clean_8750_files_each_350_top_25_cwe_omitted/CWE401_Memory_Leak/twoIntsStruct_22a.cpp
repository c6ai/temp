


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace twoIntsStruct_22
{

#ifndef OMITBAD


int badGlobal = 0;

void badSink(twoIntsStruct * data);

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    
    data = new twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    badGlobal = 1; 
    badSink(data);
}

#endif 

#ifndef OMITGOOD


int goodB2G1Global = 0;
int goodB2G2Global = 0;
int goodG2B1Global = 0;


void goodB2G1Sink(twoIntsStruct * data);

static void goodB2G1()
{
    twoIntsStruct * data;
    data = NULL;
    
    data = new twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    goodB2G1Global = 0; 
    goodB2G1Sink(data);
}


void goodB2G2Sink(twoIntsStruct * data);

static void goodB2G2()
{
    twoIntsStruct * data;
    data = NULL;
    
    data = new twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    goodB2G2Global = 1; 
    goodB2G2Sink(data);
}


void goodG2B1Sink(twoIntsStruct * data);

static void goodG2B1()
{
    twoIntsStruct * data;
    data = NULL;
    
    twoIntsStruct dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    goodG2B1Global = 1; 
    goodG2B1Sink(data);
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_22; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
