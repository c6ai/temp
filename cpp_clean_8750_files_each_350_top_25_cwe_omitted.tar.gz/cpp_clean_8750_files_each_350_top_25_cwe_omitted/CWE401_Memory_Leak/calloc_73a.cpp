


#include "std_testcase.h"
#include <list>

#include <wchar.h>

using namespace std;

namespace calloc_73
{

#ifndef OMITBAD


void badSink(list<int *> dataList);

void bad()
{
    int * data;
    list<int *> dataList;
    data = NULL;
    
    data = (int *)calloc(100, sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    badSink(dataList);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<int *> dataList);

static void goodG2B()
{
    int * data;
    list<int *> dataList;
    data = NULL;
    
    data = (int *)ALLOCA(100*sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodG2BSink(dataList);
}


void goodB2GSink(list<int *> dataList);

static void goodB2G()
{
    int * data;
    list<int *> dataList;
    data = NULL;
    
    data = (int *)calloc(100, sizeof(int));
    
    data[0] = 5;
    printIntLine(data[0]);
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodB2GSink(dataList);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace calloc_73; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
