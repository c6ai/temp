

#ifndef OMITBAD

#include "std_testcase.h"
#include "malloc_82.h"

namespace malloc_82
{

void malloc_82_bad::action(twoIntsStruct * data)
{
    
    ; 
}

}
#endif 
