

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_TwoIntsClass_82.h"

namespace array_TwoIntsClass_82
{

void array_TwoIntsClass_82_bad::action(TwoIntsClass * data)
{
    
    ; 
}

}
#endif 
