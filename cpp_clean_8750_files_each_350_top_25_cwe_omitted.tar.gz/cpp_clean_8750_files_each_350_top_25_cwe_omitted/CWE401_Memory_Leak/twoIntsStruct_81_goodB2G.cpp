

#ifndef OMITGOOD

#include "std_testcase.h"
#include "twoIntsStruct_81.h"

namespace twoIntsStruct_81
{

void twoIntsStruct_81_goodB2G::action(twoIntsStruct * data) const
{
    
    delete data;
}

}
#endif 
