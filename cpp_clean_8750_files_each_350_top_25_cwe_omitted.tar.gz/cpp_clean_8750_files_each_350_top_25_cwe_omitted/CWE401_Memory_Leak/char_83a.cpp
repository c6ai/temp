


#include "std_testcase.h"
#include "char_83.h"

namespace char_83
{

#ifndef OMITBAD

void bad()
{
    char * data;
    data = NULL;
    char_83_bad badObject(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    char * data;
    data = NULL;
    char_83_goodG2B goodG2BObject(data);
}


static void goodB2G()
{
    char * data;
    data = NULL;
    char_83_goodB2G goodB2GObject(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_83; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
