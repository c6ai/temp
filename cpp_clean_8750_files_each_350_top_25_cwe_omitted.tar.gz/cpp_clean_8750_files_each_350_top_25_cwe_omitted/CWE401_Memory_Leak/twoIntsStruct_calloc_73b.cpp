


#include "std_testcase.h"
#include <list>

#include <wchar.h>

using namespace std;

namespace twoIntsStruct_calloc_73
{

#ifndef OMITBAD

void badSink(list<struct _twoIntsStruct *> dataList)
{
    
    struct _twoIntsStruct * data = dataList.back();
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<struct _twoIntsStruct *> dataList)
{
    struct _twoIntsStruct * data = dataList.back();
    
    ; 
}


void goodB2GSink(list<struct _twoIntsStruct *> dataList)
{
    struct _twoIntsStruct * data = dataList.back();
    
    free(data);
}

#endif 

} 
