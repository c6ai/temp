


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_twointsStruct_12
{

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    else
    {
        
        twoIntsStruct dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        ; 
    }
    else
    {
        
        delete[] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    else
    {
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        delete[] data;
    }
    else
    {
        
        delete[] data;
    }
}


static void goodG2B()
{
    twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        twoIntsStruct dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    else
    {
        
        twoIntsStruct dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        ; 
    }
    else
    {
        
        ; 
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_twointsStruct_12; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
