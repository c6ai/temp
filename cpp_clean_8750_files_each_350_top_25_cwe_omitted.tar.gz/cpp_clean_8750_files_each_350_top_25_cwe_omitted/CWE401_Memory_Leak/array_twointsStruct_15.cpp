


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_twointsStruct_15
{

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    switch(6)
    {
    case 6:
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        ; 
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    twoIntsStruct * data;
    data = NULL;
    switch(6)
    {
    case 6:
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(8)
    {
    case 7:
        
        printLine("Benign, fixed string");
        break;
    default:
        
        delete[] data;
        break;
    }
}


static void goodB2G2()
{
    twoIntsStruct * data;
    data = NULL;
    switch(6)
    {
    case 6:
        
        data = new twoIntsStruct[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        delete[] data;
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}


static void goodG2B1()
{
    twoIntsStruct * data;
    data = NULL;
    switch(5)
    {
    case 6:
        
        printLine("Benign, fixed string");
        break;
    default:
        
        twoIntsStruct dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
        break;
    }
    switch(7)
    {
    case 7:
        
        ; 
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}


static void goodG2B2()
{
    twoIntsStruct * data;
    data = NULL;
    switch(6)
    {
    case 6:
        
        twoIntsStruct dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printStructLine(&data[0]);
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
    switch(7)
    {
    case 7:
        
        ; 
        break;
    default:
        
        printLine("Benign, fixed string");
        break;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_twointsStruct_15; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
