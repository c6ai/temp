


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_TwoIntsClass_16
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    data = NULL;
    while(1)
    {
        
        data = new TwoIntsClass[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printIntLine(data[0].intOne);
        printIntLine(data[0].intTwo);
        break;
    }
    while(1)
    {
        
        ; 
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    TwoIntsClass * data;
    data = NULL;
    while(1)
    {
        
        data = new TwoIntsClass[100];
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printIntLine(data[0].intOne);
        printIntLine(data[0].intTwo);
        break;
    }
    while(1)
    {
        
        delete[] data;
        break;
    }
}


static void goodG2B()
{
    TwoIntsClass * data;
    data = NULL;
    while(1)
    {
        
        TwoIntsClass dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0].intOne = 0;
        data[0].intTwo = 0;
        printIntLine(data[0].intOne);
        printIntLine(data[0].intTwo);
        break;
    }
    while(1)
    {
        
        ; 
        break;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_TwoIntsClass_16; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
