


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int_51
{

#ifndef OMITBAD

void badSink(int * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * data)
{
    
    ; 
}


void goodB2GSink(int * data)
{
    
    delete data;
}

#endif 

} 
