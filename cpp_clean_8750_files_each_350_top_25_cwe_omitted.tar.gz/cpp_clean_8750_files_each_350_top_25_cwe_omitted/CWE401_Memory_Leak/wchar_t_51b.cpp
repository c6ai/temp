


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_51
{

#ifndef OMITBAD

void badSink(wchar_t * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * data)
{
    
    ; 
}


void goodB2GSink(wchar_t * data)
{
    
    delete data;
}

#endif 

} 
