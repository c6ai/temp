


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int64_t_68
{

extern int64_t * badData;
extern int64_t * goodG2BData;
extern int64_t * goodB2GData;

#ifndef OMITBAD

void badSink()
{
    int64_t * data = badData;
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink()
{
    int64_t * data = goodG2BData;
    
    ; 
}


void goodB2GSink()
{
    int64_t * data = goodB2GData;
    
    delete[] data;
}

#endif 

} 
