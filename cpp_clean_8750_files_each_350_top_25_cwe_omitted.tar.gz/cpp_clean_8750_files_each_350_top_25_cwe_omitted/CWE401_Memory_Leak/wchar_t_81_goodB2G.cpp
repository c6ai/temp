

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_81.h"

namespace wchar_t_81
{

void wchar_t_81_goodB2G::action(wchar_t * data) const
{
    
    free(data);
}

}
#endif 
