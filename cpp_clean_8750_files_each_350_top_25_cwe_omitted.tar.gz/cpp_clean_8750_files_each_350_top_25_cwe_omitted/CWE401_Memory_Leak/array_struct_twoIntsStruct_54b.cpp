


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_struct_twoIntsStruct_54
{

#ifndef OMITBAD


void badSink_c(struct _twoIntsStruct * data);

void badSink_b(struct _twoIntsStruct * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(struct _twoIntsStruct * data);

void goodG2BSink_b(struct _twoIntsStruct * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(struct _twoIntsStruct * data);

void goodB2GSink_b(struct _twoIntsStruct * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
