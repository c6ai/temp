

#ifndef OMITBAD

#include "std_testcase.h"
#include "t_realloc_82.h"

namespace t_realloc_82
{

void t_realloc_82_bad::action(wchar_t * data)
{
    
    ; 
}

}
#endif 
