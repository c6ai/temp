


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_wchar_t_63
{

#ifndef OMITBAD

void badSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    ; 
}


void goodB2GSink(wchar_t * * dataPtr)
{
    wchar_t * data = *dataPtr;
    
    delete[] data;
}

#endif 

} 
