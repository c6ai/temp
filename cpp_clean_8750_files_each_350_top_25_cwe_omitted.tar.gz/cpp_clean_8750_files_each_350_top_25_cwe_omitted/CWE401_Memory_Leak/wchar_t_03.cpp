


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_03
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    data = NULL;
    if(5==5)
    {
        
        data = new wchar_t;
        
        *data = L'A';
        printHexCharLine((char)*data);
    }
    if(5==5)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    wchar_t * data;
    data = NULL;
    if(5==5)
    {
        
        data = new wchar_t;
        
        *data = L'A';
        printHexCharLine((char)*data);
    }
    if(5!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


static void goodB2G2()
{
    wchar_t * data;
    data = NULL;
    if(5==5)
    {
        
        data = new wchar_t;
        
        *data = L'A';
        printHexCharLine((char)*data);
    }
    if(5==5)
    {
        
        delete data;
    }
}


static void goodG2B1()
{
    wchar_t * data;
    data = NULL;
    if(5!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        wchar_t dataGoodBuffer;
        data = &dataGoodBuffer;
        
        *data = L'A';
        printHexCharLine((char)*data);
    }
    if(5==5)
    {
        
        ; 
    }
}


static void goodG2B2()
{
    wchar_t * data;
    data = NULL;
    if(5==5)
    {
        
        wchar_t dataGoodBuffer;
        data = &dataGoodBuffer;
        
        *data = L'A';
        printHexCharLine((char)*data);
    }
    if(5==5)
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_03; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
