


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int_63
{

#ifndef OMITBAD

void badSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    ; 
}


void goodB2GSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    delete[] data;
}

#endif 

} 
