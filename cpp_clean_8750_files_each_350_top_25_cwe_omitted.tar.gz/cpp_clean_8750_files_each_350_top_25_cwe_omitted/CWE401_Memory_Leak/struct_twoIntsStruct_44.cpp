


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_44
{

#ifndef OMITBAD

static void badSink(struct _twoIntsStruct * data)
{
    
    ; 
}

void bad()
{
    struct _twoIntsStruct * data;
    
    void (*funcPtr) (struct _twoIntsStruct *) = badSink;
    data = NULL;
    
    data = new struct _twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(struct _twoIntsStruct * data)
{
    
    ; 
}

static void goodG2B()
{
    struct _twoIntsStruct * data;
    void (*funcPtr) (struct _twoIntsStruct *) = goodG2BSink;
    data = NULL;
    
    struct _twoIntsStruct dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    funcPtr(data);
}


static void goodB2GSink(struct _twoIntsStruct * data)
{
    
    delete data;
}

static void goodB2G()
{
    struct _twoIntsStruct * data;
    void (*funcPtr) (struct _twoIntsStruct *) = goodB2GSink;
    data = NULL;
    
    data = new struct _twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_twoIntsStruct_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
