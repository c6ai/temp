


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_51
{

#ifndef OMITBAD

void badSink(struct _twoIntsStruct * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(struct _twoIntsStruct * data)
{
    
    ; 
}


void goodB2GSink(struct _twoIntsStruct * data)
{
    
    delete data;
}

#endif 

} 
