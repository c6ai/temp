


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_54
{

#ifndef OMITBAD


void badSink_d(struct _twoIntsStruct * data);

void badSink_c(struct _twoIntsStruct * data)
{
    badSink_d(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(struct _twoIntsStruct * data);

void goodG2BSink_c(struct _twoIntsStruct * data)
{
    goodG2BSink_d(data);
}


void goodB2GSink_d(struct _twoIntsStruct * data);

void goodB2GSink_c(struct _twoIntsStruct * data)
{
    goodB2GSink_d(data);
}

#endif 

} 
