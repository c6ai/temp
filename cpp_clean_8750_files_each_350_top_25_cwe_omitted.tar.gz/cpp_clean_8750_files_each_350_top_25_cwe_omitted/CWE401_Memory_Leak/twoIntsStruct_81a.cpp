


#include "std_testcase.h"
#include "twoIntsStruct_81.h"

namespace twoIntsStruct_81
{

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    
    data = new twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    const twoIntsStruct_81_base& o = twoIntsStruct_81_bad();
    o.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    twoIntsStruct * data;
    data = NULL;
    
    twoIntsStruct dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    const twoIntsStruct_81_base& baseObject = twoIntsStruct_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    twoIntsStruct * data;
    data = NULL;
    
    data = new twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine(data);
    const twoIntsStruct_81_base& baseObject = twoIntsStruct_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
