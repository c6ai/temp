


#include "std_testcase.h"
#include "twoIntsStruct_calloc_81.h"

namespace twoIntsStruct_calloc_81
{

#ifndef OMITBAD

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    data = (struct _twoIntsStruct *)calloc(100, sizeof(struct _twoIntsStruct));
    if (data == NULL) {exit(-1);}
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine((twoIntsStruct *)&data[0]);
    const twoIntsStruct_calloc_81_base& baseObject = twoIntsStruct_calloc_81_bad();
    baseObject.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    data = (struct _twoIntsStruct *)ALLOCA(100*sizeof(struct _twoIntsStruct));
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine((twoIntsStruct *)&data[0]);
    const twoIntsStruct_calloc_81_base& baseObject = twoIntsStruct_calloc_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    data = (struct _twoIntsStruct *)calloc(100, sizeof(struct _twoIntsStruct));
    if (data == NULL) {exit(-1);}
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine((twoIntsStruct *)&data[0]);
    const twoIntsStruct_calloc_81_base& baseObject = twoIntsStruct_calloc_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_calloc_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
