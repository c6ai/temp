


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_53
{

#ifndef OMITBAD


void badSink_c(wchar_t * data);

void badSink_b(wchar_t * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(wchar_t * data);

void goodG2BSink_b(wchar_t * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(wchar_t * data);

void goodB2GSink_b(wchar_t * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
