


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_11
{

#ifndef OMITBAD

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


static void goodB2G2()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(globalReturnsTrue())
    {
        
        delete data;
    }
}


static void goodG2B1()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(globalReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        struct _twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}


static void goodG2B2()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(globalReturnsTrue())
    {
        
        struct _twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(globalReturnsTrue())
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_twoIntsStruct_11; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
