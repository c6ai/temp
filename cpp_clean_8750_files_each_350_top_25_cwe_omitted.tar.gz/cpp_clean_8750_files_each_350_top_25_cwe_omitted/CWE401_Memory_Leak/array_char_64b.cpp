


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_char_64
{

#ifndef OMITBAD

void badSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    ; 
}


void goodB2GSink(void * dataVoidPtr)
{
    
    char * * dataPtr = (char * *)dataVoidPtr;
    
    char * data = (*dataPtr);
    
    delete[] data;
}

#endif 

} 
