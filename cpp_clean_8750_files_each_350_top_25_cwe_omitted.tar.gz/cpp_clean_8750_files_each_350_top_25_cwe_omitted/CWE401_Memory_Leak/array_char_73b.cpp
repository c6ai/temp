


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace array_char_73
{

#ifndef OMITBAD

void badSink(list<char *> dataList)
{
    
    char * data = dataList.back();
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<char *> dataList)
{
    char * data = dataList.back();
    
    ; 
}


void goodB2GSink(list<char *> dataList)
{
    char * data = dataList.back();
    
    delete[] data;
}

#endif 

} 
