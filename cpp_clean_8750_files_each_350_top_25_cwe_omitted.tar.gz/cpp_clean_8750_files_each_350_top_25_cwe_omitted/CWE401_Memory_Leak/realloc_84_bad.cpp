

#ifndef OMITBAD

#include "std_testcase.h"
#include "realloc_84.h"

namespace realloc_84
{
realloc_84_bad::realloc_84_bad(char * dataCopy)
{
    data = dataCopy;
    
    data = (char *)realloc(data, 100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
}

realloc_84_bad::~realloc_84_bad()
{
    
    ; 
}
}
#endif 
