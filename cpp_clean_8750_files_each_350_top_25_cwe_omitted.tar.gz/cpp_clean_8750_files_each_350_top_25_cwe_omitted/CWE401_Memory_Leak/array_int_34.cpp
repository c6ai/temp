


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int_34
{

typedef union
{
    int * unionFirst;
    int * unionSecond;
} unionType;

#ifndef OMITBAD

void bad()
{
    int * data;
    unionType myUnion;
    data = NULL;
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    myUnion.unionFirst = data;
    {
        int * data = myUnion.unionSecond;
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int * data;
    unionType myUnion;
    data = NULL;
    
    int dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    data[0] = 5;
    printIntLine(data[0]);
    myUnion.unionFirst = data;
    {
        int * data = myUnion.unionSecond;
        
        ; 
    }
}


static void goodB2G()
{
    int * data;
    unionType myUnion;
    data = NULL;
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    myUnion.unionFirst = data;
    {
        int * data = myUnion.unionSecond;
        
        delete[] data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_int_34; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
