


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int64_t_44
{

#ifndef OMITBAD

static void badSink(int64_t * data)
{
    
    ; 
}

void bad()
{
    int64_t * data;
    
    void (*funcPtr) (int64_t *) = badSink;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(int64_t * data)
{
    
    ; 
}

static void goodG2B()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = goodG2BSink;
    data = NULL;
    
    int64_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 5LL;
    printLongLongLine(*data);
    funcPtr(data);
}


static void goodB2GSink(int64_t * data)
{
    
    delete data;
}

static void goodB2G()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = goodB2GSink;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
