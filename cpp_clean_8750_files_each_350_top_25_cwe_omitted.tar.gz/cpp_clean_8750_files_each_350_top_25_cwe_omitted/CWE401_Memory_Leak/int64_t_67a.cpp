


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int64_t_67
{

typedef struct _structType
{
    int64_t * structFirst;
} structType;

#ifndef OMITBAD


void badSink(structType myStruct);

void bad()
{
    int64_t * data;
    structType myStruct;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    myStruct.structFirst = data;
    badSink(myStruct);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct);

static void goodG2B()
{
    int64_t * data;
    structType myStruct;
    data = NULL;
    
    int64_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 5LL;
    printLongLongLine(*data);
    myStruct.structFirst = data;
    goodG2BSink(myStruct);
}


void goodB2GSink(structType myStruct);

static void goodB2G()
{
    int64_t * data;
    structType myStruct;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    myStruct.structFirst = data;
    goodB2GSink(myStruct);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_67; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
