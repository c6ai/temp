

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_twointsStruct_82.h"

namespace array_twointsStruct_82
{

void array_twointsStruct_82_goodG2B::action(twoIntsStruct * data)
{
    
    ; 
}

}
#endif 
