


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace char_65
{

#ifndef OMITBAD


void badSink(char * data);

void bad()
{
    char * data;
    
    void (*funcPtr) (char *) = badSink;
    data = NULL;
    
    data = new char;
    
    *data = 'A';
    printHexCharLine(*data);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * data);

static void goodG2B()
{
    char * data;
    void (*funcPtr) (char *) = goodG2BSink;
    data = NULL;
    
    char dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 'A';
    printHexCharLine(*data);
    funcPtr(data);
}


void goodB2GSink(char * data);

static void goodB2G()
{
    char * data;
    void (*funcPtr) (char *) = goodB2GSink;
    data = NULL;
    
    data = new char;
    
    *data = 'A';
    printHexCharLine(*data);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
