


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace char_67
{

typedef struct _structType
{
    char * structFirst;
} structType;

#ifndef OMITBAD


void badSink(structType myStruct);

void bad()
{
    char * data;
    structType myStruct;
    data = NULL;
    
    data = new char;
    
    *data = 'A';
    printHexCharLine(*data);
    myStruct.structFirst = data;
    badSink(myStruct);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct);

static void goodG2B()
{
    char * data;
    structType myStruct;
    data = NULL;
    
    char dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 'A';
    printHexCharLine(*data);
    myStruct.structFirst = data;
    goodG2BSink(myStruct);
}


void goodB2GSink(structType myStruct);

static void goodB2G()
{
    char * data;
    structType myStruct;
    data = NULL;
    
    data = new char;
    
    *data = 'A';
    printHexCharLine(*data);
    myStruct.structFirst = data;
    goodB2GSink(myStruct);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_67; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
