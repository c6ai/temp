

#ifndef OMITGOOD

#include "std_testcase.h"
#include "t_calloc_83.h"

namespace t_calloc_83
{
t_calloc_83_goodG2B::t_calloc_83_goodG2B(int64_t * dataCopy)
{
    data = dataCopy;
    
    data = (int64_t *)ALLOCA(100*sizeof(int64_t));
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
}

t_calloc_83_goodG2B::~t_calloc_83_goodG2B()
{
    
    ; 
}
}
#endif 
