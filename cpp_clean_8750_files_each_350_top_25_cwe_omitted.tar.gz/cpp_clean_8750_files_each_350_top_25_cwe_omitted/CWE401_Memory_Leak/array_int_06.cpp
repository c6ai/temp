


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif


static const int STATIC_CONST_FIVE = 5;

namespace array_int_06
{

#ifndef OMITBAD

void bad()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new int[100];
        
        data[0] = 5;
        printIntLine(data[0]);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new int[100];
        
        data[0] = 5;
        printIntLine(data[0]);
    }
    if(STATIC_CONST_FIVE!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete[] data;
    }
}


static void goodB2G2()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new int[100];
        
        data[0] = 5;
        printIntLine(data[0]);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        delete[] data;
    }
}


static void goodG2B1()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        int dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0] = 5;
        printIntLine(data[0]);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}


static void goodG2B2()
{
    int * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        int dataGoodBuffer[100];
        data = dataGoodBuffer;
        
        data[0] = 5;
        printIntLine(data[0]);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_06; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
