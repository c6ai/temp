


#include "std_testcase.h"
#include "t_calloc_84.h"

namespace t_calloc_84
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL;
    t_calloc_84_bad * badObject = new t_calloc_84_bad(data);
    delete badObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int64_t * data;
    data = NULL;
    t_calloc_84_goodG2B * goodG2BObject = new t_calloc_84_goodG2B(data);
    delete goodG2BObject;
}


static void goodB2G()
{
    int64_t * data;
    data = NULL;
    t_calloc_84_goodB2G * goodB2GObject = new t_calloc_84_goodB2G(data);
    delete goodB2GObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace t_calloc_84; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
