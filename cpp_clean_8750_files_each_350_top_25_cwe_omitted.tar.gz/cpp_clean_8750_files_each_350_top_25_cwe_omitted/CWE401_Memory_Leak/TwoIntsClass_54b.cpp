


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace TwoIntsClass_54
{

#ifndef OMITBAD


void badSink_c(TwoIntsClass * data);

void badSink_b(TwoIntsClass * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(TwoIntsClass * data);

void goodG2BSink_b(TwoIntsClass * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(TwoIntsClass * data);

void goodB2GSink_b(TwoIntsClass * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
