


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace twoIntsStruct_54
{

#ifndef OMITBAD

void badSink_e(twoIntsStruct * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(twoIntsStruct * data)
{
    
    ; 
}


void goodB2GSink_e(twoIntsStruct * data)
{
    
    delete data;
}

#endif 

} 
