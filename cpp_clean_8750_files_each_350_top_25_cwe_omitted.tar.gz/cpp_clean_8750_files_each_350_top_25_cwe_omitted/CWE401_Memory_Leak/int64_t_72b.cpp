


#include "std_testcase.h"
#include <vector>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace int64_t_72
{

#ifndef OMITBAD

void badSink(vector<int64_t *> dataVector)
{
    
    int64_t * data = dataVector[2];
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<int64_t *> dataVector)
{
    int64_t * data = dataVector[2];
    
    ; 
}


void goodB2GSink(vector<int64_t *> dataVector)
{
    int64_t * data = dataVector[2];
    
    delete data;
}

#endif 

} 
