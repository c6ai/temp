


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif


static const int STATIC_CONST_FIVE = 5;

namespace twoIntsStruct_06
{

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine(data);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    twoIntsStruct * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine(data);
    }
    if(STATIC_CONST_FIVE!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


static void goodB2G2()
{
    twoIntsStruct * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        data = new twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine(data);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        delete data;
    }
}


static void goodG2B1()
{
    twoIntsStruct * data;
    data = NULL;
    if(STATIC_CONST_FIVE!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine(data);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}


static void goodG2B2()
{
    twoIntsStruct * data;
    data = NULL;
    if(STATIC_CONST_FIVE==5)
    {
        
        twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine(data);
    }
    if(STATIC_CONST_FIVE==5)
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace twoIntsStruct_06; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
