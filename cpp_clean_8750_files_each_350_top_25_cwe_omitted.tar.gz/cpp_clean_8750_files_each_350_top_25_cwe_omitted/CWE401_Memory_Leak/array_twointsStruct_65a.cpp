


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_twointsStruct_65
{

#ifndef OMITBAD


void badSink(twoIntsStruct * data);

void bad()
{
    twoIntsStruct * data;
    
    void (*funcPtr) (twoIntsStruct *) = badSink;
    data = NULL;
    
    data = new twoIntsStruct[100];
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine(&data[0]);
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(twoIntsStruct * data);

static void goodG2B()
{
    twoIntsStruct * data;
    void (*funcPtr) (twoIntsStruct *) = goodG2BSink;
    data = NULL;
    
    twoIntsStruct dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine(&data[0]);
    funcPtr(data);
}


void goodB2GSink(twoIntsStruct * data);

static void goodB2G()
{
    twoIntsStruct * data;
    void (*funcPtr) (twoIntsStruct *) = goodB2GSink;
    data = NULL;
    
    data = new twoIntsStruct[100];
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine(&data[0]);
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_twointsStruct_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
