

#ifndef OMITGOOD

#include "std_testcase.h"
#include "realloc_82.h"

namespace realloc_82
{

void realloc_82_goodG2B::action(twoIntsStruct * data)
{
    
    ; 
}

}
#endif 
