


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace TwoIntsClass_31
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    data = NULL;
    
    data = new TwoIntsClass;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    TwoIntsClass * data;
    data = NULL;
    
    TwoIntsClass dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        ; 
    }
}


static void goodB2G()
{
    TwoIntsClass * data;
    data = NULL;
    
    data = new TwoIntsClass;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    {
        TwoIntsClass * dataCopy = data;
        TwoIntsClass * data = dataCopy;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace TwoIntsClass_31; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
