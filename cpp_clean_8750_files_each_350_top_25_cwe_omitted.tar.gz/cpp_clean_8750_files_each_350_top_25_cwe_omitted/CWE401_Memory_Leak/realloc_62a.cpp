


#include "std_testcase.h"

#include <wchar.h>

namespace realloc_62
{

#ifndef OMITBAD


void badSource(twoIntsStruct * &data);

void bad()
{
    twoIntsStruct * data;
    data = NULL;
    badSource(data);
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(twoIntsStruct * &data);

static void goodG2B()
{
    twoIntsStruct * data;
    data = NULL;
    goodG2BSource(data);
    
    ; 
}


void goodB2GSource(twoIntsStruct * &data);

static void goodB2G()
{
    twoIntsStruct * data;
    data = NULL;
    goodB2GSource(data);
    
    free(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace realloc_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
