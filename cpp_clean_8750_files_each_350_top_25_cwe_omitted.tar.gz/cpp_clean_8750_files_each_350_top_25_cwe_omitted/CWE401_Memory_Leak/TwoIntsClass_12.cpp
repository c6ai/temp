


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace TwoIntsClass_12
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        data = new TwoIntsClass;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    else
    {
        
        TwoIntsClass dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        ; 
    }
    else
    {
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    TwoIntsClass * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        data = new TwoIntsClass;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    else
    {
        
        data = new TwoIntsClass;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        delete data;
    }
    else
    {
        
        delete data;
    }
}


static void goodG2B()
{
    TwoIntsClass * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        
        TwoIntsClass dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    else
    {
        
        TwoIntsClass dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printIntLine(data->intOne);
        printIntLine(data->intTwo);
    }
    if(globalReturnsTrueOrFalse())
    {
        
        ; 
    }
    else
    {
        
        ; 
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace TwoIntsClass_12; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
