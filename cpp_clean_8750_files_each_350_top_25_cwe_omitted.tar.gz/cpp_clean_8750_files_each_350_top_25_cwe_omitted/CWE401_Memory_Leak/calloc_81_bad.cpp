

#ifndef OMITBAD

#include "std_testcase.h"
#include "calloc_81.h"

namespace calloc_81
{

void calloc_81_bad::action(char * data) const
{
    
    ; 
}

}
#endif 
