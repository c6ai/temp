


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int_67
{

typedef struct _structType
{
    int * structFirst;
} structType;

#ifndef OMITBAD

void badSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    ; 
}


void goodB2GSink(structType myStruct)
{
    int * data = myStruct.structFirst;
    
    delete data;
}

#endif 

} 
