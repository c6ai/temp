

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_twointsStruct_81.h"

namespace array_twointsStruct_81
{

void array_twointsStruct_81_goodG2B::action(twoIntsStruct * data) const
{
    
    ; 
}

}
#endif 
