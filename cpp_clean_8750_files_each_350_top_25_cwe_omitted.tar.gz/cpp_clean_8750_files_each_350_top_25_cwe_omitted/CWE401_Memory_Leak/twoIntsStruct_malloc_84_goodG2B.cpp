

#ifndef OMITGOOD

#include "std_testcase.h"
#include "twoIntsStruct_malloc_84.h"

namespace twoIntsStruct_malloc_84
{
twoIntsStruct_malloc_84_goodG2B::twoIntsStruct_malloc_84_goodG2B(struct _twoIntsStruct * dataCopy)
{
    data = dataCopy;
    
    data = (struct _twoIntsStruct *)ALLOCA(100*sizeof(struct _twoIntsStruct));
    
    data[0].intOne = 0;
    data[0].intTwo = 0;
    printStructLine((twoIntsStruct *)&data[0]);
}

twoIntsStruct_malloc_84_goodG2B::~twoIntsStruct_malloc_84_goodG2B()
{
    
    ; 
}
}
#endif 
