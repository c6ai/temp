


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace array_int_73
{

#ifndef OMITBAD

void badSink(list<int *> dataList)
{
    
    int * data = dataList.back();
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<int *> dataList)
{
    int * data = dataList.back();
    
    ; 
}


void goodB2GSink(list<int *> dataList)
{
    int * data = dataList.back();
    
    delete[] data;
}

#endif 

} 
