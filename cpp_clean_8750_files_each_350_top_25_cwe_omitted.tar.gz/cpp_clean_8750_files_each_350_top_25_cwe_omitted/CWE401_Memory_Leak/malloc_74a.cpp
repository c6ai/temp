


#include "std_testcase.h"
#include <map>

#include <wchar.h>

using namespace std;

namespace malloc_74
{

#ifndef OMITBAD


void badSink(map<int, char *> dataMap);

void bad()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    
    data = (char *)malloc(100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    badSink(dataMap);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, char *> dataMap);

static void goodG2B()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    
    data = (char *)ALLOCA(100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodG2BSink(dataMap);
}


void goodB2GSink(map<int, char *> dataMap);

static void goodB2G()
{
    char * data;
    map<int, char *> dataMap;
    data = NULL;
    
    data = (char *)malloc(100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodB2GSink(dataMap);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace malloc_74; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
