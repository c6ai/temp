

#ifndef OMITGOOD

#include "std_testcase.h"
#include "calloc_82.h"

namespace calloc_82
{

void calloc_82_goodG2B::action(twoIntsStruct * data)
{
    
    ; 
}

}
#endif 
