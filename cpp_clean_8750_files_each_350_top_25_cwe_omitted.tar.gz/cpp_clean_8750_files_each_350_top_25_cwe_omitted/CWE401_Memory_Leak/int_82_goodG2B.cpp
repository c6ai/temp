

#ifndef OMITGOOD

#include "std_testcase.h"
#include "int_82.h"

namespace int_82
{

void int_82_goodG2B::action(int * data)
{
    
    ; 
}

}
#endif 
