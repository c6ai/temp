


#include "std_testcase.h"
#include <vector>

#include <wchar.h>

using namespace std;

namespace t_malloc_72
{

#ifndef OMITBAD


void badSink(vector<int64_t *> dataVector);

void bad()
{
    int64_t * data;
    vector<int64_t *> dataVector;
    data = NULL;
    
    data = (int64_t *)malloc(100*sizeof(int64_t));
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    badSink(dataVector);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<int64_t *> dataVector);

static void goodG2B()
{
    int64_t * data;
    vector<int64_t *> dataVector;
    data = NULL;
    
    data = (int64_t *)ALLOCA(100*sizeof(int64_t));
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodG2BSink(dataVector);
}


void goodB2GSink(vector<int64_t *> dataVector);

static void goodB2G()
{
    int64_t * data;
    vector<int64_t *> dataVector;
    data = NULL;
    
    data = (int64_t *)malloc(100*sizeof(int64_t));
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodB2GSink(dataVector);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace t_malloc_72; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
