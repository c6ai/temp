


#include "std_testcase.h"
#include "calloc_81.h"

namespace calloc_81
{

#ifndef OMITBAD

void bad()
{
    char * data;
    data = NULL;
    
    data = (char *)calloc(100, sizeof(char));
    if (data == NULL) {exit(-1);}
    
    strcpy(data, "A String");
    printLine(data);
    const calloc_81_base& baseObject = calloc_81_bad();
    baseObject.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    char * data;
    data = NULL;
    
    data = (char *)ALLOCA(100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
    const calloc_81_base& baseObject = calloc_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    char * data;
    data = NULL;
    
    data = (char *)calloc(100, sizeof(char));
    if (data == NULL) {exit(-1);}
    
    strcpy(data, "A String");
    printLine(data);
    const calloc_81_base& baseObject = calloc_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace calloc_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
