


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace twoIntsStruct_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(twoIntsStruct * data)
{
    if(badGlobal)
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(twoIntsStruct * data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


void goodB2G2Sink(twoIntsStruct * data)
{
    if(goodB2G2Global)
    {
        
        delete data;
    }
}


void goodG2B1Sink(twoIntsStruct * data)
{
    if(goodG2B1Global)
    {
        
        ; 
    }
}

#endif 

} 
