


#include "std_testcase.h"
#include "array_wchar_t_82.h"

namespace array_wchar_t_82
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    data = NULL;
    
    data = new wchar_t[100];
    
    wcscpy(data, L"A String");
    printWLine(data);
    array_wchar_t_82_base* baseObject = new array_wchar_t_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    wchar_t * data;
    data = NULL;
    
    wchar_t dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    wcscpy(data, L"A String");
    printWLine(data);
    array_wchar_t_82_base* baseObject = new array_wchar_t_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    wchar_t * data;
    data = NULL;
    
    data = new wchar_t[100];
    
    wcscpy(data, L"A String");
    printWLine(data);
    array_wchar_t_82_base* baseObject = new array_wchar_t_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_wchar_t_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
