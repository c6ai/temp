


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace struct_twoIntsStruct_53
{

#ifndef OMITBAD


void badSink_b(struct _twoIntsStruct * data);

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    data = new struct _twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(struct _twoIntsStruct * data);

static void goodG2B()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    struct _twoIntsStruct dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    goodG2BSink_b(data);
}


void goodB2GSink_b(struct _twoIntsStruct * data);

static void goodB2G()
{
    struct _twoIntsStruct * data;
    data = NULL;
    
    data = new struct _twoIntsStruct;
    
    data->intOne = 0;
    data->intTwo = 0;
    printStructLine((twoIntsStruct *)data);
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_twoIntsStruct_53; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
