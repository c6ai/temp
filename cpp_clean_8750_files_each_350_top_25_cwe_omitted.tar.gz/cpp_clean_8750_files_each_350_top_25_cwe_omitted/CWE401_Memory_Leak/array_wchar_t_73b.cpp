


#include "std_testcase.h"
#include <list>

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace array_wchar_t_73
{

#ifndef OMITBAD

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    
    ; 
}


void goodB2GSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    
    delete[] data;
}

#endif 

} 
