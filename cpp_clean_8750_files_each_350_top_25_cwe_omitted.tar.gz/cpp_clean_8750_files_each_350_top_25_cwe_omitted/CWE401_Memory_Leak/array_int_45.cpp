


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace array_int_45
{

static int * badData;
static int * goodG2BData;
static int * goodB2GData;

#ifndef OMITBAD

static void badSink()
{
    int * data = badData;
    
    ; 
}

void bad()
{
    int * data;
    data = NULL;
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    badData = data;
    badSink();
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink()
{
    int * data = goodG2BData;
    
    ; 
}

static void goodG2B()
{
    int * data;
    data = NULL;
    
    int dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    data[0] = 5;
    printIntLine(data[0]);
    goodG2BData = data;
    goodG2BSink();
}


static void goodB2GSink()
{
    int * data = goodB2GData;
    
    delete[] data;
}

static void goodB2G()
{
    int * data;
    data = NULL;
    
    data = new int[100];
    
    data[0] = 5;
    printIntLine(data[0]);
    goodB2GData = data;
    goodB2GSink();
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_45; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
