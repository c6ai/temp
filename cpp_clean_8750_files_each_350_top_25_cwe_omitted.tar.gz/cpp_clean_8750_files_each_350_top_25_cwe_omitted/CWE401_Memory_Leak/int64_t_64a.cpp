


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int64_t_64
{

#ifndef OMITBAD


void badSink(void * dataVoidPtr);

void bad()
{
    int64_t * data;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr);

static void goodG2B()
{
    int64_t * data;
    data = NULL;
    
    int64_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 5LL;
    printLongLongLine(*data);
    goodG2BSink(&data);
}


void goodB2GSink(void * dataVoidPtr);

static void goodB2G()
{
    int64_t * data;
    data = NULL;
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_64; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
