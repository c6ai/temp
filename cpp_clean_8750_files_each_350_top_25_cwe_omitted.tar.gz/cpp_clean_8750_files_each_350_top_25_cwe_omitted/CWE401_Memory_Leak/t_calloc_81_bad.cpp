

#ifndef OMITBAD

#include "std_testcase.h"
#include "t_calloc_81.h"

namespace t_calloc_81
{

void t_calloc_81_bad::action(int64_t * data) const
{
    
    ; 
}

}
#endif 
