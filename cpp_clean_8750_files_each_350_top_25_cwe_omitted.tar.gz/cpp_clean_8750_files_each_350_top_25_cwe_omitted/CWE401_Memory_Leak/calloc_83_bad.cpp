

#ifndef OMITBAD

#include "std_testcase.h"
#include "calloc_83.h"

namespace calloc_83
{
calloc_83_bad::calloc_83_bad(char * dataCopy)
{
    data = dataCopy;
    
    data = (char *)calloc(100, sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
}

calloc_83_bad::~calloc_83_bad()
{
    
    ; 
}
}
#endif 
