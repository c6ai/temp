

#ifndef OMITBAD

#include "std_testcase.h"
#include "char_83.h"

namespace char_83
{
char_83_bad::char_83_bad(char * dataCopy)
{
    data = dataCopy;
    {
        char myString[] = "myString";
        
        data = strdup(myString);
        
        printLine(data);
    }
}

char_83_bad::~char_83_bad()
{
    
    
    ; 
}
}
#endif 
