

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_struct_twoIntsStruct_82.h"

namespace array_struct_twoIntsStruct_82
{

void array_struct_twoIntsStruct_82_goodG2B::action(struct _twoIntsStruct * data)
{
    
    ; 
}

}
#endif 
