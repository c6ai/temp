

#ifndef OMITGOOD

#include "std_testcase.h"
#include "malloc_84.h"

namespace malloc_84
{
malloc_84_goodB2G::malloc_84_goodB2G(char * dataCopy)
{
    data = dataCopy;
    
    data = (char *)malloc(100*sizeof(char));
    
    strcpy(data, "A String");
    printLine(data);
}

malloc_84_goodB2G::~malloc_84_goodB2G()
{
    
    free(data);
}
}
#endif 
