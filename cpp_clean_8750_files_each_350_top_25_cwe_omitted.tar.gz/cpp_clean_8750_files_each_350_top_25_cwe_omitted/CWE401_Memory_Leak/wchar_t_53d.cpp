


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_53
{

#ifndef OMITBAD

void badSink_d(wchar_t * data)
{
    
    ; 
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(wchar_t * data)
{
    
    ; 
}


void goodB2GSink_d(wchar_t * data)
{
    
    delete data;
}

#endif 

} 
