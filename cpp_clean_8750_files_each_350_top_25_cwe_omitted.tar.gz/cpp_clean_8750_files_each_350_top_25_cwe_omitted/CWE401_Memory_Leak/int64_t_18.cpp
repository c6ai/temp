


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace int64_t_18
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL;
    goto source;
source:
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    goto sink;
sink:
    
    ; 
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int64_t * data;
    data = NULL;
    goto source;
source:
    
    data = new int64_t;
    
    *data = 5LL;
    printLongLongLine(*data);
    goto sink;
sink:
    
    delete data;
}


static void goodG2B()
{
    int64_t * data;
    data = NULL;
    goto source;
source:
    
    int64_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = 5LL;
    printLongLongLine(*data);
    goto sink;
sink:
    
    ; 
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_18; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
