

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_modulo_81.h"

namespace fscanf_modulo_81
{

void fscanf_modulo_81_goodG2B::action(int data) const
{
    
    printIntLine(100 % data);
}

}
#endif 
