


#include "std_testcase.h"
#include "zero_modulo_84.h"

namespace zero_modulo_84
{

#ifndef OMITBAD

void bad()
{
    int data;
    
    data = -1;
    zero_modulo_84_bad * badObject = new zero_modulo_84_bad(data);
    delete badObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int data;
    
    data = -1;
    zero_modulo_84_goodG2B * goodG2BObject = new zero_modulo_84_goodG2B(data);
    delete goodG2BObject;
}


static void goodB2G()
{
    int data;
    
    data = -1;
    zero_modulo_84_goodB2G * goodB2GObject = new zero_modulo_84_goodB2G(data);
    delete goodB2GObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace zero_modulo_84; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
