

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_84.h"

namespace rand_84
{
rand_84_goodB2G::rand_84_goodB2G(float dataCopy)
{
    data = dataCopy;
    
    data = (float)RAND32();
}

rand_84_goodB2G::~rand_84_goodB2G()
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
