

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_82.h"

namespace fgets_82
{

void fgets_82_bad::action(float data)
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
