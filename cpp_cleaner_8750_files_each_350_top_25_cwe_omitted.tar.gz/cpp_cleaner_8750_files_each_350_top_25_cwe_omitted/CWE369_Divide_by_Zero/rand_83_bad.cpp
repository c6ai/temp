

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_83.h"

namespace rand_83
{
rand_83_bad::rand_83_bad(float dataCopy)
{
    data = dataCopy;
    
    data = (float)RAND32();
}

rand_83_bad::~rand_83_bad()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
