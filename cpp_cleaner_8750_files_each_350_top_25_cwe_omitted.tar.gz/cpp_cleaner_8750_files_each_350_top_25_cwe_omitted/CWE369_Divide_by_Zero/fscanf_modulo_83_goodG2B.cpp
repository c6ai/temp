

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_modulo_83.h"

namespace fscanf_modulo_83
{
fscanf_modulo_83_goodG2B::fscanf_modulo_83_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

fscanf_modulo_83_goodG2B::~fscanf_modulo_83_goodG2B()
{
    
    printIntLine(100 % data);
}
}
#endif 
