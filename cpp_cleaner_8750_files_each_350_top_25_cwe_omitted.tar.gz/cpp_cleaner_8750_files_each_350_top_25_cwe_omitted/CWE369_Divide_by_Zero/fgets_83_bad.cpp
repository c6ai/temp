

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_83.h"

#define CHAR_ARRAY_SIZE 20

namespace fgets_83
{
fgets_83_bad::fgets_83_bad(float dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

fgets_83_bad::~fgets_83_bad()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
