


#include "std_testcase.h"
#include <list>

#include <math.h>

#define CHAR_ARRAY_SIZE 20

using namespace std;

namespace fgets_73
{

#ifndef OMITBAD


void badSink(list<float> dataList);

void bad()
{
    float data;
    list<float> dataList;
    
    data = 0.0F;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    badSink(dataList);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<float> dataList);

static void goodG2B()
{
    float data;
    list<float> dataList;
    
    data = 0.0F;
    
    data = 2.0F;
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodG2BSink(dataList);
}


void goodB2GSink(list<float> dataList);

static void goodB2G()
{
    float data;
    list<float> dataList;
    
    data = 0.0F;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodB2GSink(dataList);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fgets_73; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
