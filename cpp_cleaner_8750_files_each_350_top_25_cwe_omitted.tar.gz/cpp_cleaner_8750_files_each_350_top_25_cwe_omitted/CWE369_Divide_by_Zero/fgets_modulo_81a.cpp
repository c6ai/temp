


#include "std_testcase.h"
#include "fgets_modulo_81.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_modulo_81
{

#ifndef OMITBAD

void bad()
{
    int data;
    
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    const fgets_modulo_81_base& baseObject = fgets_modulo_81_bad();
    baseObject.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int data;
    
    data = -1;
    
    data = 7;
    const fgets_modulo_81_base& baseObject = fgets_modulo_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    int data;
    
    data = -1;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
    const fgets_modulo_81_base& baseObject = fgets_modulo_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fgets_modulo_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
