

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_divide_82.h"

namespace fscanf_divide_82
{

void fscanf_divide_82_goodB2G::action(int data)
{
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
