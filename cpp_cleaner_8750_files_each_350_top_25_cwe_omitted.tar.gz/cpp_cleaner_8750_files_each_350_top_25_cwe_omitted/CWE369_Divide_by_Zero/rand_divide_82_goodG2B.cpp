

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_divide_82.h"

namespace rand_divide_82
{

void rand_divide_82_goodG2B::action(int data)
{
    
    printIntLine(100 / data);
}

}
#endif 
