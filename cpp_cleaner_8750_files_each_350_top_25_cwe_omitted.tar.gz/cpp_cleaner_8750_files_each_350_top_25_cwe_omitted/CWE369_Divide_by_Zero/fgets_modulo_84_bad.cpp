

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_modulo_84.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_modulo_84
{
fgets_modulo_84_bad::fgets_modulo_84_bad(int dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

fgets_modulo_84_bad::~fgets_modulo_84_bad()
{
    
    printIntLine(100 % data);
}
}
#endif 
