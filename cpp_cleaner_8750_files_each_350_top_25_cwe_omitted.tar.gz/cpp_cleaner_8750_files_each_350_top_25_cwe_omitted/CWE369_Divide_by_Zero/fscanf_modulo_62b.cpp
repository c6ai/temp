


#include "std_testcase.h"

namespace fscanf_modulo_62
{

#ifndef OMITBAD

void badSource(int &data)
{
    
    fscanf(stdin, "%d", &data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(int &data)
{
    
    data = 7;
}


void goodB2GSource(int &data)
{
    
    fscanf(stdin, "%d", &data);
}

#endif 

} 
