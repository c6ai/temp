

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_modulo_81.h"

namespace zero_modulo_81
{

void zero_modulo_81_goodG2B::action(int data) const
{
    
    printIntLine(100 % data);
}

}
#endif 
