

#ifndef OMITGOOD

#include "std_testcase.h"
#include "connect_socket_divide_84.h"

#ifdef _WIN32
#include <winsock2.h>
#include <windows.h>
#include <direct.h>
#pragma comment(lib, "ws2_32") 
#define CLOSE_SOCKET closesocket
#else 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define CLOSE_SOCKET close
#define SOCKET int
#endif

#define TCP_PORT 27015
#define IP_ADDRESS "127.0.0.1"
#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace connect_socket_divide_84
{
connect_socket_divide_84_goodG2B::connect_socket_divide_84_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

connect_socket_divide_84_goodG2B::~connect_socket_divide_84_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
