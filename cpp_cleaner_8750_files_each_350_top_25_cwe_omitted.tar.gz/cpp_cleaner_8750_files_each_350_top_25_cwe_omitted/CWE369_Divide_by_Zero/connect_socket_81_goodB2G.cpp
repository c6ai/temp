

#ifndef OMITGOOD

#include "std_testcase.h"
#include "connect_socket_81.h"

namespace connect_socket_81
{

void connect_socket_81_goodB2G::action(float data) const
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
