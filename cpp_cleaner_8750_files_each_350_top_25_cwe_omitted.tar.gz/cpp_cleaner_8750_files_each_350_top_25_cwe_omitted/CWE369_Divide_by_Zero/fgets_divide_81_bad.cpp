

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_divide_81.h"

namespace fgets_divide_81
{

void fgets_divide_81_bad::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
