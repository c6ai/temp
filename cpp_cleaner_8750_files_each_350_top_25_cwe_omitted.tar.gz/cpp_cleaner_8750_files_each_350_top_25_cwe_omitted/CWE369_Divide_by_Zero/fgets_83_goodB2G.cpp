

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_83.h"

#define CHAR_ARRAY_SIZE 20

namespace fgets_83
{
fgets_83_goodB2G::fgets_83_goodB2G(float dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

fgets_83_goodB2G::~fgets_83_goodB2G()
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
