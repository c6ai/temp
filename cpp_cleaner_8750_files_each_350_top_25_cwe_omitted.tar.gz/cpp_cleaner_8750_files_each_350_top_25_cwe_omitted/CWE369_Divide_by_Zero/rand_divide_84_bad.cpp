

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_divide_84.h"

namespace rand_divide_84
{
rand_divide_84_bad::rand_divide_84_bad(int dataCopy)
{
    data = dataCopy;
    
    data = RAND32();
}

rand_divide_84_bad::~rand_divide_84_bad()
{
    
    printIntLine(100 / data);
}
}
#endif 
