

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_83.h"

namespace fscanf_83
{
fscanf_83_goodG2B::fscanf_83_goodG2B(float dataCopy)
{
    data = dataCopy;
    
    data = 2.0F;
}

fscanf_83_goodG2B::~fscanf_83_goodG2B()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
