

#ifndef OMITGOOD

#include "std_testcase.h"
#include "listen_socket_divide_81.h"

namespace listen_socket_divide_81
{

void listen_socket_divide_81_goodB2G::action(int data) const
{
    
    if( data != 0 )
    {
        printIntLine(100 / data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
