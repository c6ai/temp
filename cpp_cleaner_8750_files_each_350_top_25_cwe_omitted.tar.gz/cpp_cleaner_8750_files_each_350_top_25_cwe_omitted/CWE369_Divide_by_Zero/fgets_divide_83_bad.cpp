

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_divide_83.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_divide_83
{
fgets_divide_83_bad::fgets_divide_83_bad(int dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

fgets_divide_83_bad::~fgets_divide_83_bad()
{
    
    printIntLine(100 / data);
}
}
#endif 
