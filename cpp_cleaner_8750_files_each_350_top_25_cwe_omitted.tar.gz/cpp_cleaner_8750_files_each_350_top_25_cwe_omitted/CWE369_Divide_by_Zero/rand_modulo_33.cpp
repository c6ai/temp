


#include "std_testcase.h"

namespace rand_modulo_33
{

#ifndef OMITBAD

void bad()
{
    int data;
    int &dataRef = data;
    
    data = -1;
    
    data = RAND32();
    {
        int data = dataRef;
        
        printIntLine(100 % data);
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int data;
    int &dataRef = data;
    
    data = -1;
    
    data = 7;
    {
        int data = dataRef;
        
        printIntLine(100 % data);
    }
}


static void goodB2G()
{
    int data;
    int &dataRef = data;
    
    data = -1;
    
    data = RAND32();
    {
        int data = dataRef;
        
        if( data != 0 )
        {
            printIntLine(100 % data);
        }
        else
        {
            printLine("This would result in a divide by zero");
        }
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace rand_modulo_33; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
