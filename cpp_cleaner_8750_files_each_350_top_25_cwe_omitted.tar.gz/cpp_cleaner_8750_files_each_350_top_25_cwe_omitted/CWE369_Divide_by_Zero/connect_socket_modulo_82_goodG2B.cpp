

#ifndef OMITGOOD

#include "std_testcase.h"
#include "connect_socket_modulo_82.h"

namespace connect_socket_modulo_82
{

void connect_socket_modulo_82_goodG2B::action(int data)
{
    
    printIntLine(100 % data);
}

}
#endif 
