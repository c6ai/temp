


#include "std_testcase.h"
#include "zero_divide_81.h"

namespace zero_divide_81
{

#ifndef OMITBAD

void bad()
{
    int data;
    
    data = -1;
    
    data = 0;
    const zero_divide_81_base& baseObject = zero_divide_81_bad();
    baseObject.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int data;
    
    data = -1;
    
    data = 7;
    const zero_divide_81_base& baseObject = zero_divide_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    int data;
    
    data = -1;
    
    data = 0;
    const zero_divide_81_base& baseObject = zero_divide_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace zero_divide_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
