

#ifndef OMITBAD

#include "std_testcase.h"
#include "connect_socket_modulo_82.h"

namespace connect_socket_modulo_82
{

void connect_socket_modulo_82_bad::action(int data)
{
    
    printIntLine(100 % data);
}

}
#endif 
