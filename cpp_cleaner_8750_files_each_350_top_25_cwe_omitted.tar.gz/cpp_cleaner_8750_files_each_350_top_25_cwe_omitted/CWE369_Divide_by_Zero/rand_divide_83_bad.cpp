

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_divide_83.h"

namespace rand_divide_83
{
rand_divide_83_bad::rand_divide_83_bad(int dataCopy)
{
    data = dataCopy;
    
    data = RAND32();
}

rand_divide_83_bad::~rand_divide_83_bad()
{
    
    printIntLine(100 / data);
}
}
#endif 
