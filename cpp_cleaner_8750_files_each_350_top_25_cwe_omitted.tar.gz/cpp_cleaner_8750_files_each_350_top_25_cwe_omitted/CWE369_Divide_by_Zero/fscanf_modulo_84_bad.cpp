

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_modulo_84.h"

namespace fscanf_modulo_84
{
fscanf_modulo_84_bad::fscanf_modulo_84_bad(int dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%d", &data);
}

fscanf_modulo_84_bad::~fscanf_modulo_84_bad()
{
    
    printIntLine(100 % data);
}
}
#endif 
