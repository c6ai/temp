


#include "std_testcase.h"
#include <list>

using namespace std;

namespace fscanf_modulo_73
{

#ifndef OMITBAD

void badSink(list<int> dataList)
{
    
    int data = dataList.back();
    
    printIntLine(100 % data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<int> dataList)
{
    int data = dataList.back();
    
    printIntLine(100 % data);
}


void goodB2GSink(list<int> dataList)
{
    int data = dataList.back();
    
    if( data != 0 )
    {
        printIntLine(100 % data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
