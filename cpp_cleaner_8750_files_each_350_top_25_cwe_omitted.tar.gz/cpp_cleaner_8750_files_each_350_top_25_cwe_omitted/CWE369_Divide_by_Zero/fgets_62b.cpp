


#include "std_testcase.h"

#include <math.h>

#define CHAR_ARRAY_SIZE 20

namespace fgets_62
{

#ifndef OMITBAD

void badSource(float &data)
{
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(float &data)
{
    
    data = 2.0F;
}


void goodB2GSource(float &data)
{
    {
        char inputBuffer[CHAR_ARRAY_SIZE];
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = (float)atof(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

#endif 

} 
