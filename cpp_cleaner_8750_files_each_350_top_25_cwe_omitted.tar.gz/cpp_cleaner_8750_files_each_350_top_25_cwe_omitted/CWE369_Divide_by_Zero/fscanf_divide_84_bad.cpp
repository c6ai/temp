

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_divide_84.h"

namespace fscanf_divide_84
{
fscanf_divide_84_bad::fscanf_divide_84_bad(int dataCopy)
{
    data = dataCopy;
    
    fscanf(stdin, "%d", &data);
}

fscanf_divide_84_bad::~fscanf_divide_84_bad()
{
    
    printIntLine(100 / data);
}
}
#endif 
