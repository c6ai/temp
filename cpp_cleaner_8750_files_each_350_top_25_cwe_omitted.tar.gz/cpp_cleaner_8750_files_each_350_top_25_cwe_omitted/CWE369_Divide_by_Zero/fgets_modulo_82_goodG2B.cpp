

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_modulo_82.h"

namespace fgets_modulo_82
{

void fgets_modulo_82_goodG2B::action(int data)
{
    
    printIntLine(100 % data);
}

}
#endif 
