


#include "std_testcase.h"

#include <math.h>

namespace rand_62
{

#ifndef OMITBAD


void badSource(float &data);

void bad()
{
    float data;
    
    data = 0.0F;
    badSource(data);
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(float &data);

static void goodG2B()
{
    float data;
    
    data = 0.0F;
    goodG2BSource(data);
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}


void goodB2GSource(float &data);

static void goodB2G()
{
    float data;
    
    data = 0.0F;
    goodB2GSource(data);
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace rand_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
