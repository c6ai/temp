

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_modulo_84.h"

namespace zero_modulo_84
{
zero_modulo_84_goodB2G::zero_modulo_84_goodB2G(int dataCopy)
{
    data = dataCopy;
    
    data = 0;
}

zero_modulo_84_goodB2G::~zero_modulo_84_goodB2G()
{
    
    if( data != 0 )
    {
        printIntLine(100 % data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
