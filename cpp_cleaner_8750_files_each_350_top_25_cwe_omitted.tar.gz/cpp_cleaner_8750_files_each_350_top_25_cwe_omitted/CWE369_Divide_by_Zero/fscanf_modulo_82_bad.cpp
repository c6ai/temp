

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_modulo_82.h"

namespace fscanf_modulo_82
{

void fscanf_modulo_82_bad::action(int data)
{
    
    printIntLine(100 % data);
}

}
#endif 
