


#include "std_testcase.h"
#include <vector>

#include <math.h>

using namespace std;

namespace fscanf_72
{

#ifndef OMITBAD


void badSink(vector<float> dataVector);

void bad()
{
    float data;
    vector<float> dataVector;
    
    data = 0.0F;
    
    fscanf (stdin, "%f", &data);
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    badSink(dataVector);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<float> dataVector);

static void goodG2B()
{
    float data;
    vector<float> dataVector;
    
    data = 0.0F;
    
    data = 2.0F;
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodG2BSink(dataVector);
}


void goodB2GSink(vector<float> dataVector);

static void goodB2G()
{
    float data;
    vector<float> dataVector;
    
    data = 0.0F;
    
    fscanf (stdin, "%f", &data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodB2GSink(dataVector);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fscanf_72; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
