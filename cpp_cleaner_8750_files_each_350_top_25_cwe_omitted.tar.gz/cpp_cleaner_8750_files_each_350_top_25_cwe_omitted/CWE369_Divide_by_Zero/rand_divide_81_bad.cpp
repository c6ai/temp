

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_divide_81.h"

namespace rand_divide_81
{

void rand_divide_81_bad::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
