

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_divide_84.h"

namespace zero_divide_84
{
zero_divide_84_goodG2B::zero_divide_84_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

zero_divide_84_goodG2B::~zero_divide_84_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
