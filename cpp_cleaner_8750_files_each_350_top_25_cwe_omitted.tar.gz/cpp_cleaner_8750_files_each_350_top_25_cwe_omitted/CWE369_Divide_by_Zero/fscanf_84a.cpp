


#include "std_testcase.h"
#include "fscanf_84.h"

namespace fscanf_84
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    fscanf_84_bad * badObject = new fscanf_84_bad(data);
    delete badObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    fscanf_84_goodG2B * goodG2BObject = new fscanf_84_goodG2B(data);
    delete goodG2BObject;
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    fscanf_84_goodB2G * goodB2GObject = new fscanf_84_goodB2G(data);
    delete goodB2GObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fscanf_84; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
