


#include "std_testcase.h"
#include <list>

#include <math.h>

using namespace std;

namespace connect_socket_73
{

#ifndef OMITBAD

void badSink(list<float> dataList)
{
    
    float data = dataList.back();
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<float> dataList)
{
    float data = dataList.back();
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}


void goodB2GSink(list<float> dataList)
{
    float data = dataList.back();
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
