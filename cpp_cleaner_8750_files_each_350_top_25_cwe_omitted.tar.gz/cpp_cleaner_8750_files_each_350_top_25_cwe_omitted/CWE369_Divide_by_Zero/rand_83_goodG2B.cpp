

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_83.h"

namespace rand_83
{
rand_83_goodG2B::rand_83_goodG2B(float dataCopy)
{
    data = dataCopy;
    
    data = 2.0F;
}

rand_83_goodG2B::~rand_83_goodG2B()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
