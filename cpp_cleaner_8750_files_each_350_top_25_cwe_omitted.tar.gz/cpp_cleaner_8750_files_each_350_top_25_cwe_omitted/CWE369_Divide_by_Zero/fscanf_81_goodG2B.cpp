

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_81.h"

namespace fscanf_81
{

void fscanf_81_goodG2B::action(float data) const
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
