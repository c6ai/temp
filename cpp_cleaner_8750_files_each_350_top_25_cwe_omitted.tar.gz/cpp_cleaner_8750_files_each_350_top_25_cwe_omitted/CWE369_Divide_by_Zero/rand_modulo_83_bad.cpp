

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_modulo_83.h"

namespace rand_modulo_83
{
rand_modulo_83_bad::rand_modulo_83_bad(int dataCopy)
{
    data = dataCopy;
    
    data = RAND32();
}

rand_modulo_83_bad::~rand_modulo_83_bad()
{
    
    printIntLine(100 % data);
}
}
#endif 
