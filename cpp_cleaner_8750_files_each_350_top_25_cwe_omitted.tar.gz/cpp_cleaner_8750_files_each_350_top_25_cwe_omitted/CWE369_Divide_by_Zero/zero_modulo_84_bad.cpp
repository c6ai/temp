

#ifndef OMITBAD

#include "std_testcase.h"
#include "zero_modulo_84.h"

namespace zero_modulo_84
{
zero_modulo_84_bad::zero_modulo_84_bad(int dataCopy)
{
    data = dataCopy;
    
    data = 0;
}

zero_modulo_84_bad::~zero_modulo_84_bad()
{
    
    printIntLine(100 % data);
}
}
#endif 
