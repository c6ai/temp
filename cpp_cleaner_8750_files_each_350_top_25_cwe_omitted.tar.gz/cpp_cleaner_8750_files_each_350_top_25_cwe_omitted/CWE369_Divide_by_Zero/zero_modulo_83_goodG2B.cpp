

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_modulo_83.h"

namespace zero_modulo_83
{
zero_modulo_83_goodG2B::zero_modulo_83_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

zero_modulo_83_goodG2B::~zero_modulo_83_goodG2B()
{
    
    printIntLine(100 % data);
}
}
#endif 
