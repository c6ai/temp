

#ifndef OMITBAD

#include "std_testcase.h"
#include "zero_84.h"

namespace zero_84
{
zero_84_bad::zero_84_bad(float dataCopy)
{
    data = dataCopy;
    
    data = 0.0F;
}

zero_84_bad::~zero_84_bad()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
