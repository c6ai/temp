

#ifndef OMITBAD

#include "std_testcase.h"
#include "connect_socket_divide_81.h"

namespace connect_socket_divide_81
{

void connect_socket_divide_81_bad::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
