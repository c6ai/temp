

#ifndef OMITBAD

#include "std_testcase.h"
#include "fscanf_divide_81.h"

namespace fscanf_divide_81
{

void fscanf_divide_81_bad::action(int data) const
{
    
    printIntLine(100 / data);
}

}
#endif 
