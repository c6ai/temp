


#include "std_testcase.h"
#include "listenSocket_84.h"

namespace listenSocket_84
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    listenSocket_84_bad * badObject = new listenSocket_84_bad(data);
    delete badObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    listenSocket_84_goodG2B * goodG2BObject = new listenSocket_84_goodG2B(data);
    delete goodG2BObject;
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    listenSocket_84_goodB2G * goodB2GObject = new listenSocket_84_goodB2G(data);
    delete goodB2GObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace listenSocket_84; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
