

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_divide_83.h"

namespace zero_divide_83
{
zero_divide_83_goodG2B::zero_divide_83_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

zero_divide_83_goodG2B::~zero_divide_83_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
