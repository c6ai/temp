

#ifndef OMITBAD

#include "std_testcase.h"
#include "zero_81.h"

namespace zero_81
{

void zero_81_bad::action(float data) const
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
