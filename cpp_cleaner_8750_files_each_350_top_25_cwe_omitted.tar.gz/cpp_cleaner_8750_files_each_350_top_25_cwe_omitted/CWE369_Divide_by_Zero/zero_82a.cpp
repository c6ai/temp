


#include "std_testcase.h"
#include "zero_82.h"

namespace zero_82
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    
    data = 0.0F;
    zero_82_base* baseObject = new zero_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    
    data = 2.0F;
    zero_82_base* baseObject = new zero_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    
    data = 0.0F;
    zero_82_base* baseObject = new zero_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace zero_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
