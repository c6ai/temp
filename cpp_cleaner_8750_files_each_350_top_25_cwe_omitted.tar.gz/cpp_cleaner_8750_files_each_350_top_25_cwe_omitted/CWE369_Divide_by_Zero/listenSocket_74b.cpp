


#include "std_testcase.h"
#include <map>

#include <math.h>

using namespace std;

namespace listenSocket_74
{

#ifndef OMITBAD

void badSink(map<int, float> dataMap)
{
    
    float data = dataMap[2];
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, float> dataMap)
{
    float data = dataMap[2];
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}


void goodB2GSink(map<int, float> dataMap)
{
    float data = dataMap[2];
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
