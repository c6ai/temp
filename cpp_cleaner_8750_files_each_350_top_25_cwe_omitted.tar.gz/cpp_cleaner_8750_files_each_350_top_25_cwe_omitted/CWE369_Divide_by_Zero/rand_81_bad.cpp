

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_81.h"

namespace rand_81
{

void rand_81_bad::action(float data) const
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
