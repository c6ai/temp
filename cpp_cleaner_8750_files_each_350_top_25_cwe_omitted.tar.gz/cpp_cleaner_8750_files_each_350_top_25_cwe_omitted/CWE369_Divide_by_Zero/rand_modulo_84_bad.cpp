

#ifndef OMITBAD

#include "std_testcase.h"
#include "rand_modulo_84.h"

namespace rand_modulo_84
{
rand_modulo_84_bad::rand_modulo_84_bad(int dataCopy)
{
    data = dataCopy;
    
    data = RAND32();
}

rand_modulo_84_bad::~rand_modulo_84_bad()
{
    
    printIntLine(100 % data);
}
}
#endif 
