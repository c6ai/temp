

#ifndef OMITBAD

#include "std_testcase.h"
#include "fgets_divide_82.h"

namespace fgets_divide_82
{

void fgets_divide_82_bad::action(int data)
{
    
    printIntLine(100 / data);
}

}
#endif 
