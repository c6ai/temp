

#ifndef OMITGOOD

#include "std_testcase.h"
#include "zero_84.h"

namespace zero_84
{
zero_84_goodG2B::zero_84_goodG2B(float dataCopy)
{
    data = dataCopy;
    
    data = 2.0F;
}

zero_84_goodG2B::~zero_84_goodG2B()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
