

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_modulo_83.h"

#define CHAR_ARRAY_SIZE (3 * sizeof(data) + 2)

namespace fgets_modulo_83
{
fgets_modulo_83_goodB2G::fgets_modulo_83_goodB2G(int dataCopy)
{
    data = dataCopy;
    {
        char inputBuffer[CHAR_ARRAY_SIZE] = "";
        
        if (fgets(inputBuffer, CHAR_ARRAY_SIZE, stdin) != NULL)
        {
            
            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

fgets_modulo_83_goodB2G::~fgets_modulo_83_goodB2G()
{
    
    if( data != 0 )
    {
        printIntLine(100 % data);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}
}
#endif 
