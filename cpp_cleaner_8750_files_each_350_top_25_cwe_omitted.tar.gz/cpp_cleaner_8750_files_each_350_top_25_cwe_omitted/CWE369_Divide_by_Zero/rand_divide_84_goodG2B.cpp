

#ifndef OMITGOOD

#include "std_testcase.h"
#include "rand_divide_84.h"

namespace rand_divide_84
{
rand_divide_84_goodG2B::rand_divide_84_goodG2B(int dataCopy)
{
    data = dataCopy;
    
    data = 7;
}

rand_divide_84_goodG2B::~rand_divide_84_goodG2B()
{
    
    printIntLine(100 / data);
}
}
#endif 
