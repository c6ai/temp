

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fscanf_84.h"

namespace fscanf_84
{
fscanf_84_goodG2B::fscanf_84_goodG2B(float dataCopy)
{
    data = dataCopy;
    
    data = 2.0F;
}

fscanf_84_goodG2B::~fscanf_84_goodG2B()
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}
}
#endif 
