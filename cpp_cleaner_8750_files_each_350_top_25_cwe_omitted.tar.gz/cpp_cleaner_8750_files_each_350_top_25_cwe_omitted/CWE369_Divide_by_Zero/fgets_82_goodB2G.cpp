

#ifndef OMITGOOD

#include "std_testcase.h"
#include "fgets_82.h"

namespace fgets_82
{

void fgets_82_goodB2G::action(float data)
{
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

}
#endif 
