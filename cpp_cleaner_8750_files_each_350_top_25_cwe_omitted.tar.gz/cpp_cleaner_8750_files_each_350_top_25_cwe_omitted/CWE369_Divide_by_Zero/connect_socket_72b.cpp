


#include "std_testcase.h"
#include <vector>

#include <math.h>

using namespace std;

namespace connect_socket_72
{

#ifndef OMITBAD

void badSink(vector<float> dataVector)
{
    
    float data = dataVector[2];
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<float> dataVector)
{
    float data = dataVector[2];
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}


void goodB2GSink(vector<float> dataVector)
{
    float data = dataVector[2];
    
    if(fabs(data) > 0.000001)
    {
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
    else
    {
        printLine("This would result in a divide by zero");
    }
}

#endif 

} 
