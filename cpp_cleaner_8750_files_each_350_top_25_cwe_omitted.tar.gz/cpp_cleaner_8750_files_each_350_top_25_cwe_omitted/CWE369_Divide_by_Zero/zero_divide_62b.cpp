


#include "std_testcase.h"

namespace zero_divide_62
{

#ifndef OMITBAD

void badSource(int &data)
{
    
    data = 0;
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(int &data)
{
    
    data = 7;
}


void goodB2GSource(int &data)
{
    
    data = 0;
}

#endif 

} 
