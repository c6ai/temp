


#include "std_testcase.h"
#include "fscanf_83.h"

namespace fscanf_83
{

#ifndef OMITBAD

void bad()
{
    float data;
    
    data = 0.0F;
    fscanf_83_bad badObject(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    float data;
    
    data = 0.0F;
    fscanf_83_goodG2B goodG2BObject(data);
}


static void goodB2G()
{
    float data;
    
    data = 0.0F;
    fscanf_83_goodB2G goodB2GObject(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace fscanf_83; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
