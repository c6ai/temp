

#ifndef OMITBAD

#include "std_testcase.h"
#include "listenSocket_81.h"

namespace listenSocket_81
{

void listenSocket_81_bad::action(float data) const
{
    {
        
        int result = (int)(100.0 / data);
        printIntLine(result);
    }
}

}
#endif 
