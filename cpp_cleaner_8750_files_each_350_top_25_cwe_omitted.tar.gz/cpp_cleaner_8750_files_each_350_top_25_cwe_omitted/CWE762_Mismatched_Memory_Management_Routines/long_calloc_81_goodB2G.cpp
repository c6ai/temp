

#ifndef OMITGOOD

#include "std_testcase.h"
#include "long_calloc_81.h"

namespace long_calloc_81
{

void long_calloc_81_goodB2G::action(long * data) const
{
    
    free(data);
}

}
#endif 
