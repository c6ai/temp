


#include "std_testcase.h"

namespace array_delete_int64_t_52
{

#ifndef OMITBAD

void badSink_c(int64_t * data)
{
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(int64_t * data)
{
    
    delete data;
}


void goodB2GSink_c(int64_t * data)
{
    
    delete [] data;
}

#endif 

} 
