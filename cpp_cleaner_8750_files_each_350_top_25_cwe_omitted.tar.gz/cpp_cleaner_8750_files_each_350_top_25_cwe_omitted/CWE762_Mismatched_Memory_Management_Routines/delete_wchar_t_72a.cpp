


#include "std_testcase.h"
#include <vector>

#include <wchar.h>

using namespace std;

namespace delete_wchar_t_72
{

#ifndef OMITBAD


void badSink(vector<wchar_t *> dataVector);

void bad()
{
    wchar_t * data;
    vector<wchar_t *> dataVector;
    
    data = NULL;
    {
        wchar_t myString[] = L"myString";
        
        data = wcsdup(myString);
    }
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    badSink(dataVector);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<wchar_t *> dataVector);

static void goodG2B()
{
    wchar_t * data;
    vector<wchar_t *> dataVector;
    
    data = NULL;
    
    data = new wchar_t;
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodG2BSink(dataVector);
}


void goodB2GSink(vector<wchar_t *> dataVector);

static void goodB2G()
{
    wchar_t * data;
    vector<wchar_t *> dataVector;
    
    data = NULL;
    {
        wchar_t myString[] = L"myString";
        
        data = wcsdup(myString);
    }
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodB2GSink(dataVector);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_wchar_t_72; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
