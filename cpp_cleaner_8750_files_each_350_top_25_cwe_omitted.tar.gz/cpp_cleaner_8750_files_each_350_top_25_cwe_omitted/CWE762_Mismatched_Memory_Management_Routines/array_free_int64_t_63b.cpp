


#include "std_testcase.h"

namespace array_free_int64_t_63
{

#ifndef OMITBAD

void badSink(int64_t * * dataPtr)
{
    int64_t * data = *dataPtr;
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int64_t * * dataPtr)
{
    int64_t * data = *dataPtr;
    
    free(data);
}


void goodB2GSink(int64_t * * dataPtr)
{
    int64_t * data = *dataPtr;
    
    delete [] data;
}

#endif 

} 
