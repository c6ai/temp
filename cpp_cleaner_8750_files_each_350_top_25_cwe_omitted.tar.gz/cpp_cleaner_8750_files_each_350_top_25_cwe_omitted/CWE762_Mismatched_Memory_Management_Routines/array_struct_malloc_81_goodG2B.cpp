

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_struct_malloc_81.h"

namespace array_struct_malloc_81
{

void array_struct_malloc_81_goodG2B::action(twoIntsStruct * data) const
{
    
    delete [] data;
}

}
#endif 
