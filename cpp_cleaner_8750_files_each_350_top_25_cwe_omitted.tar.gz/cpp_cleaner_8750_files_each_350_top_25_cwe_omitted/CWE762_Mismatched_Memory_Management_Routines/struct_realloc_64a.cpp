


#include "std_testcase.h"

namespace struct_realloc_64
{

#ifndef OMITBAD


void badSink(void * dataVoidPtr);

void bad()
{
    twoIntsStruct * data;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr);

static void goodG2B()
{
    twoIntsStruct * data;
    
    data = NULL;
    
    data = new twoIntsStruct;
    goodG2BSink(&data);
}


void goodB2GSink(void * dataVoidPtr);

static void goodB2G()
{
    twoIntsStruct * data;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_realloc_64; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
