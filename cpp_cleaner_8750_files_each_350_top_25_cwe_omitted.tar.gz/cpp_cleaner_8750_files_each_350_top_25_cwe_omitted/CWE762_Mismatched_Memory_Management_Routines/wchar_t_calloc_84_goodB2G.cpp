

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_calloc_84.h"

namespace wchar_t_calloc_84
{
wchar_t_calloc_84_goodB2G::wchar_t_calloc_84_goodB2G(wchar_t * dataCopy)
{
    data = dataCopy;
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
}

wchar_t_calloc_84_goodB2G::~wchar_t_calloc_84_goodB2G()
{
    
    free(data);
}
}
#endif 
