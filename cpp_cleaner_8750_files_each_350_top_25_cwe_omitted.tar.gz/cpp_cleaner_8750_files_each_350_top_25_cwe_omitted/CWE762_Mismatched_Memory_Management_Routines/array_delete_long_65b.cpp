


#include "std_testcase.h"

namespace array_delete_long_65
{

#ifndef OMITBAD

void badSink(long * data)
{
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(long * data)
{
    
    delete data;
}


void goodB2GSink(long * data)
{
    
    delete [] data;
}

#endif 

} 
