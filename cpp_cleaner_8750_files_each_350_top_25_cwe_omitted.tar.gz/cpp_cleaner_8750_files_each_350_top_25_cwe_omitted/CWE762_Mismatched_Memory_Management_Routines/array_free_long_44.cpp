


#include "std_testcase.h"

namespace array_free_long_44
{

#ifndef OMITBAD

static void badSink(long * data)
{
    
    free(data);
}

void bad()
{
    long * data;
    
    void (*funcPtr) (long *) = badSink;
    
    data = NULL;
    
    data = new long[100];
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(long * data)
{
    
    free(data);
}

static void goodG2B()
{
    long * data;
    void (*funcPtr) (long *) = goodG2BSink;
    
    data = NULL;
    
    data = (long *)malloc(100*sizeof(long));
    if (data == NULL) {exit(-1);}
    funcPtr(data);
}


static void goodB2GSink(long * data)
{
    
    delete [] data;
}

static void goodB2G()
{
    long * data;
    void (*funcPtr) (long *) = goodB2GSink;
    
    data = NULL;
    
    data = new long[100];
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_long_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
