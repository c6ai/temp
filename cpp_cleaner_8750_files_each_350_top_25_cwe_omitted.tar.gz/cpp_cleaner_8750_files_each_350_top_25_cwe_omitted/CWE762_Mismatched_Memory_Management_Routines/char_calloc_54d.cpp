


#include "std_testcase.h"

namespace char_calloc_54
{

#ifndef OMITBAD


void badSink_e(char * data);

void badSink_d(char * data)
{
    badSink_e(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(char * data);

void goodG2BSink_d(char * data)
{
    goodG2BSink_e(data);
}


void goodB2GSink_e(char * data);

void goodB2GSink_d(char * data)
{
    goodB2GSink_e(data);
}

#endif 

} 
