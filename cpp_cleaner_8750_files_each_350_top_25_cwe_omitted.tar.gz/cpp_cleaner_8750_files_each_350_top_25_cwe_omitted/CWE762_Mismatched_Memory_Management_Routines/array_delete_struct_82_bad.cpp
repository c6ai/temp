

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_delete_struct_82.h"

namespace array_delete_struct_82
{

void array_delete_struct_82_bad::action(twoIntsStruct * data)
{
    
    delete data;
}

}
#endif 
