


#include "std_testcase.h"


static int staticFive = 5;

namespace delete_array_int_07
{

#ifndef OMITBAD

void bad()
{
    int * data;
    
    data = NULL;
    if(staticFive==5)
    {
        
        data = new int;
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    int * data;
    
    data = NULL;
    if(staticFive==5)
    {
        
        data = new int;
    }
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


static void goodB2G2()
{
    int * data;
    
    data = NULL;
    if(staticFive==5)
    {
        
        data = new int;
    }
    if(staticFive==5)
    {
        
        delete data;
    }
}


static void goodG2B1()
{
    int * data;
    
    data = NULL;
    if(staticFive!=5)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        data = new int[100];
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}


static void goodG2B2()
{
    int * data;
    
    data = NULL;
    if(staticFive==5)
    {
        
        data = new int[100];
    }
    if(staticFive==5)
    {
        
        delete [] data;
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_array_int_07; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
