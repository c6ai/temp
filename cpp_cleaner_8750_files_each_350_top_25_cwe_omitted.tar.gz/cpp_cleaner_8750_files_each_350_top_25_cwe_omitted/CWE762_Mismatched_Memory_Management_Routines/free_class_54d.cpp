


#include "std_testcase.h"

namespace free_class_54
{

#ifndef OMITBAD


void badSink_e(TwoIntsClass * data);

void badSink_d(TwoIntsClass * data)
{
    badSink_e(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(TwoIntsClass * data);

void goodG2BSink_d(TwoIntsClass * data)
{
    goodG2BSink_e(data);
}


void goodB2GSink_e(TwoIntsClass * data);

void goodB2GSink_d(TwoIntsClass * data)
{
    goodB2GSink_e(data);
}

#endif 

} 
