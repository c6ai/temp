


#include "std_testcase.h"

namespace struct_malloc_45
{

static twoIntsStruct * badData;
static twoIntsStruct * goodG2BData;
static twoIntsStruct * goodB2GData;

#ifndef OMITBAD

static void badSink()
{
    twoIntsStruct * data = badData;
    
    delete data;
}

void bad()
{
    twoIntsStruct * data;
    
    data = NULL;
    
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
    if (data == NULL) {exit(-1);}
    badData = data;
    badSink();
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink()
{
    twoIntsStruct * data = goodG2BData;
    
    delete data;
}

static void goodG2B()
{
    twoIntsStruct * data;
    
    data = NULL;
    
    data = new twoIntsStruct;
    goodG2BData = data;
    goodG2BSink();
}


static void goodB2GSink()
{
    twoIntsStruct * data = goodB2GData;
    
    free(data);
}

static void goodB2G()
{
    twoIntsStruct * data;
    
    data = NULL;
    
    data = (twoIntsStruct *)malloc(100*sizeof(twoIntsStruct));
    if (data == NULL) {exit(-1);}
    goodB2GData = data;
    goodB2GSink();
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_malloc_45; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
