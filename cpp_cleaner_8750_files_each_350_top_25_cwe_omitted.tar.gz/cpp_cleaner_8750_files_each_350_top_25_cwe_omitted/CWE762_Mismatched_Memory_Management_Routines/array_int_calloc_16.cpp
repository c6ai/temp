


#include "std_testcase.h"

namespace array_int_calloc_16
{

#ifndef OMITBAD

void bad()
{
    int * data;
    
    data = NULL;
    while(1)
    {
        
        data = (int *)calloc(100, sizeof(int));
        if (data == NULL) {exit(-1);}
        break;
    }
    while(1)
    {
        
        delete [] data;
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    int * data;
    
    data = NULL;
    while(1)
    {
        
        data = (int *)calloc(100, sizeof(int));
        if (data == NULL) {exit(-1);}
        break;
    }
    while(1)
    {
        
        free(data);
        break;
    }
}


static void goodG2B()
{
    int * data;
    
    data = NULL;
    while(1)
    {
        
        data = new int[100];
        break;
    }
    while(1)
    {
        
        delete [] data;
        break;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_calloc_16; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
