


#include "std_testcase.h"

namespace delete_array_int_53
{

#ifndef OMITBAD


void badSink_c(int * data);

void badSink_b(int * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(int * data);

void goodG2BSink_b(int * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(int * data);

void goodB2GSink_b(int * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
