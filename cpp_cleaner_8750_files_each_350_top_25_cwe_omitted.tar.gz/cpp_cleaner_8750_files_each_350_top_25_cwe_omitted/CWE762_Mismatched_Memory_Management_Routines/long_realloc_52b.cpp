


#include "std_testcase.h"

namespace long_realloc_52
{

#ifndef OMITBAD


void badSink_c(long * data);

void badSink_b(long * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(long * data);

void goodG2BSink_b(long * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(long * data);

void goodB2GSink_b(long * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
