


#include "std_testcase.h"
#include <list>

using namespace std;

namespace delete_array_long_73
{

#ifndef OMITBAD

void badSink(list<long *> dataList)
{
    
    long * data = dataList.back();
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<long *> dataList)
{
    long * data = dataList.back();
    
    delete [] data;
}


void goodB2GSink(list<long *> dataList)
{
    long * data = dataList.back();
    
    delete data;
}

#endif 

} 
