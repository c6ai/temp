


#include "std_testcase.h"

namespace int_calloc_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(int * data)
{
    if(badGlobal)
    {
        
        delete data;
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(int * data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        free(data);
    }
}


void goodB2G2Sink(int * data)
{
    if(goodB2G2Global)
    {
        
        free(data);
    }
}


void goodG2B1Sink(int * data)
{
    if(goodG2B1Global)
    {
        
        delete data;
    }
}

#endif 

} 
