


#include "std_testcase.h"

namespace array_delete_long_61
{

#ifndef OMITBAD

long * badSource(long * data)
{
    
    data = new long[100];
    return data;
}

#endif 

#ifndef OMITGOOD


long * goodG2BSource(long * data)
{
    
    data = new long;
    return data;
}


long * goodB2GSource(long * data)
{
    
    data = new long[100];
    return data;
}

#endif 

} 
