


#include "std_testcase.h"

#include <wchar.h>

namespace delete_array_char_53
{

#ifndef OMITBAD


void badSink_c(char * data);

void badSink_b(char * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(char * data);

void goodG2BSink_b(char * data)
{
    goodG2BSink_c(data);
}


void goodB2GSink_c(char * data);

void goodB2GSink_b(char * data)
{
    goodB2GSink_c(data);
}

#endif 

} 
