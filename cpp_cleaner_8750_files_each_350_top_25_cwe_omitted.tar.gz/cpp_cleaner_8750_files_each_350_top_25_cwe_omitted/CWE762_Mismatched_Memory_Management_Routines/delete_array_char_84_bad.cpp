

#ifndef OMITBAD

#include "std_testcase.h"
#include "delete_array_char_84.h"

namespace delete_array_char_84
{
delete_array_char_84_bad::delete_array_char_84_bad(char * dataCopy)
{
    data = dataCopy;
    {
        char myString[] = "myString";
        
        data = strdup(myString);
    }
}

delete_array_char_84_bad::~delete_array_char_84_bad()
{
    
    delete [] data;
}
}
#endif 
