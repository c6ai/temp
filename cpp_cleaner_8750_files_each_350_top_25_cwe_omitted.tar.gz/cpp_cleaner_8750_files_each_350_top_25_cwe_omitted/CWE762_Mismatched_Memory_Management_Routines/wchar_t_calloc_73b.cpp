


#include "std_testcase.h"
#include <list>

using namespace std;

namespace wchar_t_calloc_73
{

#ifndef OMITBAD

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    
    delete data;
}


void goodB2GSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    
    free(data);
}

#endif 

} 
