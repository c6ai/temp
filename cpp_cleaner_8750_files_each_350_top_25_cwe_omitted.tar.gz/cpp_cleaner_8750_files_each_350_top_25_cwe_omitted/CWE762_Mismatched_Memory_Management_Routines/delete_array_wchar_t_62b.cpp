


#include "std_testcase.h"

#include <wchar.h>

namespace delete_array_wchar_t_62
{

#ifndef OMITBAD

void badSource(wchar_t * &data)
{
    {
        wchar_t myString[] = L"myString";
        
        data = wcsdup(myString);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(wchar_t * &data)
{
    
    data = new wchar_t[100];
}


void goodB2GSource(wchar_t * &data)
{
    {
        wchar_t myString[] = L"myString";
        
        data = wcsdup(myString);
    }
}

#endif 

} 
