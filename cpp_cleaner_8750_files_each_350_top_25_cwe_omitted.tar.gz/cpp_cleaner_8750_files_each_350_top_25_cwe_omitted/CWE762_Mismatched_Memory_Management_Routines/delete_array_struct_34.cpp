


#include "std_testcase.h"

namespace delete_array_struct_34
{

typedef union
{
    twoIntsStruct * unionFirst;
    twoIntsStruct * unionSecond;
} unionType;

#ifndef OMITBAD

void bad()
{
    twoIntsStruct * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new twoIntsStruct;
    myUnion.unionFirst = data;
    {
        twoIntsStruct * data = myUnion.unionSecond;
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    twoIntsStruct * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new twoIntsStruct[100];
    myUnion.unionFirst = data;
    {
        twoIntsStruct * data = myUnion.unionSecond;
        
        delete [] data;
    }
}


static void goodB2G()
{
    twoIntsStruct * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new twoIntsStruct;
    myUnion.unionFirst = data;
    {
        twoIntsStruct * data = myUnion.unionSecond;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace delete_array_struct_34; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
