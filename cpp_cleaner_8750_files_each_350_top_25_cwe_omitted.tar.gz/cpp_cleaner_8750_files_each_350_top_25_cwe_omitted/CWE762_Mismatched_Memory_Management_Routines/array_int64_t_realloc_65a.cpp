


#include "std_testcase.h"

namespace array_int64_t_realloc_65
{

#ifndef OMITBAD


void badSink(int64_t * data);

void bad()
{
    int64_t * data;
    
    void (*funcPtr) (int64_t *) = badSink;
    
    data = NULL;
    data = NULL;
    
    data = (int64_t *)realloc(data, 100*sizeof(int64_t));
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int64_t * data);

static void goodG2B()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = goodG2BSink;
    
    data = NULL;
    
    data = new int64_t[100];
    funcPtr(data);
}


void goodB2GSink(int64_t * data);

static void goodB2G()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = goodB2GSink;
    
    data = NULL;
    data = NULL;
    
    data = (int64_t *)realloc(data, 100*sizeof(int64_t));
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int64_t_realloc_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
