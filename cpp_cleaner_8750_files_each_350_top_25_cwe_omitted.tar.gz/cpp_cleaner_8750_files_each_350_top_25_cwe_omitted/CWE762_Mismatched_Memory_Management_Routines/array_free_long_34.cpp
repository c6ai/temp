


#include "std_testcase.h"

namespace array_free_long_34
{

typedef union
{
    long * unionFirst;
    long * unionSecond;
} unionType;

#ifndef OMITBAD

void bad()
{
    long * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new long[100];
    myUnion.unionFirst = data;
    {
        long * data = myUnion.unionSecond;
        
        free(data);
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    long * data;
    unionType myUnion;
    
    data = NULL;
    
    data = (long *)malloc(100*sizeof(long));
    if (data == NULL) {exit(-1);}
    myUnion.unionFirst = data;
    {
        long * data = myUnion.unionSecond;
        
        free(data);
    }
}


static void goodB2G()
{
    long * data;
    unionType myUnion;
    
    data = NULL;
    
    data = new long[100];
    myUnion.unionFirst = data;
    {
        long * data = myUnion.unionSecond;
        
        delete [] data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_free_long_34; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
