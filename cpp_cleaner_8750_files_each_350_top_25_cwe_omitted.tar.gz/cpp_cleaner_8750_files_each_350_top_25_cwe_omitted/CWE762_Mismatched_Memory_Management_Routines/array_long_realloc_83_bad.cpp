

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_long_realloc_83.h"

namespace array_long_realloc_83
{
array_long_realloc_83_bad::array_long_realloc_83_bad(long * dataCopy)
{
    data = dataCopy;
    data = NULL;
    
    data = (long *)realloc(data, 100*sizeof(long));
}

array_long_realloc_83_bad::~array_long_realloc_83_bad()
{
    
    delete [] data;
}
}
#endif 
