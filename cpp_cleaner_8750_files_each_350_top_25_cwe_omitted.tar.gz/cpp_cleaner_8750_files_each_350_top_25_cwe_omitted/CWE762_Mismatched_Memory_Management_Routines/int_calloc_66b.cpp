


#include "std_testcase.h"

namespace int_calloc_66
{

#ifndef OMITBAD

void badSink(int * dataArray[])
{
    
    int * data = dataArray[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * dataArray[])
{
    int * data = dataArray[2];
    
    delete data;
}


void goodB2GSink(int * dataArray[])
{
    int * data = dataArray[2];
    
    free(data);
}

#endif 

} 
