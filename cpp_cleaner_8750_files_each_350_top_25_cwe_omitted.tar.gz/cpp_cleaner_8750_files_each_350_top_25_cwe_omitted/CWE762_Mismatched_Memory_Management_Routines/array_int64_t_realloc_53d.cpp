


#include "std_testcase.h"

namespace array_int64_t_realloc_53
{

#ifndef OMITBAD

void badSink_d(int64_t * data)
{
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(int64_t * data)
{
    
    delete [] data;
}


void goodB2GSink_d(int64_t * data)
{
    
    free(data);
}

#endif 

} 
