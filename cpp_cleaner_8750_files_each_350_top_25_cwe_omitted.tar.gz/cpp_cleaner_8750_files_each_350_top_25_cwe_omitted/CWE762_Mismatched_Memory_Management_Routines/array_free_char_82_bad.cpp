

#ifndef OMITBAD

#include "std_testcase.h"
#include "array_free_char_82.h"

namespace array_free_char_82
{

void array_free_char_82_bad::action(char * data)
{
    
    free(data);
}

}
#endif 
