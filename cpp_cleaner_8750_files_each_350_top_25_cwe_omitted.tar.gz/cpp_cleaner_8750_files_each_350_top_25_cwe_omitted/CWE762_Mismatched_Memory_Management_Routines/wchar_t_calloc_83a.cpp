


#include "std_testcase.h"
#include "wchar_t_calloc_83.h"

namespace wchar_t_calloc_83
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    
    data = NULL;
    wchar_t_calloc_83_bad badObject(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    wchar_t * data;
    
    data = NULL;
    wchar_t_calloc_83_goodG2B goodG2BObject(data);
}


static void goodB2G()
{
    wchar_t * data;
    
    data = NULL;
    wchar_t_calloc_83_goodB2G goodB2GObject(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_calloc_83; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
