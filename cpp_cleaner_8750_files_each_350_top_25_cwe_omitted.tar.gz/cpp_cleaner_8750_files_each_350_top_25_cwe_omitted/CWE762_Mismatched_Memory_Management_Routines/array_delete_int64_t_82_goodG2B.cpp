

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_delete_int64_t_82.h"

namespace array_delete_int64_t_82
{

void array_delete_int64_t_82_goodG2B::action(int64_t * data)
{
    
    delete data;
}

}
#endif 
