


#include "std_testcase.h"

namespace free_int_54
{

#ifndef OMITBAD

void badSink_e(int * data)
{
    
    free(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(int * data)
{
    
    free(data);
}


void goodB2GSink_e(int * data)
{
    
    delete data;
}

#endif 

} 
