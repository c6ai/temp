


#include "std_testcase.h"
#include <map>

using namespace std;

namespace array_wchar_t_calloc_74
{

#ifndef OMITBAD


void badSink(map<int, wchar_t *> dataMap);

void bad()
{
    wchar_t * data;
    map<int, wchar_t *> dataMap;
    
    data = NULL;
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    badSink(dataMap);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, wchar_t *> dataMap);

static void goodG2B()
{
    wchar_t * data;
    map<int, wchar_t *> dataMap;
    
    data = NULL;
    
    data = new wchar_t[100];
    
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodG2BSink(dataMap);
}


void goodB2GSink(map<int, wchar_t *> dataMap);

static void goodB2G()
{
    wchar_t * data;
    map<int, wchar_t *> dataMap;
    
    data = NULL;
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    dataMap[0] = data;
    dataMap[1] = data;
    dataMap[2] = data;
    goodB2GSink(dataMap);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_wchar_t_calloc_74; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
