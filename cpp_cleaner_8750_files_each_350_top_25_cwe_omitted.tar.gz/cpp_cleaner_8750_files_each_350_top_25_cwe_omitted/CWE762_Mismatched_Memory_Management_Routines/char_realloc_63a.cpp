


#include "std_testcase.h"

namespace char_realloc_63
{

#ifndef OMITBAD


void badSink(char * * dataPtr);

void bad()
{
    char * data;
    
    data = NULL;
    data = NULL;
    
    data = (char *)realloc(data, 100*sizeof(char));
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * * data);

static void goodG2B()
{
    char * data;
    
    data = NULL;
    
    data = new char;
    goodG2BSink(&data);
}


void goodB2GSink(char * * data);

static void goodB2G()
{
    char * data;
    
    data = NULL;
    data = NULL;
    
    data = (char *)realloc(data, 100*sizeof(char));
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_realloc_63; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
