


#include "std_testcase.h"

namespace array_char_malloc_66
{

#ifndef OMITBAD

void badSink(char * dataArray[])
{
    
    char * data = dataArray[2];
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * dataArray[])
{
    char * data = dataArray[2];
    
    delete [] data;
}


void goodB2GSink(char * dataArray[])
{
    char * data = dataArray[2];
    
    free(data);
}

#endif 

} 
