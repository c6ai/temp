


#include "std_testcase.h"

namespace array_delete_class_67
{

typedef struct _structType
{
    TwoIntsClass * structFirst;
} structType;

#ifndef OMITBAD

void badSink(structType myStruct)
{
    TwoIntsClass * data = myStruct.structFirst;
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct)
{
    TwoIntsClass * data = myStruct.structFirst;
    
    delete data;
}


void goodB2GSink(structType myStruct)
{
    TwoIntsClass * data = myStruct.structFirst;
    
    delete [] data;
}

#endif 

} 
