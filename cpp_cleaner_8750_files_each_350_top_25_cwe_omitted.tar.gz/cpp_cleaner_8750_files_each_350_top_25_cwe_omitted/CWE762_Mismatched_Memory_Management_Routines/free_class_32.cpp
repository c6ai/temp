


#include "std_testcase.h"

namespace free_class_32
{

#ifndef OMITBAD

void bad()
{
    TwoIntsClass * data;
    TwoIntsClass * *dataPtr1 = &data;
    TwoIntsClass * *dataPtr2 = &data;
    
    data = NULL;
    {
        TwoIntsClass * data = *dataPtr1;
        
        data = new TwoIntsClass;
        *dataPtr1 = data;
    }
    {
        TwoIntsClass * data = *dataPtr2;
        
        free(data);
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    TwoIntsClass * data;
    TwoIntsClass * *dataPtr1 = &data;
    TwoIntsClass * *dataPtr2 = &data;
    
    data = NULL;
    {
        TwoIntsClass * data = *dataPtr1;
        
        data = (TwoIntsClass *)malloc(100*sizeof(TwoIntsClass));
        if (data == NULL) {exit(-1);}
        *dataPtr1 = data;
    }
    {
        TwoIntsClass * data = *dataPtr2;
        
        free(data);
    }
}


static void goodB2G()
{
    TwoIntsClass * data;
    TwoIntsClass * *dataPtr1 = &data;
    TwoIntsClass * *dataPtr2 = &data;
    
    data = NULL;
    {
        TwoIntsClass * data = *dataPtr1;
        
        data = new TwoIntsClass;
        *dataPtr1 = data;
    }
    {
        TwoIntsClass * data = *dataPtr2;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace free_class_32; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
