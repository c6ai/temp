


#include "std_testcase.h"
#include <vector>

using namespace std;

namespace long_malloc_72
{

#ifndef OMITBAD

void badSink(vector<long *> dataVector)
{
    
    long * data = dataVector[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<long *> dataVector)
{
    long * data = dataVector[2];
    
    delete data;
}


void goodB2GSink(vector<long *> dataVector)
{
    long * data = dataVector[2];
    
    free(data);
}

#endif 

} 
