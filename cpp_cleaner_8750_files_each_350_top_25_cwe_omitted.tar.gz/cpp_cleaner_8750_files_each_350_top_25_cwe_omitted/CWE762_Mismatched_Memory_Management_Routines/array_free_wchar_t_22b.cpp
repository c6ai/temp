


#include "std_testcase.h"

namespace array_free_wchar_t_22
{

#ifndef OMITBAD


extern int badGlobal;

void badSink(wchar_t * data)
{
    if(badGlobal)
    {
        
        free(data);
    }
}

#endif 

#ifndef OMITGOOD


extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(wchar_t * data)
{
    if(goodB2G1Global)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete [] data;
    }
}


void goodB2G2Sink(wchar_t * data)
{
    if(goodB2G2Global)
    {
        
        delete [] data;
    }
}


void goodG2B1Sink(wchar_t * data)
{
    if(goodG2B1Global)
    {
        
        free(data);
    }
}

#endif 

} 
