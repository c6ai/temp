


#include "std_testcase.h"

namespace array_char_realloc_54
{

#ifndef OMITBAD


void badSink_b(char * data);

void bad()
{
    char * data;
    
    data = NULL;
    data = NULL;
    
    data = (char *)realloc(data, 100*sizeof(char));
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(char * data);

static void goodG2B()
{
    char * data;
    
    data = NULL;
    
    data = new char[100];
    goodG2BSink_b(data);
}


void goodB2GSink_b(char * data);

static void goodB2G()
{
    char * data;
    
    data = NULL;
    data = NULL;
    
    data = (char *)realloc(data, 100*sizeof(char));
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_char_realloc_54; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
