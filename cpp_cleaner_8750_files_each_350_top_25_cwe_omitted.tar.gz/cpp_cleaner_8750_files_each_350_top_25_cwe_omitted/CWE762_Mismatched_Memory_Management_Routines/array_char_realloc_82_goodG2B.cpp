

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_char_realloc_82.h"

namespace array_char_realloc_82
{

void array_char_realloc_82_goodG2B::action(char * data)
{
    
    delete [] data;
}

}
#endif 
