


#include "std_testcase.h"

namespace array_free_int64_t_64
{

#ifndef OMITBAD


void badSink(void * dataVoidPtr);

void bad()
{
    int64_t * data;
    
    data = NULL;
    
    data = new int64_t[100];
    badSink(&data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr);

static void goodG2B()
{
    int64_t * data;
    
    data = NULL;
    
    data = (int64_t *)malloc(100*sizeof(int64_t));
    goodG2BSink(&data);
}


void goodB2GSink(void * dataVoidPtr);

static void goodB2G()
{
    int64_t * data;
    
    data = NULL;
    
    data = new int64_t[100];
    goodB2GSink(&data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_int64_t_64; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
