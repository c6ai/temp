


#include "std_testcase.h"

#include <wchar.h>

namespace delete_wchar_t_66
{

#ifndef OMITBAD

void badSink(wchar_t * dataArray[])
{
    
    wchar_t * data = dataArray[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * dataArray[])
{
    wchar_t * data = dataArray[2];
    
    delete data;
}


void goodB2GSink(wchar_t * dataArray[])
{
    wchar_t * data = dataArray[2];
    
    free(data);
}

#endif 

} 
