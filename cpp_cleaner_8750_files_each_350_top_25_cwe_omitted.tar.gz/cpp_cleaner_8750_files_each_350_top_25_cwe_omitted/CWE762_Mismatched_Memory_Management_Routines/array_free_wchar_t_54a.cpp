


#include "std_testcase.h"

namespace array_free_wchar_t_54
{

#ifndef OMITBAD


void badSink_b(wchar_t * data);

void bad()
{
    wchar_t * data;
    
    data = NULL;
    
    data = new wchar_t[100];
    badSink_b(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_b(wchar_t * data);

static void goodG2B()
{
    wchar_t * data;
    
    data = NULL;
    
    data = (wchar_t *)malloc(100*sizeof(wchar_t));
    goodG2BSink_b(data);
}


void goodB2GSink_b(wchar_t * data);

static void goodB2G()
{
    wchar_t * data;
    
    data = NULL;
    
    data = new wchar_t[100];
    goodB2GSink_b(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_free_wchar_t_54; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
