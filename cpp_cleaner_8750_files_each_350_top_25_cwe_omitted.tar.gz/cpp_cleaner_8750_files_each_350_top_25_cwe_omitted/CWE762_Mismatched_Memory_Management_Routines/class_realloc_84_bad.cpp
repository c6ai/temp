

#ifndef OMITBAD

#include "std_testcase.h"
#include "class_realloc_84.h"

namespace class_realloc_84
{
class_realloc_84_bad::class_realloc_84_bad(TwoIntsClass * dataCopy)
{
    data = dataCopy;
    data = NULL;
    
    data = (TwoIntsClass *)realloc(data, 100*sizeof(TwoIntsClass));
}

class_realloc_84_bad::~class_realloc_84_bad()
{
    
    delete data;
}
}
#endif 
