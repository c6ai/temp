


#include "std_testcase.h"

namespace class_calloc_64
{

#ifndef OMITBAD

void badSink(void * dataVoidPtr)
{
    
    TwoIntsClass * * dataPtr = (TwoIntsClass * *)dataVoidPtr;
    
    TwoIntsClass * data = (*dataPtr);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(void * dataVoidPtr)
{
    
    TwoIntsClass * * dataPtr = (TwoIntsClass * *)dataVoidPtr;
    
    TwoIntsClass * data = (*dataPtr);
    
    delete data;
}


void goodB2GSink(void * dataVoidPtr)
{
    
    TwoIntsClass * * dataPtr = (TwoIntsClass * *)dataVoidPtr;
    
    TwoIntsClass * data = (*dataPtr);
    
    free(data);
}

#endif 

} 
