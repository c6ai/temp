


#include "std_testcase.h"
#include "array_int_realloc_82.h"

namespace array_int_realloc_82
{

#ifndef OMITBAD

void bad()
{
    int * data;
    
    data = NULL;
    data = NULL;
    
    data = (int *)realloc(data, 100*sizeof(int));
    if (data == NULL) {exit(-1);}
    array_int_realloc_82_base* baseObject = new array_int_realloc_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int * data;
    
    data = NULL;
    
    data = new int[100];
    array_int_realloc_82_base* baseObject = new array_int_realloc_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}


static void goodB2G()
{
    int * data;
    
    data = NULL;
    data = NULL;
    
    data = (int *)realloc(data, 100*sizeof(int));
    if (data == NULL) {exit(-1);}
    array_int_realloc_82_base* baseObject = new array_int_realloc_82_goodB2G;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int_realloc_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
