


#include "std_testcase.h"
#include <vector>

using namespace std;

namespace array_delete_long_72
{

#ifndef OMITBAD


void badSink(vector<long *> dataVector);

void bad()
{
    long * data;
    vector<long *> dataVector;
    
    data = NULL;
    
    data = new long[100];
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    badSink(dataVector);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<long *> dataVector);

static void goodG2B()
{
    long * data;
    vector<long *> dataVector;
    
    data = NULL;
    
    data = new long;
    
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodG2BSink(dataVector);
}


void goodB2GSink(vector<long *> dataVector);

static void goodB2G()
{
    long * data;
    vector<long *> dataVector;
    
    data = NULL;
    
    data = new long[100];
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    dataVector.insert(dataVector.end(), 1, data);
    goodB2GSink(dataVector);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_delete_long_72; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
