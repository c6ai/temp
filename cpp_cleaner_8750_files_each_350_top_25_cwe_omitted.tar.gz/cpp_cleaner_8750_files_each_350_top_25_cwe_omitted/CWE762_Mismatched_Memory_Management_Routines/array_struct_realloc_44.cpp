


#include "std_testcase.h"

namespace array_struct_realloc_44
{

#ifndef OMITBAD

static void badSink(twoIntsStruct * data)
{
    
    delete [] data;
}

void bad()
{
    twoIntsStruct * data;
    
    void (*funcPtr) (twoIntsStruct *) = badSink;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    if (data == NULL) {exit(-1);}
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(twoIntsStruct * data)
{
    
    delete [] data;
}

static void goodG2B()
{
    twoIntsStruct * data;
    void (*funcPtr) (twoIntsStruct *) = goodG2BSink;
    
    data = NULL;
    
    data = new twoIntsStruct[100];
    funcPtr(data);
}


static void goodB2GSink(twoIntsStruct * data)
{
    
    free(data);
}

static void goodB2G()
{
    twoIntsStruct * data;
    void (*funcPtr) (twoIntsStruct *) = goodB2GSink;
    
    data = NULL;
    data = NULL;
    
    data = (twoIntsStruct *)realloc(data, 100*sizeof(twoIntsStruct));
    if (data == NULL) {exit(-1);}
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_struct_realloc_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
