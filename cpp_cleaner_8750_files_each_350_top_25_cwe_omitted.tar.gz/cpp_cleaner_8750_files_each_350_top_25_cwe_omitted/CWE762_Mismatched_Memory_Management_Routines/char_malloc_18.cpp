


#include "std_testcase.h"

namespace char_malloc_18
{

#ifndef OMITBAD

void bad()
{
    char * data;
    
    data = NULL;
    goto source;
source:
    
    data = (char *)malloc(100*sizeof(char));
    if (data == NULL) {exit(-1);}
    goto sink;
sink:
    
    delete data;
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    char * data;
    
    data = NULL;
    goto source;
source:
    
    data = (char *)malloc(100*sizeof(char));
    if (data == NULL) {exit(-1);}
    goto sink;
sink:
    
    free(data);
}


static void goodG2B()
{
    char * data;
    
    data = NULL;
    goto source;
source:
    
    data = new char;
    goto sink;
sink:
    
    delete data;
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_malloc_18; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
