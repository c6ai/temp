


#include "std_testcase.h"

namespace int64_t_calloc_51
{

#ifndef OMITBAD

void badSink(int64_t * data)
{
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int64_t * data)
{
    
    delete data;
}


void goodB2GSink(int64_t * data)
{
    
    free(data);
}

#endif 

} 
