


#include "std_testcase.h"
#include <map>

using namespace std;

namespace array_struct_malloc_74
{

#ifndef OMITBAD

void badSink(map<int, twoIntsStruct *> dataMap)
{
    
    twoIntsStruct * data = dataMap[2];
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, twoIntsStruct *> dataMap)
{
    twoIntsStruct * data = dataMap[2];
    
    delete [] data;
}


void goodB2GSink(map<int, twoIntsStruct *> dataMap)
{
    twoIntsStruct * data = dataMap[2];
    
    free(data);
}

#endif 

} 
