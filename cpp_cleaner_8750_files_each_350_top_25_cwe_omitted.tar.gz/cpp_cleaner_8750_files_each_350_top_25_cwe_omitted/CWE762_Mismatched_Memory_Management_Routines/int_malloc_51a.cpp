


#include "std_testcase.h"

namespace int_malloc_51
{

#ifndef OMITBAD


void badSink(int * data);

void bad()
{
    int * data;
    
    data = NULL;
    
    data = (int *)malloc(100*sizeof(int));
    badSink(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * data);
void goodB2GSink(int * data);


static void goodG2B()
{
    int * data;
    
    data = NULL;
    
    data = new int;
    goodG2BSink(data);
}


static void goodB2G()
{
    int * data;
    
    data = NULL;
    
    data = (int *)malloc(100*sizeof(int));
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int_malloc_51; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
