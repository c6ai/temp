


#include "std_testcase.h"
#include <vector>

using namespace std;

namespace wchar_t_realloc_72
{

#ifndef OMITBAD

void badSink(vector<wchar_t *> dataVector)
{
    
    wchar_t * data = dataVector[2];
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<wchar_t *> dataVector)
{
    wchar_t * data = dataVector[2];
    
    delete data;
}


void goodB2GSink(vector<wchar_t *> dataVector)
{
    wchar_t * data = dataVector[2];
    
    free(data);
}

#endif 

} 
