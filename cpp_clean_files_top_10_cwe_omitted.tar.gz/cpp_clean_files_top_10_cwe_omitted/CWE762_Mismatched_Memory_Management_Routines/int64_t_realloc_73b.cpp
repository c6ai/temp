


#include "std_testcase.h"
#include <list>

using namespace std;

namespace int64_t_realloc_73
{

#ifndef OMITBAD

void badSink(list<int64_t *> dataList)
{
    
    int64_t * data = dataList.back();
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<int64_t *> dataList)
{
    int64_t * data = dataList.back();
    
    delete data;
}


void goodB2GSink(list<int64_t *> dataList)
{
    int64_t * data = dataList.back();
    
    free(data);
}

#endif 

} 
