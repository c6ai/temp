


#include "std_testcase.h"

namespace wchar_t_calloc_65
{

#ifndef OMITBAD


void badSink(wchar_t * data);

void bad()
{
    wchar_t * data;
    
    void (*funcPtr) (wchar_t *) = badSink;
    
    data = NULL;
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * data);

static void goodG2B()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodG2BSink;
    
    data = NULL;
    
    data = new wchar_t;
    funcPtr(data);
}


void goodB2GSink(wchar_t * data);

static void goodB2G()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodB2GSink;
    
    data = NULL;
    
    data = (wchar_t *)calloc(100, sizeof(wchar_t));
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_calloc_65; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
