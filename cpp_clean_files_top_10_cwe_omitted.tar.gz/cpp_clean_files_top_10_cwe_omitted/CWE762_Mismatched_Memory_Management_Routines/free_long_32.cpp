


#include "std_testcase.h"

namespace free_long_32
{

#ifndef OMITBAD

void bad()
{
    long * data;
    long * *dataPtr1 = &data;
    long * *dataPtr2 = &data;
    
    data = NULL;
    {
        long * data = *dataPtr1;
        
        data = new long;
        *dataPtr1 = data;
    }
    {
        long * data = *dataPtr2;
        
        free(data);
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    long * data;
    long * *dataPtr1 = &data;
    long * *dataPtr2 = &data;
    
    data = NULL;
    {
        long * data = *dataPtr1;
        
        data = (long *)malloc(100*sizeof(long));
        if (data == NULL) {exit(-1);}
        *dataPtr1 = data;
    }
    {
        long * data = *dataPtr2;
        
        free(data);
    }
}


static void goodB2G()
{
    long * data;
    long * *dataPtr1 = &data;
    long * *dataPtr2 = &data;
    
    data = NULL;
    {
        long * data = *dataPtr1;
        
        data = new long;
        *dataPtr1 = data;
    }
    {
        long * data = *dataPtr2;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace free_long_32; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
