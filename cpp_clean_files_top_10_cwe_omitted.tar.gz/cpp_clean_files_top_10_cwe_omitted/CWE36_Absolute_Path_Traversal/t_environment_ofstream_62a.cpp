


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define ENV_VARIABLE L"ADD"

#ifdef _WIN32
#define GETENV _wgetenv
#else
#define GETENV getenv
#endif

#include <fstream>
using namespace std;

namespace t_environment_ofstream_62
{

#ifndef OMITBAD


void badSource(wchar_t * &data);

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[FILENAME_MAX] = L"";
    data = dataBuffer;
    badSource(data);
    {
        ofstream outputFile;
        
        outputFile.open((char *)data);
        outputFile.close();
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(wchar_t * &data);

static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[FILENAME_MAX] = L"";
    data = dataBuffer;
    goodG2BSource(data);
    {
        ofstream outputFile;
        
        outputFile.open((char *)data);
        outputFile.close();
    }
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace t_environment_ofstream_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
