


#include "std_testcase.h"
#include <vector>

#ifndef _WIN32
#include <wchar.h>
#endif

#ifdef _WIN32
#define FOPEN fopen
#else
#define FOPEN fopen
#endif

using namespace std;

namespace file_fopen_72
{

#ifndef OMITBAD

void badSink(vector<char *> dataVector)
{
    
    char * data = dataVector[2];
    {
        FILE *pFile = NULL;
        
        pFile = FOPEN(data, "wb+");
        if (pFile != NULL)
        {
            fclose(pFile);
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<char *> dataVector)
{
    char * data = dataVector[2];
    {
        FILE *pFile = NULL;
        
        pFile = FOPEN(data, "wb+");
        if (pFile != NULL)
        {
            fclose(pFile);
        }
    }
}

#endif 

} 
