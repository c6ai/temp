


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

#define ENV_VARIABLE L"ADD"

#ifdef _WIN32
#define GETENV _wgetenv
#else
#define GETENV getenv
#endif

#include <fstream>
using namespace std;

namespace t_environment_ofstream_62
{

#ifndef OMITBAD

void badSource(wchar_t * &data)
{
    {
        
        size_t dataLen = wcslen(data);
        wchar_t * environment = GETENV(ENV_VARIABLE);
        
        if (environment != NULL)
        {
            
            wcsncat(data+dataLen, environment, FILENAME_MAX-dataLen-1);
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(wchar_t * &data)
{
#ifdef _WIN32
    
    wcscat(data, L"c:\\temp\\file.txt");
#else
    
    wcscat(data, L"/tmp/file.txt");
#endif
}

#endif 

} 
