


#include "std_testcase.h"

#include <wchar.h>

namespace int64_t_placement_new_01
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL; 
    {
        
        char buffer[sizeof(int64_t)];
        int64_t * dataBuffer = new(buffer) int64_t;
        *dataBuffer = 5LL;
        data = dataBuffer;
    }
    printLongLongLine(*data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int64_t * data;
    data = NULL; 
    {
        
        int64_t * dataBuffer = new int64_t;
        *dataBuffer = 5LL;
        data = dataBuffer;
    }
    printLongLongLine(*data);
    
    delete data;
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_placement_new_01; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
