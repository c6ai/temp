


#include "std_testcase.h"

#include <wchar.h>

namespace int64_t_static_12
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL; 
    if(globalReturnsTrueOrFalse())
    {
        {
            
            static int64_t dataBuffer;
            dataBuffer = 5LL;
            data = &dataBuffer;
        }
    }
    else
    {
        {
            
            int64_t * dataBuffer = new int64_t;
            *dataBuffer = 5LL;
            data = dataBuffer;
        }
    }
    printLongLongLine(*data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int64_t * data;
    data = NULL; 
    if(globalReturnsTrueOrFalse())
    {
        {
            
            int64_t * dataBuffer = new int64_t;
            *dataBuffer = 5LL;
            data = dataBuffer;
        }
    }
    else
    {
        {
            
            int64_t * dataBuffer = new int64_t;
            *dataBuffer = 5LL;
            data = dataBuffer;
        }
    }
    printLongLongLine(*data);
    
    delete data;
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_static_12; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
