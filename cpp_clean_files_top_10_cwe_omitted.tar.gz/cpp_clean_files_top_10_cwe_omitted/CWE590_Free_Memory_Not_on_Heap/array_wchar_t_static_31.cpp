


#include "std_testcase.h"

#include <wchar.h>

namespace array_wchar_t_static_31
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    data = NULL; 
    {
        
        static wchar_t dataBuffer[100];
        wmemset(dataBuffer, L'A', 100-1); 
        dataBuffer[100-1] = L'\0'; 
        data = dataBuffer;
    }
    {
        wchar_t * dataCopy = data;
        wchar_t * data = dataCopy;
        printWLine(data);
        
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    wchar_t * data;
    data = NULL; 
    {
        
        wchar_t * dataBuffer = new wchar_t[100];
        wmemset(dataBuffer, L'A', 100-1); 
        dataBuffer[100-1] = L'\0'; 
        data = dataBuffer;
    }
    {
        wchar_t * dataCopy = data;
        wchar_t * data = dataCopy;
        printWLine(data);
        
        delete [] data;
    }
}

void good()
{
    goodG2B();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace array_wchar_t_static_31; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
