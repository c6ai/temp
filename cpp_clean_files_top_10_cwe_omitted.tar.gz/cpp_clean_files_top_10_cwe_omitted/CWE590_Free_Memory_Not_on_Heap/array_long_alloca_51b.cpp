


#include "std_testcase.h"

#include <wchar.h>

namespace array_long_alloca_51
{



#ifndef OMITBAD

void badSink(long * data)
{
    printLongLine(data[0]);
    
    delete [] data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(long * data)
{
    printLongLine(data[0]);
    
    delete [] data;
}

#endif 

} 
