


#include "std_testcase.h"

#include <wchar.h>

namespace int_declare_65
{

#ifndef OMITBAD

void badSink(int * data)
{
    printIntLine(*data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * data)
{
    printIntLine(*data);
    
    delete data;
}

#endif 

} 
