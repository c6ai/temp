


#include "std_testcase.h"

#include <wchar.h>

namespace int64_t_static_44
{

#ifndef OMITBAD

static void badSink(int64_t * data)
{
    printLongLongLine(*data);
    
    delete data;
}

void bad()
{
    int64_t * data;
    
    void (*funcPtr) (int64_t *) = badSink;
    data = NULL; 
    {
        
        static int64_t dataBuffer;
        dataBuffer = 5LL;
        data = &dataBuffer;
    }
    
    funcPtr(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(int64_t * data)
{
    printLongLongLine(*data);
    
    delete data;
}

static void goodG2B()
{
    int64_t * data;
    void (*funcPtr) (int64_t *) = goodG2BSink;
    data = NULL; 
    {
        
        int64_t * dataBuffer = new int64_t;
        *dataBuffer = 5LL;
        data = dataBuffer;
    }
    funcPtr(data);
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_static_44; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
