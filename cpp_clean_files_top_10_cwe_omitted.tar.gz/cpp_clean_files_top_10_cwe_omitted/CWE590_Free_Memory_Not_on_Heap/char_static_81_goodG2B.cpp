

#ifndef OMITGOOD

#include "std_testcase.h"
#include "char_static_81.h"

namespace char_static_81
{

void char_static_81_goodG2B::action(char * data) const
{
    printLine(data);
    
    free(data);
}

}
#endif 
