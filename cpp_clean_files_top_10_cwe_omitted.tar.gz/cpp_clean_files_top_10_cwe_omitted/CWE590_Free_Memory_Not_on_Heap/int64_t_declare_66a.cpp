


#include "std_testcase.h"

#include <wchar.h>

namespace int64_t_declare_66
{

#ifndef OMITBAD


void badSink(int64_t * dataArray[]);

void bad()
{
    int64_t * data;
    int64_t * dataArray[5];
    data = NULL; 
    {
        
        int64_t dataBuffer;
        dataBuffer = 5LL;
        data = &dataBuffer;
    }
    
    dataArray[2] = data;
    badSink(dataArray);
}

#endif 

#ifndef OMITGOOD




void goodG2BSink(int64_t * dataArray[]);

static void goodG2B()
{
    int64_t * data;
    int64_t * dataArray[5];
    data = NULL; 
    {
        
        int64_t * dataBuffer = new int64_t;
        *dataBuffer = 5LL;
        data = dataBuffer;
    }
    dataArray[2] = data;
    goodG2BSink(dataArray);
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace int64_t_declare_66; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
