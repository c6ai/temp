


#include "std_testcase.h"

#include <wchar.h>

extern long * long_declare_68_badData;
extern long * long_declare_68_goodG2BData;

namespace long_declare_68
{



#ifndef OMITBAD

void badSink()
{
    long * data = long_declare_68_badData;
    printLongLine(*data);
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink()
{
    long * data = long_declare_68_goodG2BData;
    printLongLine(*data);
    
    delete data;
}

#endif 

} 
