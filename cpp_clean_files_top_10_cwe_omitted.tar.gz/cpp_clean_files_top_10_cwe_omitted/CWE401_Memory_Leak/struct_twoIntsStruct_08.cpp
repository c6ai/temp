


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif


static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}

namespace struct_twoIntsStruct_08
{

#ifndef OMITBAD

void bad()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(staticReturnsTrue())
    {
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G1()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(staticReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        delete data;
    }
}


static void goodB2G2()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticReturnsTrue())
    {
        
        data = new struct _twoIntsStruct;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(staticReturnsTrue())
    {
        
        delete data;
    }
}


static void goodG2B1()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticReturnsFalse())
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        struct _twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(staticReturnsTrue())
    {
        
        ; 
    }
}


static void goodG2B2()
{
    struct _twoIntsStruct * data;
    data = NULL;
    if(staticReturnsTrue())
    {
        
        struct _twoIntsStruct dataGoodBuffer;
        data = &dataGoodBuffer;
        
        data->intOne = 0;
        data->intTwo = 0;
        printStructLine((twoIntsStruct *)data);
    }
    if(staticReturnsTrue())
    {
        
        ; 
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace struct_twoIntsStruct_08; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
