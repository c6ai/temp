

#ifndef OMITGOOD

#include "std_testcase.h"
#include "array_int64_t_81.h"

namespace array_int64_t_81
{

void array_int64_t_81_goodG2B::action(int64_t * data) const
{
    
    ; 
}

}
#endif 
