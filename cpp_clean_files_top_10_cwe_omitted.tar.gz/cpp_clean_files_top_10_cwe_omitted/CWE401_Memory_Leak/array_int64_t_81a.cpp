


#include "std_testcase.h"
#include "array_int64_t_81.h"

namespace array_int64_t_81
{

#ifndef OMITBAD

void bad()
{
    int64_t * data;
    data = NULL;
    
    data = new int64_t[100];
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    const array_int64_t_81_base& o = array_int64_t_81_bad();
    o.action(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    int64_t * data;
    data = NULL;
    
    int64_t dataGoodBuffer[100];
    data = dataGoodBuffer;
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    const array_int64_t_81_base& baseObject = array_int64_t_81_goodG2B();
    baseObject.action(data);
}


static void goodB2G()
{
    int64_t * data;
    data = NULL;
    
    data = new int64_t[100];
    
    data[0] = 5LL;
    printLongLongLine(data[0]);
    const array_int64_t_81_base& baseObject = array_int64_t_81_goodB2G();
    baseObject.action(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace array_int64_t_81; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
