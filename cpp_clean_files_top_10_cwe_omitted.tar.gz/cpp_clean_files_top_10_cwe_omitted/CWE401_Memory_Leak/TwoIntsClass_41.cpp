


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace TwoIntsClass_41
{

#ifndef OMITBAD

static void badSink(TwoIntsClass * data)
{
    
    ; 
}

void bad()
{
    TwoIntsClass * data;
    data = NULL;
    
    data = new TwoIntsClass;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    badSink(data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BSink(TwoIntsClass * data)
{
    
    ; 
}

static void goodG2B()
{
    TwoIntsClass * data;
    data = NULL;
    
    TwoIntsClass dataGoodBuffer;
    data = &dataGoodBuffer;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    goodG2BSink(data);
}


static void goodB2GSink(TwoIntsClass * data)
{
    
    delete data;
}

static void goodB2G()
{
    TwoIntsClass * data;
    data = NULL;
    
    data = new TwoIntsClass;
    
    data->intOne = 0;
    data->intTwo = 0;
    printIntLine(data->intOne);
    printIntLine(data->intTwo);
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace TwoIntsClass_41; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
