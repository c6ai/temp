


#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

namespace wchar_t_34
{

typedef union
{
    wchar_t * unionFirst;
    wchar_t * unionSecond;
} unionType;

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    unionType myUnion;
    data = NULL;
    
    data = new wchar_t;
    
    *data = L'A';
    printHexCharLine((char)*data);
    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;
        
        ; 
    }
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    wchar_t * data;
    unionType myUnion;
    data = NULL;
    
    wchar_t dataGoodBuffer;
    data = &dataGoodBuffer;
    
    *data = L'A';
    printHexCharLine((char)*data);
    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;
        
        ; 
    }
}


static void goodB2G()
{
    wchar_t * data;
    unionType myUnion;
    data = NULL;
    
    data = new wchar_t;
    
    *data = L'A';
    printHexCharLine((char)*data);
    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;
        
        delete data;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 


#ifdef INCLUDEMAIN

using namespace wchar_t_34; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
