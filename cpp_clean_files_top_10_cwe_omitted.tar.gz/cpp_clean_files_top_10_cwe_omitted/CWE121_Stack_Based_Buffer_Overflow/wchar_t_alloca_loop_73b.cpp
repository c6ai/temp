


#include "std_testcase.h"
#include <list>

#include <wchar.h>

using namespace std;

namespace wchar_t_alloca_loop_73
{

#ifndef OMITBAD

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    {
        size_t i;
        wchar_t source[100];
        wmemset(source, L'C', 100-1); 
        source[100-1] = L'\0'; 
        
        for (i = 0; i < 100; i++)
        {
            data[i] = source[i];
        }
        data[100-1] = L'\0'; 
        printWLine(data);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    {
        size_t i;
        wchar_t source[100];
        wmemset(source, L'C', 100-1); 
        source[100-1] = L'\0'; 
        
        for (i = 0; i < 100; i++)
        {
            data[i] = source[i];
        }
        data[100-1] = L'\0'; 
        printWLine(data);
    }
}

#endif 

} 
