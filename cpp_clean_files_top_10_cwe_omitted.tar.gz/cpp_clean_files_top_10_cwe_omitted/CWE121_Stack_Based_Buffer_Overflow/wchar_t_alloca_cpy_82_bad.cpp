

#ifndef OMITBAD

#include "std_testcase.h"
#include "wchar_t_alloca_cpy_82.h"

namespace wchar_t_alloca_cpy_82
{

void wchar_t_alloca_cpy_82_bad::action(wchar_t * data)
{
    {
        wchar_t source[100];
        wmemset(source, L'C', 100-1); 
        source[100-1] = L'\0'; 
        
        wcscpy(data, source);
        printWLine(data);
    }
}

}
#endif 
