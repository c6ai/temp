

#ifndef OMITGOOD

#include "std_testcase.h"
#include "wchar_t_declare_memmove_82.h"

namespace wchar_t_declare_memmove_82
{

void wchar_t_declare_memmove_82_goodG2B::action(wchar_t * data)
{
    {
        wchar_t source[10+1] = SRC_STRING;
        
        
        memmove(data, source, (wcslen(source) + 1) * sizeof(wchar_t));
        printWLine(data);
    }
}

}
#endif 
