


#include "std_testcase.h"
#include <list>

#include <wchar.h>

using namespace std;

namespace wchar_t_alloca_cat_73
{

#ifndef OMITBAD

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    {
        wchar_t source[100];
        wmemset(source, L'C', 100-1); 
        source[100-1] = L'\0'; 
        
        wcscat(data, source);
        printWLine(data);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    {
        wchar_t source[100];
        wmemset(source, L'C', 100-1); 
        source[100-1] = L'\0'; 
        
        wcscat(data, source);
        printWLine(data);
    }
}

#endif 

} 
