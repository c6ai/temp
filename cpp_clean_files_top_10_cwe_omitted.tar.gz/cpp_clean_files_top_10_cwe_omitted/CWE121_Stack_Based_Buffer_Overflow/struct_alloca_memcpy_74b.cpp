


#include "std_testcase.h"
#include <map>

using namespace std;

namespace struct_alloca_memcpy_74
{

#ifndef OMITBAD

void badSink(map<int, twoIntsStruct *> dataMap)
{
    
    twoIntsStruct * data = dataMap[2];
    {
        twoIntsStruct source[100];
        {
            size_t i;
            
            for (i = 0; i < 100; i++)
            {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        
        memcpy(data, source, 100*sizeof(twoIntsStruct));
        printStructLine(&data[0]);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, twoIntsStruct *> dataMap)
{
    twoIntsStruct * data = dataMap[2];
    {
        twoIntsStruct source[100];
        {
            size_t i;
            
            for (i = 0; i < 100; i++)
            {
                source[i].intOne = 0;
                source[i].intTwo = 0;
            }
        }
        
        memcpy(data, source, 100*sizeof(twoIntsStruct));
        printStructLine(&data[0]);
    }
}

#endif 

} 
