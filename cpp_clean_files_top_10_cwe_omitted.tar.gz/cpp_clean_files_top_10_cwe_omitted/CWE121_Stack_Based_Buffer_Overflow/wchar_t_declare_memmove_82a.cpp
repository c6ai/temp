


#include "std_testcase.h"
#include "wchar_t_declare_memmove_82.h"

namespace wchar_t_declare_memmove_82
{

#ifndef OMITBAD

void bad()
{
    wchar_t * data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10+1];
    
    data = dataBadBuffer;
    data[0] = L'\0'; 
    wchar_t_declare_memmove_82_base* baseObject = new wchar_t_declare_memmove_82_bad;
    baseObject->action(data);
    delete baseObject;
}

#endif 

#ifndef OMITGOOD


static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBadBuffer[10];
    wchar_t dataGoodBuffer[10+1];
    
    data = dataGoodBuffer;
    data[0] = L'\0'; 
    wchar_t_declare_memmove_82_base* baseObject = new wchar_t_declare_memmove_82_goodG2B;
    baseObject->action(data);
    delete baseObject;
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace wchar_t_declare_memmove_82; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
