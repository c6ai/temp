


#include "std_testcase.h"

#ifdef _WIN32
#define BASEPATH L"c:\\temp\\"
#else
#include <wchar.h>
#define BASEPATH L"/tmp/"
#endif

#include <fstream>
using namespace std;

namespace t_console_ofstream_61
{

#ifndef OMITBAD

wchar_t * badSource(wchar_t * data)
{
    {
        
        size_t dataLen = wcslen(data);
        
        if (FILENAME_MAX-dataLen > 1)
        {
            
            if (fgetws(data+dataLen, (int)(FILENAME_MAX-dataLen), stdin) != NULL)
            {
                
                dataLen = wcslen(data);
                if (dataLen > 0 && data[dataLen-1] == L'\n')
                {
                    data[dataLen-1] = L'\0';
                }
            }
            else
            {
                printLine("fgetws() failed");
                
                data[dataLen] = L'\0';
            }
        }
    }
    return data;
}

#endif 

#ifndef OMITGOOD


wchar_t * goodG2BSource(wchar_t * data)
{
    
    wcscat(data, L"file.txt");
    return data;
}

#endif 

} 
