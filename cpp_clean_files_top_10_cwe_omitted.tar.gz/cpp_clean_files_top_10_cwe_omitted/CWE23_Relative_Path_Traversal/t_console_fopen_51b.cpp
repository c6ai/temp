


#include "std_testcase.h"

#ifdef _WIN32
#define BASEPATH L"c:\\temp\\"
#else
#include <wchar.h>
#define BASEPATH L"/tmp/"
#endif

#ifdef _WIN32
#define FOPEN _wfopen
#else
#define FOPEN fopen
#endif

namespace t_console_fopen_51
{



#ifndef OMITBAD

void badSink(wchar_t * data)
{
    {
        FILE *pFile = NULL;
        
        pFile = FOPEN(data, L"wb+");
        if (pFile != NULL)
        {
            fclose(pFile);
        }
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(wchar_t * data)
{
    {
        FILE *pFile = NULL;
        
        pFile = FOPEN(data, L"wb+");
        if (pFile != NULL)
        {
            fclose(pFile);
        }
    }
}

#endif 

} 
