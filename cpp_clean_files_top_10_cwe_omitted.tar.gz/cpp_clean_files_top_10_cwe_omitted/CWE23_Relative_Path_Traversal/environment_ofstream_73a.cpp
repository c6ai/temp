


#include "std_testcase.h"
#include <list>

#ifdef _WIN32
#define BASEPATH "c:\\temp\\"
#else
#include <wchar.h>
#define BASEPATH "/tmp/"
#endif

#define ENV_VARIABLE "ADD"

#ifdef _WIN32
#define GETENV getenv
#else
#define GETENV getenv
#endif

using namespace std;

namespace environment_ofstream_73
{

#ifndef OMITBAD


void badSink(list<char *> dataList);

void bad()
{
    char * data;
    list<char *> dataList;
    char dataBuffer[FILENAME_MAX] = BASEPATH;
    data = dataBuffer;
    {
        
        size_t dataLen = strlen(data);
        char * environment = GETENV(ENV_VARIABLE);
        
        if (environment != NULL)
        {
            
            strncat(data+dataLen, environment, FILENAME_MAX-dataLen-1);
        }
    }
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    badSink(dataList);
}

#endif 

#ifndef OMITGOOD




void goodG2BSink(list<char *> dataList);

static void goodG2B()
{
    char * data;
    list<char *> dataList;
    char dataBuffer[FILENAME_MAX] = BASEPATH;
    data = dataBuffer;
    
    strcat(data, "file.txt");
    
    dataList.push_back(data);
    dataList.push_back(data);
    dataList.push_back(data);
    goodG2BSink(dataList);
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace environment_ofstream_73; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
