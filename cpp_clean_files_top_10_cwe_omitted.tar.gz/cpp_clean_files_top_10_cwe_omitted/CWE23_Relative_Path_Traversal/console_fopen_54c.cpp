


#include "std_testcase.h"

#ifdef _WIN32
#define BASEPATH "c:\\temp\\"
#else
#include <wchar.h>
#define BASEPATH "/tmp/"
#endif

#ifdef _WIN32
#define FOPEN fopen
#else
#define FOPEN fopen
#endif

namespace console_fopen_54
{



#ifndef OMITBAD


void badSink_d(char * data);

void badSink_c(char * data)
{
    badSink_d(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(char * data);

void goodG2BSink_c(char * data)
{
    goodG2BSink_d(data);
}

#endif 

} 
