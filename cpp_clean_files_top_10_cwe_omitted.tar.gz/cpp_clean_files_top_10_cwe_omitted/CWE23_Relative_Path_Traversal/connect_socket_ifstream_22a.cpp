


#include "std_testcase.h"

#ifdef _WIN32
#define BASEPATH "c:\\temp\\"
#else
#include <wchar.h>
#define BASEPATH "/tmp/"
#endif

#include <fstream>
using namespace std;

namespace connect_socket_ifstream_22
{

#ifndef OMITBAD


int badGlobal = 0;

char * badSource(char * data);

void bad()
{
    char * data;
    char dataBuffer[FILENAME_MAX] = BASEPATH;
    data = dataBuffer;
    badGlobal = 1; 
    data = badSource(data);
    {
        ifstream inputFile;
        
        inputFile.open((char *)data);
        inputFile.close();
    }
    ;
}

#endif 

#ifndef OMITGOOD


int goodG2B1Global = 0;
int goodG2B2Global = 0;


char * goodG2B1Source(char * data);

static void goodG2B1()
{
    char * data;
    char dataBuffer[FILENAME_MAX] = BASEPATH;
    data = dataBuffer;
    goodG2B1Global = 0; 
    data = goodG2B1Source(data);
    {
        ifstream inputFile;
        
        inputFile.open((char *)data);
        inputFile.close();
    }
    ;
}


char * goodG2B2Source(char * data);

static void goodG2B2()
{
    char * data;
    char dataBuffer[FILENAME_MAX] = BASEPATH;
    data = dataBuffer;
    goodG2B2Global = 1; 
    data = goodG2B2Source(data);
    {
        ifstream inputFile;
        
        inputFile.open((char *)data);
        inputFile.close();
    }
    ;
}

void good()
{
    goodG2B1();
    goodG2B2();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace connect_socket_ifstream_22; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
