


#include "std_testcase.h"

#include <wchar.h>

namespace wchar_t_ncpy_54
{



#ifndef OMITBAD


void badSink_d(wchar_t * data);

void badSink_c(wchar_t * data)
{
    badSink_d(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_d(wchar_t * data);

void goodG2BSink_c(wchar_t * data)
{
    goodG2BSink_d(data);
}

#endif 

} 
