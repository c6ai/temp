


#include "std_testcase.h"
#include <list>

#include <wchar.h>

using namespace std;

namespace wchar_t_loop_73
{

#ifndef OMITBAD

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    {
        size_t i;
        wchar_t dest[100];
        wmemset(dest, L'C', 100-1); 
        dest[100-1] = L'\0'; 
        
        for (i = 0; i < 100; i++)
        {
            dest[i] = data[i];
        }
        
        dest[100-1] = L'\0';
        printWLine(dest);
        
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    {
        size_t i;
        wchar_t dest[100];
        wmemset(dest, L'C', 100-1); 
        dest[100-1] = L'\0'; 
        
        for (i = 0; i < 100; i++)
        {
            dest[i] = data[i];
        }
        
        dest[100-1] = L'\0';
        printWLine(dest);
        
    }
}

#endif 

} 
