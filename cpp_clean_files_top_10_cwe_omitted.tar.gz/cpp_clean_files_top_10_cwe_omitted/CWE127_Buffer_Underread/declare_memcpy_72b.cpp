


#include "std_testcase.h"
#include <vector>

#include <wchar.h>

using namespace std;

namespace declare_memcpy_72
{

#ifndef OMITBAD

void badSink(vector<char *> dataVector)
{
    
    char * data = dataVector[2];
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        memcpy(dest, data, 100*sizeof(char));
        
        dest[100-1] = '\0';
        printLine(dest);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(vector<char *> dataVector)
{
    char * data = dataVector[2];
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        memcpy(dest, data, 100*sizeof(char));
        
        dest[100-1] = '\0';
        printLine(dest);
    }
}

#endif 

} 
