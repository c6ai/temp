


#include "std_testcase.h"

#include <wchar.h>

namespace char_ncpy_42
{

#ifndef OMITBAD

static char * badSource(char * data)
{
    {
        char * dataBuffer = new char[100];
        memset(dataBuffer, 'A', 100-1);
        dataBuffer[100-1] = '\0';
        
        data = dataBuffer - 8;
    }
    return data;
}

void bad()
{
    char * data;
    data = NULL;
    data = badSource(data);
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        strncpy(dest, data, strlen(dest));
        
        dest[100-1] = '\0';
        printLine(dest);
        
    }
}

#endif 

#ifndef OMITGOOD

static char * goodG2BSource(char * data)
{
    {
        char * dataBuffer = new char[100];
        memset(dataBuffer, 'A', 100-1);
        dataBuffer[100-1] = '\0';
        
        data = dataBuffer;
    }
    return data;
}


static void goodG2B()
{
    char * data;
    data = NULL;
    data = goodG2BSource(data);
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        strncpy(dest, data, strlen(dest));
        
        dest[100-1] = '\0';
        printLine(dest);
        
    }
}

void good()
{
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace char_ncpy_42; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
