


#include "std_testcase.h"

#include <wchar.h>

namespace char_ncpy_66
{

#ifndef OMITBAD

void badSink(char * dataArray[])
{
    
    char * data = dataArray[2];
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        strncpy(dest, data, strlen(dest));
        
        dest[100-1] = '\0';
        printLine(dest);
        
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(char * dataArray[])
{
    char * data = dataArray[2];
    {
        char dest[100];
        memset(dest, 'C', 100-1); 
        dest[100-1] = '\0'; 
        
        strncpy(dest, data, strlen(dest));
        
        dest[100-1] = '\0';
        printLine(dest);
        
    }
}

#endif 

} 
