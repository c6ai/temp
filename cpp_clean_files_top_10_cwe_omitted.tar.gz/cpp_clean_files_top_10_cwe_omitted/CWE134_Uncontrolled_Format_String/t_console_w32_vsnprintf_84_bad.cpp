

#ifndef OMITBAD

#include <stdarg.h>
#include "std_testcase.h"
#include "t_console_w32_vsnprintf_84.h"

namespace t_console_w32_vsnprintf_84
{
t_console_w32_vsnprintf_84_bad::t_console_w32_vsnprintf_84_bad(wchar_t * dataCopy)
{
    data = dataCopy;
    {
        
        size_t dataLen = wcslen(data);
        
        if (100-dataLen > 1)
        {
            
            if (fgetws(data+dataLen, (int)(100-dataLen), stdin) != NULL)
            {
                
                dataLen = wcslen(data);
                if (dataLen > 0 && data[dataLen-1] == L'\n')
                {
                    data[dataLen-1] = L'\0';
                }
            }
            else
            {
                printLine("fgetws() failed");
                
                data[dataLen] = L'\0';
            }
        }
    }
}

static void badVaSink(wchar_t * data, ...)
{
    {
        wchar_t dest[100] = L"";
        va_list args;
        va_start(args, data);
        
        _vsnwprintf(dest, 100-1, data, args);
        va_end(args);
        printWLine(dest);
    }
}

t_console_w32_vsnprintf_84_bad::~t_console_w32_vsnprintf_84_bad()
{
    badVaSink(data, data);
}
}
#endif 
