

#ifndef OMITGOOD

#include "std_testcase.h"
#include "t_file_printf_83.h"

#ifdef _WIN32
#define FILENAME "C:\\temp\\file.txt"
#else
#define FILENAME "/tmp/file.txt"
#endif

namespace t_file_printf_83
{
t_file_printf_83_goodB2G::t_file_printf_83_goodB2G(wchar_t * dataCopy)
{
    data = dataCopy;
    {
        
        size_t dataLen = wcslen(data);
        FILE * pFile;
        
        if (100-dataLen > 1)
        {
            pFile = fopen(FILENAME, "r");
            if (pFile != NULL)
            {
                
                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");
                    
                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
}

t_file_printf_83_goodB2G::~t_file_printf_83_goodB2G()
{
    
    wprintf(L"%s\n", data);
}
}
#endif 
