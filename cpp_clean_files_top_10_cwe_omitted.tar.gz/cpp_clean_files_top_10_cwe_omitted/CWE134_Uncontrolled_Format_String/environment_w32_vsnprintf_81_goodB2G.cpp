

#ifndef OMITGOOD

#include <stdarg.h>
#include "std_testcase.h"
#include "environment_w32_vsnprintf_81.h"

namespace environment_w32_vsnprintf_81
{

static void goodB2GVaSink(char * data, ...)
{
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        
        vsnprintf(dest, 100-1, "%s", args);
        va_end(args);
        printLine(dest);
    }
}

void environment_w32_vsnprintf_81_goodB2G::action(char * data) const
{
    goodB2GVaSink(data, data);
}

}
#endif 
