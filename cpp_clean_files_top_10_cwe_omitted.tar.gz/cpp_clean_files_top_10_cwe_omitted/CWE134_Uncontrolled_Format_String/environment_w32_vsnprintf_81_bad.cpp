

#ifndef OMITBAD

#include <stdarg.h>
#include "std_testcase.h"
#include "environment_w32_vsnprintf_81.h"

namespace environment_w32_vsnprintf_81
{

static void badVaSink(char * data, ...)
{
    {
        char dest[100] = "";
        va_list args;
        va_start(args, data);
        
        vsnprintf(dest, 100-1, data, args);
        va_end(args);
        printLine(dest);
    }
}

void environment_w32_vsnprintf_81_bad::action(char * data) const
{
    badVaSink(data, data);
}

}
#endif 
