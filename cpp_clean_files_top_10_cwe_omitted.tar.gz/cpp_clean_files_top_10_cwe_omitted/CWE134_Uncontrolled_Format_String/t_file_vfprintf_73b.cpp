

#include <stdarg.h>
#include <list>
#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace t_file_vfprintf_73
{

#ifndef OMITBAD

static void badVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, data, args);
        va_end(args);
    }
}

void badSink(list<wchar_t *> dataList)
{
    
    wchar_t * data = dataList.back();
    badVaSink(data, data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, data, args);
        va_end(args);
    }
}

void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    goodG2BVaSink(data, data);
}


static void goodB2GVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, L"%s", args);
        va_end(args);
    }
}

void goodB2GSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();
    goodB2GVaSink(data, data);
}

#endif 

} 
