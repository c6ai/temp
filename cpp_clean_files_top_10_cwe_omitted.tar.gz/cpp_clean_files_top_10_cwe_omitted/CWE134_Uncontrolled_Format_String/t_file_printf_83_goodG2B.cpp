

#ifndef OMITGOOD

#include "std_testcase.h"
#include "t_file_printf_83.h"

#ifdef _WIN32
#define FILENAME "C:\\temp\\file.txt"
#else
#define FILENAME "/tmp/file.txt"
#endif

namespace t_file_printf_83
{
t_file_printf_83_goodG2B::t_file_printf_83_goodG2B(wchar_t * dataCopy)
{
    data = dataCopy;
    
    wcscpy(data, L"fixedstringtest");
}

t_file_printf_83_goodG2B::~t_file_printf_83_goodG2B()
{
    
    wprintf(data);
}
}
#endif 
