

#include <stdarg.h>
#include <map>
#include "std_testcase.h"

#ifndef _WIN32
#include <wchar.h>
#endif

using namespace std;

namespace t_console_vfprintf_74
{

#ifndef OMITBAD

static void badVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, data, args);
        va_end(args);
    }
}

void badSink(map<int, wchar_t *> dataMap)
{
    
    wchar_t * data = dataMap[2];
    badVaSink(data, data);
}

#endif 

#ifndef OMITGOOD


static void goodG2BVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, data, args);
        va_end(args);
    }
}

void goodG2BSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    goodG2BVaSink(data, data);
}


static void goodB2GVaSink(wchar_t * data, ...)
{
    {
        va_list args;
        va_start(args, data);
        
        vfwprintf(stdout, L"%s", args);
        va_end(args);
    }
}

void goodB2GSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];
    goodB2GVaSink(data, data);
}

#endif 

} 
