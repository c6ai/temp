


#include "std_testcase.h"
#include <map>

#include <wchar.h>

#ifdef _WIN32
#define SNPRINTF _snprintf
#else
#define SNPRINTF snprintf
#endif

using namespace std;

namespace CWE805_char_snprintf_74
{

#ifndef OMITBAD

void badSink(map<int, char *> dataMap)
{
    
    char * data = dataMap[2];
    {
        char source[100];
        memset(source, 'C', 100-1); 
        source[100-1] = '\0'; 
        
        SNPRINTF(data, 100, "%s", source);
        printLine(data);
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(map<int, char *> dataMap)
{
    char * data = dataMap[2];
    {
        char source[100];
        memset(source, 'C', 100-1); 
        source[100-1] = '\0'; 
        
        SNPRINTF(data, 100, "%s", source);
        printLine(data);
        delete [] data;
    }
}

#endif 

} 
