


#include "std_testcase.h"

namespace CWE129_fgets_62
{

#ifndef OMITBAD


void badSource(int &data);

void bad()
{
    int data;
    
    data = -1;
    badSource(data);
    {
        int i;
        int * buffer = (int *)malloc(10 * sizeof(int));
        
        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }
        
        if (data >= 0)
        {
            buffer[data] = 1;
            
            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        free(buffer);
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSource(int &data);

static void goodG2B()
{
    int data;
    
    data = -1;
    goodG2BSource(data);
    {
        int i;
        int * buffer = (int *)malloc(10 * sizeof(int));
        
        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }
        
        if (data >= 0)
        {
            buffer[data] = 1;
            
            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        free(buffer);
    }
}


void goodB2GSource(int &data);

static void goodB2G()
{
    int data;
    
    data = -1;
    goodB2GSource(data);
    {
        int i;
        int * buffer = (int *)malloc(10 * sizeof(int));
        
        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }
        
        if (data >= 0 && data < (10))
        {
            buffer[data] = 1;
            
            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is out-of-bounds");
        }
        free(buffer);
    }
}

void good()
{
    goodG2B();
    goodB2G();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace CWE129_fgets_62; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
