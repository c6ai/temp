


#include "std_testcase.h"

#include <wchar.h>

namespace CWE806_wchar_t_ncpy_52
{



#ifndef OMITBAD


void badSink_c(wchar_t * data);

void badSink_b(wchar_t * data)
{
    badSink_c(data);
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_c(wchar_t * data);

void goodG2BSink_b(wchar_t * data)
{
    goodG2BSink_c(data);
}

#endif 

} 
