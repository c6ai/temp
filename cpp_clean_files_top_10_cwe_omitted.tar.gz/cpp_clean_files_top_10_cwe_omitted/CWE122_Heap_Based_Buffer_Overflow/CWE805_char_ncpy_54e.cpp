


#include "std_testcase.h"

#include <wchar.h>

namespace CWE805_char_ncpy_54
{



#ifndef OMITBAD

void badSink_e(char * data)
{
    {
        char source[100];
        memset(source, 'C', 100-1); 
        source[100-1] = '\0'; 
        
        strncpy(data, source, 100-1);
        data[100-1] = '\0'; 
        printLine(data);
        delete [] data;
    }
}

#endif 

#ifndef OMITGOOD


void goodG2BSink_e(char * data)
{
    {
        char source[100];
        memset(source, 'C', 100-1); 
        source[100-1] = '\0'; 
        
        strncpy(data, source, 100-1);
        data[100-1] = '\0'; 
        printLine(data);
        delete [] data;
    }
}

#endif 

} 
