

#ifndef OMITGOOD

#include "std_testcase.h"
#include "delete_array_class_84.h"

namespace delete_array_class_84
{
delete_array_class_84_goodB2G::delete_array_class_84_goodB2G(TwoIntsClass * dataCopy)
{
    data = dataCopy;
    data = new TwoIntsClass[100];
    
    delete [] data;
}

delete_array_class_84_goodB2G::~delete_array_class_84_goodB2G()
{
    
    
    ; 
}
}
#endif 
