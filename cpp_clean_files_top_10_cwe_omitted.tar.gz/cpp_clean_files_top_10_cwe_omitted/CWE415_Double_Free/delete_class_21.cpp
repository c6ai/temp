


#include "std_testcase.h"

#include <wchar.h>

namespace delete_class_21
{

#ifndef OMITBAD


static int badStatic = 0;

static void badSink(TwoIntsClass * data)
{
    if(badStatic)
    {
        
        delete data;
    }
}

void bad()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = new TwoIntsClass;
    
    delete data;
    badStatic = 1; 
    badSink(data);
}

#endif 

#ifndef OMITGOOD


static int goodB2G1Static = 0;
static int goodB2G2Static = 0;
static int goodG2bStatic = 0;


static void goodB2G1Sink(TwoIntsClass * data)
{
    if(goodB2G1Static)
    {
        
        printLine("Benign, fixed string");
    }
    else
    {
        
        
        ; 
    }
}

static void goodB2G1()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = new TwoIntsClass;
    
    delete data;
    goodB2G1Static = 0; 
    goodB2G1Sink(data);
}


static void goodB2G2Sink(TwoIntsClass * data)
{
    if(goodB2G2Static)
    {
        
        
        ; 
    }
}

static void goodB2G2()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = new TwoIntsClass;
    
    delete data;
    goodB2G2Static = 1; 
    goodB2G2Sink(data);
}


static void goodG2BSink(TwoIntsClass * data)
{
    if(goodG2bStatic)
    {
        
        delete data;
    }
}

static void goodG2B()
{
    TwoIntsClass * data;
    
    data = NULL;
    data = new TwoIntsClass;
    
    goodG2bStatic = 1; 
    goodG2BSink(data);
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_class_21; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
