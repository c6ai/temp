

#ifndef OMITBAD

#include "std_testcase.h"
#include "delete_array_class_84.h"

namespace delete_array_class_84
{
delete_array_class_84_bad::delete_array_class_84_bad(TwoIntsClass * dataCopy)
{
    data = dataCopy;
    data = new TwoIntsClass[100];
    
    delete [] data;
}

delete_array_class_84_bad::~delete_array_class_84_bad()
{
    
    delete [] data;
}
}
#endif 
