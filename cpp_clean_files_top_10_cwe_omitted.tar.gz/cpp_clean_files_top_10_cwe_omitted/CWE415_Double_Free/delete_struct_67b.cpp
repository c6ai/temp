


#include "std_testcase.h"

#include <wchar.h>

namespace delete_struct_67
{

typedef struct _structType
{
    twoIntsStruct * structFirst;
} structType;

#ifndef OMITBAD

void badSink(structType myStruct)
{
    twoIntsStruct * data = myStruct.structFirst;
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(structType myStruct)
{
    twoIntsStruct * data = myStruct.structFirst;
    
    delete data;
}


void goodB2GSink(structType myStruct)
{
    twoIntsStruct * data = myStruct.structFirst;
    
    
    ; 
}

#endif 

} 
