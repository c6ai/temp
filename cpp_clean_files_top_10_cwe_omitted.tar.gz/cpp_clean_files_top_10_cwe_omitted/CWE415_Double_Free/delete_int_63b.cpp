


#include "std_testcase.h"

#include <wchar.h>

namespace delete_int_63
{

#ifndef OMITBAD

void badSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    delete data;
}

#endif 

#ifndef OMITGOOD


void goodG2BSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    delete data;
}


void goodB2GSink(int * * dataPtr)
{
    int * data = *dataPtr;
    
    
    ; 
}

#endif 

} 
