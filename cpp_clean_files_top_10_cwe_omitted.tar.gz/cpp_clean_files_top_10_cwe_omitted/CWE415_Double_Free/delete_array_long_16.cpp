


#include "std_testcase.h"

#include <wchar.h>

namespace delete_array_long_16
{

#ifndef OMITBAD

void bad()
{
    long * data;
    
    data = NULL;
    while(1)
    {
        data = new long[100];
        
        delete [] data;
        break;
    }
    while(1)
    {
        
        delete [] data;
        break;
    }
}

#endif 

#ifndef OMITGOOD


static void goodB2G()
{
    long * data;
    
    data = NULL;
    while(1)
    {
        data = new long[100];
        
        delete [] data;
        break;
    }
    while(1)
    {
        
        
        ; 
        break;
    }
}


static void goodG2B()
{
    long * data;
    
    data = NULL;
    while(1)
    {
        data = new long[100];
        
        break;
    }
    while(1)
    {
        
        delete [] data;
        break;
    }
}

void good()
{
    goodB2G();
    goodG2B();
}

#endif 

} 



#ifdef INCLUDEMAIN

using namespace delete_array_long_16; 

int main(int argc, char * argv[])
{
    
    srand( (unsigned)time(NULL) );
#ifndef OMITGOOD
    printLine("Calling good()...");
    good();
    printLine("Finished good()");
#endif 
#ifndef OMITBAD
    printLine("Calling bad()...");
    bad();
    printLine("Finished bad()");
#endif 
    return 0;
}

#endif
